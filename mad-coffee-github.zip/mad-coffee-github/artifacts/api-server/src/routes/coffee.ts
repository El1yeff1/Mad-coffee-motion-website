import { createHmac, createHash, randomUUID, timingSafeEqual } from "node:crypto";
import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { asc, desc, eq, max } from "drizzle-orm";
import {
  AdminLoginBody,
  AdminLoginResponse,
  CreateBranchBody,
  CreateBranchResponse,
  CreateContentBlockBody,
  CreateContentBlockResponse,
  CreateMenuItemBody,
  CreateMenuItemResponse,
  GetAdminDataResponse,
  GetAdminSessionResponse,
  GetSiteDataResponse,
  UpdateBranchBody,
  UpdateBranchResponse,
  UpdateContentBlockBody,
  UpdateContentBlockResponse,
  UpdateMenuItemBody,
  UpdateMenuItemResponse,
} from "@workspace/api-zod";
import { branchesTable, contentBlocksTable, db, menuItemsTable } from "@workspace/db";
import { initialBranches, initialMenu } from "../lib/coffee-seed";

const router: IRouter = Router();
const sessionCookieName = "mad_coffee_admin_session";
const sessionLifetimeSeconds = 60 * 60 * 12;

const sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret) throw new Error("SESSION_SECRET must be configured for admin sessions.");
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  throw new Error("ADMIN_USERNAME and ADMIN_PASSWORD must be configured for admin access.");
}

function constantTimeEqual(left: string, right: string): boolean {
  const leftHash = createHash("sha256").update(left).digest();
  const rightHash = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftHash, rightHash);
}

function createSessionToken(expiresAt: number): string {
  const value = String(expiresAt);
const signature = createHmac("sha256", sessionSecret!).update(value).digest("base64url");
  return `${value}.${signature}`;
}

function isValidSession(token: unknown): boolean {
  if (typeof token !== "string") return false;
  const [expiryValue, signature, extra] = token.split(".");
  const expiresAt = Number(expiryValue);
  if (!expiryValue || !signature || extra !== undefined || !Number.isSafeInteger(expiresAt)) return false;
  if (expiresAt <= Math.floor(Date.now() / 1000)) return false;
  return constantTimeEqual(createSessionToken(expiresAt), token);
}

function sameOrigin(req: Request, res: Response): boolean {
  const origin = req.get("origin");
  if (!origin) return true;
  try {
    if (new URL(origin).host === req.get("host")) return true;
  } catch {
    // Invalid Origin values are rejected below.
  }
  res.status(403).json({ error: "Requests must come from this site." });
  return false;
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (!isValidSession(req.cookies?.[sessionCookieName])) {
    res.status(401).json({ error: "Admin session required." });
    return;
  }
  next();
}

let seedWork: Promise<void> | undefined;
async function ensureInitialCatalog(): Promise<void> {
  if (!seedWork) {
    seedWork = (async () => {
      const currentMenu = await db.select({ id: menuItemsTable.id, position: menuItemsTable.position }).from(menuItemsTable);
      if (currentMenu.length === 0) {
        await db.insert(menuItemsTable).values(initialMenu.map((item, position) => ({ ...item, position }))).onConflictDoNothing();
      } else if (
        currentMenu.length === initialMenu.length &&
        currentMenu.every((item) => item.position === 0) &&
        initialMenu.every((item) => currentMenu.some((saved) => saved.id === item.id))
      ) {
        await Promise.all(initialMenu.map((item, position) =>
          db.update(menuItemsTable).set({ position }).where(eq(menuItemsTable.id, item.id)),
        ));
      }
      const [branchCount] = await db.select({ count: branchesTable.id }).from(branchesTable).limit(1);
      if (!branchCount) await db.insert(branchesTable).values(initialBranches).onConflictDoNothing();
    })().catch((error: unknown) => {
      seedWork = undefined;
      throw error;
    });
  }
  await seedWork;
}

function parseId(raw: string | string[] | undefined): string | null {
  const value = Array.isArray(raw) ? raw[0] : raw;
  return typeof value === "string" && value.length > 0 && value.length <= 120 ? value : null;
}

router.get("/site-data", async (_req, res): Promise<void> => {
  await ensureInitialCatalog();
  const [menu, branches, content] = await Promise.all([
    db.select().from(menuItemsTable).where(eq(menuItemsTable.available, true)).orderBy(asc(menuItemsTable.position), asc(menuItemsTable.id)),
    db.select().from(branchesTable).where(eq(branchesTable.active, true)).orderBy(asc(branchesTable.id)),
    db.select().from(contentBlocksTable).where(eq(contentBlocksTable.status, "published")).orderBy(asc(contentBlocksTable.updatedAt)),
  ]);
  res.json(GetSiteDataResponse.parse({ menu, branches, content }));
});

router.post("/admin/login", (req, res): void => {
  if (!sameOrigin(req, res)) return;
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Username and password are required." });
    return;
  }
  const validUsername = constantTimeEqual(parsed.data.username, process.env.ADMIN_USERNAME ?? "");
  const validPassword = constantTimeEqual(parsed.data.password, process.env.ADMIN_PASSWORD ?? "");
  if (!validUsername || !validPassword) {
    res.status(401).json({ error: "Username or password is incorrect." });
    return;
  }
  const expiresAt = Math.floor(Date.now() / 1000) + sessionLifetimeSeconds;
  res.cookie(sessionCookieName, createSessionToken(expiresAt), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/api/admin",
    maxAge: sessionLifetimeSeconds * 1000,
  });
  res.json(AdminLoginResponse.parse({ authenticated: true }));
});

router.post("/admin/logout", (req, res): void => {
  if (!sameOrigin(req, res)) return;
  res.clearCookie(sessionCookieName, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/api/admin",
  });
  res.sendStatus(204);
});

router.get("/admin/session", (req, res): void => {
  res.json(GetAdminSessionResponse.parse({
    authenticated: isValidSession(req.cookies?.[sessionCookieName]),
  }));
});

router.get("/admin/data", requireAdmin, async (_req, res): Promise<void> => {
  await ensureInitialCatalog();
  const [allMenu, allBranches, allContent] = await Promise.all([
    db.select().from(menuItemsTable).orderBy(asc(menuItemsTable.position), asc(menuItemsTable.id)),
    db.select().from(branchesTable).orderBy(asc(branchesTable.id)),
    db.select().from(contentBlocksTable).orderBy(asc(contentBlocksTable.updatedAt)),
  ]);
  res.json(GetAdminDataResponse.parse({
    menu: allMenu.filter((item) => item.available),
    branches: allBranches.filter((branch) => branch.active),
    content: allContent.filter((block) => block.status === "published"),
    allMenu,
    allBranches,
    allContent,
  }));
});

router.post("/admin/menu", requireAdmin, async (req, res): Promise<void> => {
  if (!sameOrigin(req, res)) return;
  const parsed = CreateMenuItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [positionRow] = await db.select({ position: max(menuItemsTable.position) }).from(menuItemsTable);
  const [item] = await db.insert(menuItemsTable).values({
    ...parsed.data,
    id: parsed.data.id || randomUUID(),
    signature: parsed.data.signature ?? false,
    available: parsed.data.available ?? true,
    position: (positionRow?.position ?? -1) + 1,
  }).returning();
  res.status(201).json(CreateMenuItemResponse.parse(item));
});

router.patch("/admin/menu/:id", requireAdmin, async (req, res): Promise<void> => {
  if (!sameOrigin(req, res)) return;
  const id = parseId(req.params.id);
  const parsed = UpdateMenuItemBody.safeParse(req.body);
  if (!id || !parsed.success || Object.keys(parsed.data ?? {}).length === 0) {
    res.status(400).json({ error: parsed.success ? "A menu item id and at least one change are required." : parsed.error.message });
    return;
  }
  const [item] = await db.update(menuItemsTable).set(parsed.data).where(eq(menuItemsTable.id, id)).returning();
  if (!item) {
    res.status(404).json({ error: "Menu item not found." });
    return;
  }
  res.json(UpdateMenuItemResponse.parse(item));
});

router.post("/admin/branches", requireAdmin, async (req, res): Promise<void> => {
  if (!sameOrigin(req, res)) return;
  const parsed = CreateBranchBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [branch] = await db.insert(branchesTable).values({
    ...parsed.data,
    id: parsed.data.id || randomUUID(),
    active: parsed.data.active ?? true,
  }).returning();
  res.status(201).json(CreateBranchResponse.parse(branch));
});

router.patch("/admin/branches/:id", requireAdmin, async (req, res): Promise<void> => {
  if (!sameOrigin(req, res)) return;
  const id = parseId(req.params.id);
  const parsed = UpdateBranchBody.safeParse(req.body);
  if (!id || !parsed.success || Object.keys(parsed.data ?? {}).length === 0) {
    res.status(400).json({ error: parsed.success ? "A branch id and at least one change are required." : parsed.error.message });
    return;
  }
  const [branch] = await db.update(branchesTable).set(parsed.data).where(eq(branchesTable.id, id)).returning();
  if (!branch) {
    res.status(404).json({ error: "Branch not found." });
    return;
  }
  res.json(UpdateBranchResponse.parse(branch));
});

router.post("/admin/content", requireAdmin, async (req, res): Promise<void> => {
  if (!sameOrigin(req, res)) return;
  const parsed = CreateContentBlockBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [block] = await db.insert(contentBlocksTable).values({
    id: randomUUID(),
    title: parsed.data.title,
    body: parsed.data.body,
    status: parsed.data.status ?? "draft",
  }).returning();
  res.status(201).json(CreateContentBlockResponse.parse(block));
});

router.patch("/admin/content/:id", requireAdmin, async (req, res): Promise<void> => {
  if (!sameOrigin(req, res)) return;
  const id = parseId(req.params.id);
  const parsed = UpdateContentBlockBody.safeParse(req.body);
  if (!id || !parsed.success || Object.keys(parsed.data ?? {}).length === 0) {
    res.status(400).json({ error: parsed.success ? "A content block id and at least one change are required." : parsed.error.message });
    return;
  }
  const [block] = await db.update(contentBlocksTable).set(parsed.data).where(eq(contentBlocksTable.id, id)).returning();
  if (!block) {
    res.status(404).json({ error: "Content block not found." });
    return;
  }
  res.json(UpdateContentBlockResponse.parse(block));
});

router.delete("/admin/content/:id", requireAdmin, async (req, res): Promise<void> => {
  if (!sameOrigin(req, res)) return;
  const id = parseId(req.params.id);
  if (!id) {
    res.status(400).json({ error: "A valid content block id is required." });
    return;
  }
  const [block] = await db.delete(contentBlocksTable).where(eq(contentBlocksTable.id, id)).returning();
  if (!block) {
    res.status(404).json({ error: "Content block not found." });
    return;
  }
  res.sendStatus(204);
});

export default router;
