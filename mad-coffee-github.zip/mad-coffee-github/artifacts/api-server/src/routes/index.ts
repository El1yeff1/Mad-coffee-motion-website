import { Router, type IRouter } from "express";
import healthRouter from "./health";
import coffeeRouter from "./coffee";

const router: IRouter = Router();

router.use(healthRouter);
router.use(coffeeRouter);

export default router;
