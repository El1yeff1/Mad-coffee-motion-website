import path from "node:path";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { defineConfig } from "vite";

const port = Number(process.env.PORT ?? 5173);

export default defineConfig({
  base: process.env.BASE_PATH ?? "/",
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { "@": path.resolve(import.meta.dirname, "src") },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: { outDir: path.resolve(import.meta.dirname, "dist"), emptyOutDir: true },
  server: {
    port, strictPort: true, host: "0.0.0.0",
    proxy: { "/api": { target: process.env.API_PROXY_TARGET ?? "http://127.0.0.1:8080", changeOrigin: true } },
  },
  preview: { port, host: "0.0.0.0" },
});
