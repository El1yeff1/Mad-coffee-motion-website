import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "az" | "ru" | "en";
export type L = Record<Lang, string>;
export const LANGS: Lang[] = ["az", "ru", "en"];

const dict = {
  navMenu: { az: "Menyu", ru: "Меню", en: "Menu" },
  navBranches: { az: "Filiallar", ru: "Филиалы", en: "Branches" },
  navAbout: { az: "Brend", ru: "О бренде", en: "About" },
  navBeans: { az: "Məhsullar", ru: "Продукция", en: "Products" },
  navContact: { az: "Əlaqə", ru: "Контакты", en: "Contact" },
  shop: { az: "Dənə al", ru: "Купить зёрна", en: "Shop beans" },
  bag: { az: "Səbət", ru: "Корзина", en: "Bag" },
  cartCount: { az: "{count} məhsul", ru: "Позиций: {count}", en: "{count} items" },
  cartEmpty: { az: "Səbət boşdur.", ru: "Корзина пуста.", en: "Your cart is empty." },
  cartBrowse: { az: "Məhsullara bax", ru: "Смотреть товары", en: "Browse products" },
  cartDecrease: { az: "Sayını azalt", ru: "Уменьшить количество", en: "Decrease quantity" },
  cartIncrease: { az: "Sayını artır", ru: "Увеличить количество", en: "Increase quantity" },
  cartRemove: { az: "Sil", ru: "Удалить", en: "Remove" },
  cartSubtotal: { az: "Cəmi", ru: "Итого", en: "Subtotal" },
  cartNote: { az: "Sifariş filialda tamamlanır.", ru: "Заказ оформляется в кофейне.", en: "Complete your order at the cafe." },
  size250: { az: "250 q", ru: "250 г", en: "250 g" },
  size1k: { az: "1 kq", ru: "1 кг", en: "1 kg" },
  addToCart: { az: "Səbətə əlavə et", ru: "Добавить в корзину", en: "Add to cart" },
  addedToCart: { az: "Səbətə əlavə olundu.", ru: "Добавлено в корзину.", en: "Added to your cart." },
  heroTag: { az: "Yumşaq qəhvə? Bizdə yox.", ru: "Мягкий кофе? Не у нас.", en: "Soft coffee? Not here." },
  heroSub: { az: "Bakıda qovrulur. Dəqiq ölçülür. Heç bir güzəşt olmadan süzülür.", ru: "Обжарено в Баку. Выверено до грамма. Без компромиссов.", en: "Roasted in Baku. Dialed to the gram. Pulled without compromise." },
  scroll: { az: "Aşağı sürüşdür", ru: "Листай вниз", en: "Scroll down" },
  marquee: { az: "Qəzəbli dəqiqlik", ru: "Злая точность", en: "Fierce precision" },
  menuKicker: { az: "01 — Menyu", ru: "01 — Меню", en: "01 — Menu" },
  menuTitle: { az: "Nə içirik bu gün?", ru: "Что пьём сегодня?", en: "What are we drinking?" },
  all: { az: "Hamısı", ru: "Все", en: "All" },
  details: { az: "Ətraflı", ru: "Подробнее", en: "Details" },
  volume: { az: "Həcm", ru: "Объём", en: "Volume" },
  notes: { az: "Dad notları", ru: "Ноты вкуса", en: "Tasting notes" },
  close: { az: "Bağla", ru: "Закрыть", en: "Close" },
  orderAt: { az: "Kassada sifariş et — burada sadəcə baxırıq.", ru: "Заказ — на кассе. Здесь только смотрим.", en: "Order at the bar — this is just the look-book." },
  brKicker: { az: "02 — Filiallar", ru: "02 — Филиалы", en: "02 — Branches" },
  brTitle: { az: "Şəhərdə 4 ünvan", ru: "4 адреса в городе", en: "4 addresses in the city" },
  branchesUnavailable: { az: "Hazırda açıq filial yoxdur.", ru: "Сейчас нет открытых филиалов.", en: "No branches are currently open." },
  catalogSyncError: { az: "Canlı kataloq yüklənmədi. Son mövcud məlumat göstərilir.", ru: "Не удалось загрузить актуальный каталог. Показаны последние доступные данные.", en: "Live catalog is unavailable. Showing the latest available data." },
  hours: { az: "İş saatları", ru: "Часы работы", en: "Hours" },
  phone: { az: "Telefon", ru: "Телефон", en: "Phone" },
  directions: { az: "Yol tarifi", ru: "Маршрут", en: "Get directions" },
  aboutKicker: { az: "03 — Brend haqqında", ru: "03 — О бренде", en: "03 — The brand" },
  aboutTitle: { az: "Biz qəhvəyə qarşı mehriban deyilik. Ona ciddi yanaşırıq.", ru: "Мы не добры к кофе. Мы к нему серьёзны.", en: "We are not nice to coffee. We are serious about it." },
  about1: { az: "Mad — qəhvəyə yanaşmamızın ifadəsidir: cəsarətli dad, dəqiq qovurma və hər fincanda xarakter.", ru: "Mad — наш подход к кофе: смелый вкус, точная обжарка и характер в каждой чашке.", en: "Mad is our approach to coffee: bold flavor, precise roasting, and character in every cup." },
  about2: { az: "Hər partiyanı kiçik həcmdə qovururuq, hər espresso-nu çəkiyə görə yığırıq və barmenlərimiz resepti hər səhər yenidən kalibrləyir.", ru: "Мы жарим малыми партиями, собираем каждый эспрессо по весу, а бариста перекалибровывают рецепт каждое утро.", en: "We roast in small batches, build every shot by weight, and our baristas recalibrate the recipe every single morning." },
  stat1: { az: "qram, hər doppio", ru: "грамма на доппио", en: "grams per doppio" },
  stat2: { az: "saniyə ekstraksiya", ru: "секунд экстракции", en: "seconds of extraction" },
  stat3: { az: "fincan dünən", ru: "чашек вчера", en: "cups yesterday" },
  beansKicker: { az: "04 — Qəhvə məhsulları", ru: "04 — Кофейные продукты", en: "04 — Coffee products" },
  beansTitle: { az: "Evə apar. Düzgün dəm et.", ru: "Забери домой. Завари правильно.", en: "Take it home. Brew it right." },
  roast: { az: "Qovurma", ru: "Обжарка", en: "Roast" },
  process: { az: "Emal", ru: "Обработка", en: "Process" },
  origin: { az: "Mənşə", ru: "Происхождение", en: "Origin" },
  brew: { az: "Tövsiyə", ru: "Рекомендуем", en: "Brew with" },
  contactKicker: { az: "05 — Əlaqə", ru: "05 — Контакты", en: "05 — Contact" },
  contactTitle: { az: "Yaz bizə. Cavab verəcəyik. Nəzakətlə.", ru: "Напиши нам. Ответим. Вежливо.", en: "Write to us. We'll answer. Politely." },
  name: { az: "Ad", ru: "Имя", en: "Name" },
  email: { az: "E-poçt", ru: "E-mail", en: "Email" },
  topic: { az: "Mövzu", ru: "Тема", en: "Topic" },
  message: { az: "Mesaj", ru: "Сообщение", en: "Message" },
  send: { az: "Göndər", ru: "Отправить", en: "Send it" },
  sent: { az: "Mesaj qəbul edildi", ru: "Сообщение принято", en: "Message received" },
  sentD: { az: "Demo forma — hələ server yoxdur, amma biz sizi eşitdik.", ru: "Демо-форма — сервера пока нет, но мы вас услышали.", en: "Demo form — no server yet, but we heard you." },
  required: { az: "Doldurun", ru: "Заполните", en: "Required" },
  badEmail: { az: "Düzgün e-poçt", ru: "Корректный e-mail", en: "Valid email please" },
  social: { az: "Sosial şəbəkələr", ru: "Соцсети", en: "Social" },
  topics: { az: "Ümumi|Əməkdaşlıq|Topdan qəhvə|İş", ru: "Общее|Сотрудничество|Опт зерна|Работа", en: "General|Partnership|Wholesale beans|Careers" },
  footerLine: { az: "Qəhvə ciddi işdir.", ru: "Кофе — дело серьёзное.", en: "Coffee is serious business." },
  rights: { az: "Bütün hüquqlar qorunur", ru: "Все права защищены", en: "All rights reserved" },
  empty: { az: "Bu kateqoriyada hələ heç nə yoxdur.", ru: "В этой категории пока пусто.", en: "Nothing brewing here yet." },
} satisfies Record<string, L>;

type Key = keyof typeof dict;
const Ctx = createContext<{ lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string; tr: (v: L) => string }>(null!);

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem("mad-coffee-lang") as Lang) || "az");
  useEffect(() => {
    localStorage.setItem("mad-coffee-lang", lang);
    document.documentElement.lang = lang;
  }, [lang]);
  return (
    <Ctx.Provider value={{ lang, setLang, t: (k) => dict[k][lang], tr: (v) => v[lang] }}>{children}</Ctx.Provider>
  );
}
export const useLang = () => useContext(Ctx);
// Catalog image names resolve to their preconverted WebP files in public/images.
const webpName = (n: string) => n.replace(/\.(?:png|jpe?g)$/i, ".webp");
export const img = (n: string) => `${import.meta.env.BASE_URL}images/${webpName(n)}`;
