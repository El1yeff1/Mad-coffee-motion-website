import { memo, useEffect, useRef } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";

/* Scroll-driven 3D roastery: a black arched roaster with a wide open roasting pan, seen from ~45 degrees above.
   Progress p (0..1):
   0.00-0.06  camera looks up at beans raining from the sky
   0.06-0.22  camera rides one bean down toward the hopper
   0.22-0.36  beans pour into the pan, camera settles at a 45 degree view
   0.36-0.86  stirring arms toss the beans while they roast (colour, cracks, heat)
   0.86-1.00  heat fades, arms slow down and the camera pulls back to show the machine */

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const ease = (t: number) => { t = clamp(t); return t * t * (3 - 2 * t); };
const smooth = (a: number, b: number, v: number) => ease((v - a) / (b - a));
const STOPS: [number, number[]][] = [
  [0, [128, 146, 78]], [0.22, [178, 166, 72]], [0.42, [170, 117, 58]], [0.62, [126, 77, 36]], [0.8, [84, 49, 26]], [1, [46, 26, 15]],
];
function setRoastColor(out: THREE.Color, r: number) {
  r = clamp(r);
  for (let i = 1; i < STOPS.length; i++) {
    if (r <= STOPS[i][0]) {
      const [a, ca] = STOPS[i - 1], [b, cb] = STOPS[i];
      const t = (r - a) / (b - a);
      out.setRGB(
        (ca[0] + (cb[0] - ca[0]) * t) / 255,
        (ca[1] + (cb[1] - ca[1]) * t) / 255,
        (ca[2] + (cb[2] - ca[2]) * t) / 255,
        THREE.SRGBColorSpace,
      );
      return;
    }
  }
  const final = STOPS[STOPS.length - 1][1];
  out.setRGB(final[0] / 255, final[1] / 255, final[2] / 255, THREE.SRGBColorSpace);
}
export const roastLevel = (p: number) => clamp((p - 0.36) / 0.5);

const RB = 3.0, ARM = 2.85, TOP = 4.2, FLOORY = 0, TAU = Math.PI * 2;
const HERO_REL = 0.06, HERO_DUR = 0.16;

type Bean = {
  pos: THREE.Vector3; vel: THREE.Vector3; q: THREE.Quaternion; w: THREE.Vector3;
  rel: number; dur: number; y0: number; sx: number; sz: number; jit: number; size: number;
  mode: 0 | 1; inside: boolean; pop: number; c1: number; c2: number; hero: boolean; touch: boolean; hadPop: boolean; tx: number; tz: number;
};

function beanGeometry(ws: number, hs: number) {
  const g = new THREE.SphereGeometry(1, ws, hs);
  const pa = g.attributes.position;
  const cols = new Float32Array(pa.count * 3);
  const A = 0.4, B = 0.27, C = 0.2;
  for (let i = 0; i < pa.count; i++) {
    const ux = pa.getX(i), uy = pa.getY(i);
    let uz = pa.getZ(i);
    // slightly pointed ends, one domed side, one flatter side with an S-shaped centre cut
    const taper = 1 - 0.1 * (ux * ux);
    let x = ux * A, y = uy * B * taper, z = uz * C;
    let shade = 1;
    if (uz > 0) {
      z *= 0.62;
      const yc = y - 0.07 * Math.sin(ux * 3.3);
      const w = 0.036;
      const e = Math.exp(-(yc * yc) / (w * w));
      const fade = Math.pow(Math.max(0, 1 - ux * ux), 0.6);
      z -= 0.085 * e * fade;
      shade = 1 - 0.55 * e * fade;
      z += 0.02 * Math.tanh(Math.abs(yc) / 0.08) * (1 - ux * ux);
    } else {
      shade = 1 - 0.1 * Math.abs(uz);
    }
    // soft ambient occlusion toward the rim
    shade *= 0.88 + 0.12 * Math.min(1, Math.abs(uz) * 2.2 + 0.4);
    pa.setXYZ(i, x, y, z);
    cols[i * 3] = cols[i * 3 + 1] = cols[i * 3 + 2] = shade;
  }
  g.setAttribute("color", new THREE.BufferAttribute(cols, 3));
  g.computeVertexNormals();
  return g;
}

function label(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  draw(c.getContext("2d")!);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return { c, t };
}

function paintFace(g: CanvasRenderingContext2D) {
  const gold = (x0: number, y0: number, x1: number, y1: number) => {
    const gr = g.createLinearGradient(x0, y0, x1, y1);
    gr.addColorStop(0, "#f3d38a"); gr.addColorStop(0.35, "#c58a3d"); gr.addColorStop(0.7, "#8a5a22"); gr.addColorStop(1, "#d9a85a");
    return gr;
  };
  /* perforated copper window with dark frame */
  g.fillStyle = "#050404"; g.beginPath(); g.moveTo(300, 70); g.lineTo(724, 70); g.lineTo(770, 270); g.lineTo(254, 270); g.closePath(); g.fill();
  g.fillStyle = gold(300, 70, 724, 270); g.beginPath(); g.moveTo(318, 86); g.lineTo(706, 86); g.lineTo(748, 256); g.lineTo(276, 256); g.closePath(); g.fill();
  g.fillStyle = "rgba(25,12,4,.85)";
  for (let y = 100; y < 250; y += 15) for (let x = 300; x < 740; x += 15) {
    const t = (y - 86) / 170, l = 318 - 42 * t + 6, rr = 706 + 42 * t - 6;
    if (x > l && x < rr) { g.beginPath(); g.arc(x, y, 3.3, 0, Math.PI * 2); g.fill(); }
  }
  g.fillStyle = "#0a0808"; g.fillRect(380, 226, 270, 26);
  g.fillStyle = "#c9c2b8"; g.fillRect(384, 230, 262, 6);
  /* gauges */
  const gauge = (x: number, y: number, r: number, ring: string | CanvasGradient) => {
    g.fillStyle = "#050404"; g.beginPath(); g.arc(x, y, r + 8, 0, Math.PI * 2); g.fill();
    g.fillStyle = ring; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
    g.fillStyle = "#14100d"; g.beginPath(); g.arc(x, y, r * 0.62, 0, Math.PI * 2); g.fill();
    g.fillStyle = "rgba(255,255,255,.25)"; g.beginPath(); g.arc(x - r * 0.25, y - r * 0.28, r * 0.2, 0, Math.PI * 2); g.fill();
  };
  gauge(210, 300, 30, gold(180, 270, 240, 330));
  gauge(830, 290, 22, "#9d9890");
  gauge(900, 330, 16, "#7d7872");
  /* latches */
  g.fillStyle = "#1b1613";
  for (const x of [118, 868]) { g.fillRect(x, 352, 54, 40); g.fillStyle = "#a69d90"; g.fillRect(x + 6, 358, 42, 6); g.fillStyle = "#1b1613"; }
  g.fillStyle = "#14100d"; g.fillRect(180, 372, 664, 6);
  /* gold drop chute */
  g.fillStyle = "#050404"; g.beginPath(); g.moveTo(200, 470); g.lineTo(840, 470); g.quadraticCurveTo(800, 690, 520, 706); g.quadraticCurveTo(240, 690, 200, 470); g.closePath(); g.fill();
  g.fillStyle = gold(200, 470, 840, 706); g.beginPath(); g.moveTo(218, 480); g.lineTo(822, 480); g.quadraticCurveTo(786, 676, 520, 690); g.quadraticCurveTo(254, 676, 218, 480); g.closePath(); g.fill();
  const inner = g.createLinearGradient(0, 480, 0, 690); inner.addColorStop(0, "rgba(40,20,6,.55)"); inner.addColorStop(1, "rgba(255,225,160,.2)");
  g.fillStyle = inner; g.beginPath(); g.moveTo(262, 492); g.lineTo(778, 492); g.quadraticCurveTo(748, 656, 520, 668); g.quadraticCurveTo(292, 656, 262, 492); g.closePath(); g.fill();
  const ball = g.createRadialGradient(500, 548, 4, 520, 566, 44); ball.addColorStop(0, "#fff0c8"); ball.addColorStop(0.45, "#d4973f"); ball.addColorStop(1, "#6d4416");
  g.fillStyle = ball; g.beginPath(); g.arc(520, 566, 44, 0, Math.PI * 2); g.fill();
  g.fillStyle = "#cfc8bd"; g.fillRect(508, 604, 24, 54);
  /* warning triangle */
  g.fillStyle = "#e9bd1b"; g.beginPath(); g.moveTo(110, 740); g.lineTo(150, 668); g.lineTo(190, 740); g.closePath(); g.fill();
  g.fillStyle = "#14100d"; g.fillRect(146, 690, 8, 30); g.beginPath(); g.arc(150, 730, 4, 0, Math.PI * 2); g.fill();
}

function RoastScene3D({ pRef, onFail }: { pRef: React.MutableRefObject<number>; onFail: () => void }) {
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = host.current!;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch { onFail(); return; }
    const lite = window.innerWidth < 760 || (navigator.hardwareConcurrency || 8) < 4 || ((navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8) < 4;
    const N = lite ? 210 : 300, RN = lite ? 22 : 56;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, lite ? 1.25 : 1.75));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.domElement.style.cssText = "display:block;width:100%;height:100%;touch-action:pan-y";
    el.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pm = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    const environmentTarget = pm.fromScene(room, 0.04);
    scene.environment = environmentTarget.texture;
    room.dispose();
    scene.environmentIntensity = 0.55;
    const camera = new THREE.PerspectiveCamera(52, 1, 0.05, 200);

    /* lights */
    scene.add(new THREE.HemisphereLight(0xffe2c0, 0x1a0e08, 0.55));
    const key = new THREE.DirectionalLight(0xffdfb8, 1.55); key.position.set(4, 9, 8); scene.add(key);
    const rim = new THREE.DirectionalLight(0x8fa8ff, 0.7); rim.position.set(-6, 4, -6); scene.add(rim);
    const inner = new THREE.PointLight(0xffa04a, 0, 11, 1.4); inner.position.set(0, 2.2, 0.2); scene.add(inner);
    const burner = new THREE.PointLight(0xff5a1c, 0, 9, 1.6); burner.position.set(0, 0.9, -1.2); scene.add(burner);
    const trayLight = new THREE.PointLight(0xffd0a0, 0, 16, 1.2); trayLight.position.set(0, 4.5, 2.5); scene.add(trayLight);

    /* materials */
    const blackMat = new THREE.MeshStandardMaterial({ color: 0x0d0c0c, metalness: 0.65, roughness: 0.42 });
    const steelLight = new THREE.MeshStandardMaterial({ color: 0x9a8670, metalness: 0.92, roughness: 0.26 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xc9c3ba, metalness: 1, roughness: 0.18 });
    const brass = new THREE.MeshStandardMaterial({ color: 0xb48443, metalness: 1, roughness: 0.3 });
    const drumMat = new THREE.MeshStandardMaterial({ color: 0x5b5149, metalness: 0.88, roughness: 0.42, side: THREE.DoubleSide, emissive: 0xff4a10, emissiveIntensity: 0 });

    /* floor */
    const floor = new THREE.Mesh(new THREE.CircleGeometry(60, 64), new THREE.MeshStandardMaterial({ color: 0x17100b, metalness: 0.5, roughness: 0.34 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -1; scene.add(floor);

    /* roaster body: arched black housing behind the pan */
    const FZ = -3.2, DEPTH = 2.4;
    const shape = new THREE.Shape();
    shape.moveTo(-2.8, -1); shape.lineTo(2.8, -1); shape.lineTo(2.8, 3); shape.absellipse(0, 3, 2.8, 2.1, 0, Math.PI, false, 0); shape.lineTo(-2.8, -1);
    const body = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: DEPTH, bevelEnabled: true, bevelSize: 0.06, bevelThickness: 0.06, bevelSegments: 2, curveSegments: 48 }), blackMat);
    body.position.z = FZ - DEPTH; scene.add(body);
    const casing = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 1.7, 1.7, 48), new THREE.MeshStandardMaterial({ color: 0x6f5426, metalness: 0.9, roughness: 0.38 }));
    casing.rotation.x = Math.PI / 2; casing.position.set(-3.3, 2.3, FZ - 1.9); scene.add(casing);
    const face = label(1024, 796, paintFace);
    const faceMat = new THREE.MeshStandardMaterial({ map: face.t, transparent: true, metalness: 0.3, roughness: 0.5 });
    const facePlane = new THREE.Mesh(new THREE.PlaneGeometry(5.4, 4.2), faceMat); facePlane.position.set(0, 2.3, FZ + 0.075); scene.add(facePlane);
    const plaque = label(512, 100, (g) => {
      const rr = (x: number, y: number, w: number, h: number, r: number) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };
      const grd = g.createLinearGradient(0, 0, 0, 100); grd.addColorStop(0, "#241b15"); grd.addColorStop(1, "#0f0b08");
      rr(3, 3, 506, 94, 16); g.fillStyle = grd; g.fill();
      g.lineWidth = 3; g.strokeStyle = "#8a6a4a"; g.stroke();
      rr(10, 10, 492, 80, 11); g.lineWidth = 1.5; g.strokeStyle = "rgba(255,150,70,.45)"; g.stroke();
      g.font = "800 54px Arial Black, Arial, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
      g.fillStyle = "rgba(0,0,0,.6)"; g.fillText("MAD ROASTER", 257, 56);
      g.fillStyle = "#f1e3cb"; g.fillText("MAD ROASTER", 256, 53);
    });
    const plaqueMesh = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 0.39), new THREE.MeshBasicMaterial({ map: plaque.t, transparent: true }));
    plaqueMesh.position.set(-1.45, 2.2, FZ + 0.085); scene.add(plaqueMesh);
    const disp = label(256, 96, () => {});
    const dctx = disp.c.getContext("2d")!;
    const dispMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.45), new THREE.MeshBasicMaterial({ map: disp.t, transparent: true }));
    dispMesh.position.set(1.55, 2.2, FZ + 0.085); scene.add(dispMesh);
    let lastTemp = -1;
    const drawTemp = (t: number, hot: number) => {
      if (t === lastTemp) return; lastTemp = t;
      dctx.fillStyle = "#0a0605"; dctx.fillRect(0, 0, 256, 96);
      dctx.strokeStyle = "#3b2a1e"; dctx.lineWidth = 4; dctx.strokeRect(2, 2, 252, 92);
      dctx.shadowColor = hot > 0.1 ? "rgba(255,122,42,.85)" : "rgba(232,217,184,.5)"; dctx.shadowBlur = 10; dctx.fillStyle = hot > 0.1 ? "#ff8a3a" : "#e8d9b8"; dctx.font = "700 58px 'Courier New', monospace"; dctx.textAlign = "center"; dctx.textBaseline = "middle";
      dctx.fillText(`${t}°C`, 128, 52); dctx.shadowBlur = 0; disp.t.needsUpdate = true;
    };
    for (const x of [-2.1, 2.1]) {
      const k = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.19, 0.14, 24), chrome);
      k.rotation.x = Math.PI / 2; k.position.set(x, 1.35, FZ + 0.1); scene.add(k);
    }

    /* hopper hanging over the pan on a boom */
    const hopper = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 0.45, 1.5, 48, 1, true), new THREE.MeshStandardMaterial({ color: 0x1a1613, metalness: 0.9, roughness: 0.3, side: THREE.DoubleSide }));
    hopper.position.set(0, TOP + 1.95, 0); scene.add(hopper);
    const hRim = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.05, 12, 64), chrome); hRim.rotation.x = Math.PI / 2; hRim.position.set(0, TOP + 2.7, 0); scene.add(hRim);
    const spout = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 1.2, 24, 1, true), chrome); spout.position.set(0, TOP + 0.75, 0); scene.add(spout);
    const boom = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.38, 3.6), blackMat); boom.position.set(0, TOP + 1.95, -1.5); scene.add(boom);

    /* roasting pan with silver rim */
    const base = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.6, 0.96, 48), blackMat); base.position.y = -0.5; scene.add(base);
    const wall = new THREE.Mesh(new THREE.CylinderGeometry(3.18, 3.02, 0.95, 96, 1, true), blackMat); wall.position.y = 0.38; wall.material = new THREE.MeshStandardMaterial({ color: 0x0d0c0c, metalness: 0.65, roughness: 0.42, side: THREE.DoubleSide }); scene.add(wall);
    const liner = new THREE.Mesh(new THREE.CylinderGeometry(3.02, 3.0, 0.95, 96, 1, true), drumMat); liner.position.y = 0.38; scene.add(liner);
    const pan = new THREE.Mesh(new THREE.CircleGeometry(3.02, 80), drumMat); pan.rotation.x = -Math.PI / 2; pan.position.y = 0.005; scene.add(pan);
    const lip = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.08, 14, 120), chrome); lip.rotation.x = Math.PI / 2; lip.position.y = 0.86; scene.add(lip);
    const band = new THREE.Mesh(new THREE.TorusGeometry(3.17, 0.03, 8, 120), steelLight); band.rotation.x = Math.PI / 2; band.position.y = -0.05; scene.add(band);

    /* stirring arms */
    const arms = new THREE.Group(); scene.add(arms);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.36, 1, 32), chrome); hub.position.y = 0.5; arms.add(hub);
    const hubCap = new THREE.Mesh(new THREE.SphereGeometry(0.26, 24, 16), brass); hubCap.position.y = 1.02; arms.add(hubCap);
    for (let k = 0; k < 3; k++) {
      const a = new THREE.Group(); a.rotation.y = -(k * TAU) / 3; arms.add(a);
      const bar = new THREE.Mesh(new THREE.BoxGeometry(ARM, 0.08, 0.16), chrome); bar.position.set(ARM / 2, 0.74, 0); a.add(bar);
      for (const bx of [0.9, 1.65, 2.4]) {
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.62, 0.06), chrome);
        blade.position.set(bx, 0.42, 0); blade.rotation.y = 0.55; a.add(blade);
      }
    }

    /* beans */
    const bg = lite ? beanGeometry(56, 34) : beanGeometry(72, 44);
    const beanMat = new THREE.MeshPhysicalMaterial({ color: 0xffffff, vertexColors: true, roughness: 0.5, metalness: 0, clearcoat: 0.15, clearcoatRoughness: 0.5, envMapIntensity: 1.0 });
    const beanMesh = new THREE.InstancedMesh(bg, beanMat, N);
    beanMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(N * 3), 3);
    beanMesh.frustumCulled = false; scene.add(beanMesh);
    const rainMesh = new THREE.InstancedMesh(bg, beanMat, RN);
    rainMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(RN * 3), 3);
    rainMesh.frustumCulled = false; scene.add(rainMesh);

    const rnd = Math.random;
    const beans: Bean[] = Array.from({ length: N }, (_, i) => {
      const hero = i === 0;
      const ang = rnd() * 6.28, rr = Math.sqrt(rnd()) * 0.32;
      return {
        pos: new THREE.Vector3(), vel: new THREE.Vector3(), q: new THREE.Quaternion().setFromEuler(new THREE.Euler(rnd() * 6, rnd() * 6, rnd() * 6)), w: new THREE.Vector3(),
        rel: hero ? HERO_REL : 0.085 + (i / N) * 0.12, dur: hero ? HERO_DUR : 0.1 + rnd() * 0.025,
        y0: hero ? 26 : 22 + rnd() * 8, sx: hero ? 0 : Math.cos(ang) * rr, sz: hero ? 0 : Math.sin(ang) * rr,
        jit: rnd() * 2 - 1, size: 0.92 + rnd() * 0.16, mode: 0, inside: false, pop: 0,
        c1: 0.6 + rnd() * 0.12, c2: 0.88 + rnd() * 0.09, hero, touch: false, hadPop: false, tx: 0, tz: 0,
      };
    });
    const rain = Array.from({ length: RN }, () => ({ x: (rnd() - 0.5) * 12, z: (rnd() - 0.5) * 9 - 1, y0: rnd() * 38, sp: 2 + rnd() * 2.2, s: 0.7 + rnd() * 0.7, a: rnd() * 6, b: rnd() * 6 }));

    /* sparks & smoke */
    const SP = 140;
    const spPos = new Float32Array(SP * 3), spVel = new Float32Array(SP * 3), spLife = new Float32Array(SP);
    for (let i = 0; i < SP; i++) spPos[i * 3 + 1] = -999;
    const spGeo = new THREE.BufferGeometry(); spGeo.setAttribute("position", new THREE.BufferAttribute(spPos, 3));
    const sparksPts = new THREE.Points(spGeo, new THREE.PointsMaterial({ color: 0xffa040, size: 0.09, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false }));
    sparksPts.frustumCulled = false; scene.add(sparksPts);
    let spHead = 0;
    const emitSpark = (p: THREE.Vector3, power: number) => {
      for (let k = 0; k < 4; k++) {
        const i = spHead++ % SP;
        spPos[i * 3] = p.x; spPos[i * 3 + 1] = p.y; spPos[i * 3 + 2] = p.z;
        spVel[i * 3] = (rnd() - 0.5) * 4 * power; spVel[i * 3 + 1] = rnd() * 4 * power; spVel[i * 3 + 2] = (rnd() - 0.5) * 4 * power; spLife[i] = 1;
      }
    };
    const smokeTex = label(64, 64, (g) => {
      const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, "rgba(220,210,200,.9)"); gr.addColorStop(1, "rgba(220,210,200,0)");
      g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    }).t;
    const SM = lite ? 60 : 120;
    const smPos = new Float32Array(SM * 3), smLife = new Float32Array(SM);
    for (let i = 0; i < SM; i++) smPos[i * 3 + 1] = -999;
    const smGeo = new THREE.BufferGeometry(); smGeo.setAttribute("position", new THREE.BufferAttribute(smPos, 3));
    const smokePts = new THREE.Points(smGeo, new THREE.PointsMaterial({ map: smokeTex, size: 1.7, transparent: true, opacity: 0.16, depthWrite: false }));
    smokePts.frustumCulled = false; scene.add(smokePts);
    let smHead = 0;

    /* sizing */
    let baseFov = 46;
    const resize = () => {
      const w = el.clientWidth || 1, h = el.clientHeight || 1;
      renderer.setSize(w, h, false);
      camera.aspect = w / h; baseFov = 46; camera.fov = baseFov; camera.updateProjectionMatrix();
    };
    resize();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(resize) : null;
    if (ro) ro.observe(el); else window.addEventListener("resize", resize);
    let perfN = 0, perfAcc = 0, dprNow = renderer.getPixelRatio();
    let visible = false, raf = 0, last = performance.now();

    /* pointer */
    const ptr = { x: 0, y: 0, on: false, down: false };
    const setPtr = (e: PointerEvent) => { const r = renderer.domElement.getBoundingClientRect(); ptr.x = ((e.clientX - r.left) / r.width) * 2 - 1; ptr.y = -((e.clientY - r.top) / r.height) * 2 + 1; ptr.on = true; };
    const onMove = (e: PointerEvent) => setPtr(e);
    const onDown = (e: PointerEvent) => { setPtr(e); ptr.down = true; };
    const onUp = () => { ptr.down = false; };
    const onLeave = () => { ptr.on = false; ptr.down = false; };
    const cv = renderer.domElement;
    cv.addEventListener("pointermove", onMove); cv.addEventListener("pointerdown", onDown); window.addEventListener("pointerup", onUp); cv.addEventListener("pointerleave", onLeave);

    /* camera path */
    const camPos = new THREE.Vector3(), camLook = new THREE.Vector3(), lookNow = new THREE.Vector3(0, 16, 0);
    const heroY = (p: number) => lerp(26, TOP, clamp((p - HERO_REL) / HERO_DUR));
    const fitZ = () => { const t = Math.tan((baseFov * Math.PI) / 360) * camera.aspect; return Math.max(1, 3.9 / t / 9.6); };
    const orbit = (az: number, el: number, dist: number) => camPos.set(Math.sin(az) * Math.cos(el) * dist, Math.sin(el) * dist, Math.cos(az) * Math.cos(el) * dist);
    const path = (p: number, time: number) => {
      const fit = fitZ();
      const mobileZoom = camera.aspect < 0.8 ? 0.78 : 1;
      if (p < HERO_REL) {
        camPos.set(Math.sin(time * 0.3) * 0.3, 4.5, 6.5); camLook.set(0, 16, 0);
      } else if (p < 0.22) {
        const t = (p - HERO_REL) / HERO_DUR, e = ease(t), hy = heroY(p);
        camPos.set(0, lerp(4.5, hy + 2.2, ease(Math.min(1, t * 2.2))), lerp(6.5, 5.4, e));
        camLook.set(0, lerp(16, hy - 1.0, ease(Math.min(1, t * 2))), 0);
      } else if (p < 0.36) {
        const e = ease((p - 0.22) / 0.14);
        orbit(0, 0.8, 14.5 * fit * mobileZoom);
        camPos.set(0, lerp(6.4, camPos.y, e), lerp(5.4, camPos.z, e)); camLook.set(0, lerp(3.2, 1.2, e), 0);
      } else if (p < 0.86) {
        const t = (p - 0.36) / 0.5;
        orbit(Math.sin(t * 2.6) * 0.3, lerp(0.8, 0.92, t) + Math.sin(time * 0.5) * 0.01, lerp(14.5, 13.2, t) * fit * mobileZoom);
        camLook.set(0, 1.2, 0);
      } else {
        const e = ease((p - 0.86) / 0.14);
        const az0 = Math.sin(2.6) * 0.3;
        orbit(lerp(az0, 0.38, e), lerp(0.92, 0.55, e), lerp(13.2, 17.5, e) * fit * mobileZoom);
        camLook.set(0, lerp(1.2, 1.8, e), lerp(0, -1, e));
      }
    };

    /* physics */
    const tmpM = new THREE.Matrix4(), tmpS = new THREE.Vector3(), tmpC = new THREE.Color(), dq = new THREE.Quaternion(), ax = new THREE.Vector3();
    const flatQ = new THREE.Quaternion(), zAx = new THREE.Vector3(), upV = new THREE.Vector3(0, 1, 0), dnV = new THREE.Vector3(0, -1, 0);
    const tmpEuler = new THREE.Euler(), rainPos = new THREE.Vector3(), popColor = new THREE.Color(1, 0.55, 0.2);
    const activeBeans: Bean[] = [];
    let lastColR = -1, simClock = 0, theta = 0, omega = 0, prevR = 0, rJump = 0, lastSpawn = 0, sp = 0;
    const rayO = new THREE.Vector3(), rayD = new THREE.Vector3();
    const BS = 0.55; /* bean scale */

    const popBean = (b: Bean) => {
      if (Math.abs(rJump) > 0.04) return;
      b.pop = 1; b.vel.y += 3 + rnd() * 3.5; b.vel.x += (rnd() - 0.5) * 3; b.vel.z += (rnd() - 0.5) * 2; b.w.x += (rnd() - 0.5) * 12;
      emitSpark(b.pos, 1);
    };

    const stepPhysics = (dt: number, p: number, r: number) => {
      const rad = 0.15;
      const restY = FLOORY + 0.1;
      const now = simClock;
      for (const b of beans) {
        b.pop = Math.max(0, b.pop - dt * 2.6);
        const arrive = b.rel + b.dur;
        if (p < arrive) { b.mode = 0; b.inside = false; continue; }
        if (b.mode === 0) {
          if (now - lastSpawn < 0.012) continue;
          lastSpawn = now; b.mode = 1; b.inside = false; b.pos.set(b.sx, TOP, b.sz); b.vel.set(0, -8, 0);
        }
        const touched = b.touch; b.touch = false;
        b.vel.y -= 22 * dt;
        b.pos.addScaledVector(b.vel, dt);
        b.vel.multiplyScalar(0.9993);
        const ad = Math.exp(-1.2 * dt); b.vel.x *= ad; b.vel.z *= ad;
        if (touched && b.vel.x * b.vel.x + b.vel.y * b.vel.y + b.vel.z * b.vel.z < 0.12) { b.vel.set(0, 0, 0); b.w.set(0, 0, 0); }
        const spd2 = b.vel.x * b.vel.x + b.vel.y * b.vel.y + b.vel.z * b.vel.z;
        b.w.multiplyScalar(Math.exp(-(touched ? 10 : 1.6) * dt));
        if (touched && spd2 < 6) {
          zAx.set(0, 0, 1).applyQuaternion(b.q);
          flatQ.setFromUnitVectors(zAx, zAx.y >= 0 ? upV : dnV).multiply(b.q);
          b.q.slerp(flatQ, 1 - Math.exp(-9 * dt));
        }
        if (prevR < b.c1 && r >= b.c1) popBean(b);
        if (prevR < b.c2 && r >= b.c2) popBean(b);
        // cursor stirs
        if (ptr.on && p > 0.3 && p < 0.9) {
          const wx = b.pos.x - rayO.x, wy = b.pos.y - rayO.y, wz = b.pos.z - rayO.z;
          const t = wx * rayD.x + wy * rayD.y + wz * rayD.z;
          if (t > 0) {
            const ox = wx - rayD.x * t, oy = wy - rayD.y * t, oz = wz - rayD.z * t;
            const d = Math.hypot(ox, oy, oz), reach = 0.9;
            if (d < reach && d > 0.001) {
              const f = (1 - d / reach) * (ptr.down ? 90 : 34) * dt;
              b.vel.x += (ox / d) * f; b.vel.y += (oy / d) * f + (ptr.down ? f * 0.6 : 0); b.vel.z += (oz / d) * f;
              b.w.x += (oz / d) * f * 0.5; b.w.z += (ox / d) * f * 0.5;
              if (ptr.down && b.pop < 0.2 && rnd() < 0.08) { b.pop = 1; emitSpark(b.pos, 0.8); }
            }
          }
        }
        // stirring arms scoop the beans along and toss them up
        if (omega > 0.12 && b.pos.y < 0.95) {
          const r2 = b.pos.x * b.pos.x + b.pos.z * b.pos.z;
          if (r2 < ARM * ARM && r2 > 0.09) {
            const rr = Math.sqrt(r2), phi = Math.atan2(b.pos.z, b.pos.x);
            for (let k = 0; k < 3; k++) {
              let dl = phi - (theta + (k * TAU) / 3); dl -= Math.round(dl / TAU) * TAU;
              if (Math.abs(dl) * rr < 0.3) {
                const tg = omega * rr * 1.15, kk = Math.min(1, 16 * dt);
                b.vel.x += (-Math.sin(phi) * tg - b.vel.x) * kk; b.vel.z += (Math.cos(phi) * tg - b.vel.z) * kk;
                b.vel.y += (34 + rnd() * 18) * dt * (omega / 2);
                b.w.x += (rnd() - 0.5) * 40 * dt; b.w.z += (rnd() - 0.5) * 40 * dt;
                break;
              }
            }
          }
        }
        // pan wall
        const dw = Math.hypot(b.pos.x, b.pos.z);
        if (dw > RB - rad) {
          const nx = b.pos.x / dw, nz = b.pos.z / dw;
          b.pos.x = nx * (RB - rad); b.pos.z = nz * (RB - rad);
          const vn = b.vel.x * nx + b.vel.z * nz;
          if (vn > 0) { b.vel.x -= 1.3 * vn * nx; b.vel.z -= 1.3 * vn * nz; }
        }
        // pan floor
        if (b.pos.y < restY) {
          b.pos.y = restY; b.touch = true;
          if (b.vel.y < -2) {
            const k = Math.min(1, -b.vel.y / 14);
            b.vel.x += (rnd() - 0.5) * 2.2 * k; b.vel.z += (rnd() - 0.5) * 2.2 * k;
            b.vel.y = -b.vel.y * 0.2;
          } else b.vel.y = 0;
          const fr = Math.exp(-2.2 * dt); b.vel.x *= fr; b.vel.z *= fr;
        }
      }
      activeBeans.length = 0;
      for (const bean of beans) if (bean.mode !== 0) activeBeans.push(bean);
      for (let i = 0; i < activeBeans.length; i++) {
        const a = activeBeans[i];
        for (let j = i + 1; j < activeBeans.length; j++) {
          const b = activeBeans[j];
          const dx = b.pos.x - a.pos.x, dy = b.pos.y - a.pos.y, dz = b.pos.z - a.pos.z, md = rad * (a.size + b.size);
          if (Math.abs(dx) > md || Math.abs(dy) > md || Math.abs(dz) > md) continue;
          const d = Math.hypot(dx, dy, dz);
          if (d < md && d > 0.0001) {
            const nx = dx / d, ny = dy / d, nz = dz / d, ov = (md - d) * 0.5;
            a.pos.x -= nx * ov; a.pos.y -= ny * ov; a.pos.z -= nz * ov; b.pos.x += nx * ov; b.pos.y += ny * ov; b.pos.z += nz * ov;
            const vn = (b.vel.x - a.vel.x) * nx + (b.vel.y - a.vel.y) * ny + (b.vel.z - a.vel.z) * nz;
            if (Math.abs(ny) > 0.55) {
              // stacked beans shove each other sideways and spread into an even bed
              const hz = Math.hypot(nx, nz) || 1, ps = (md - d) * 14;
              a.vel.x -= (nx / hz) * ps * dt * 6 * (ny > 0 ? 1 : 0.4); a.vel.z -= (nz / hz) * ps * dt * 6 * (ny > 0 ? 1 : 0.4);
              b.vel.x += (nx / hz) * ps * dt * 6 * (ny < 0 ? 1 : 0.4); b.vel.z += (nz / hz) * ps * dt * 6 * (ny < 0 ? 1 : 0.4);
              a.touch = b.touch = true; const fr = Math.exp(-2 * dt); a.vel.multiplyScalar(fr); b.vel.multiplyScalar(fr); }
            if (vn < 0) { const j2 = vn * 0.55; a.vel.x += nx * j2; a.vel.y += ny * j2; a.vel.z += nz * j2; b.vel.x -= nx * j2; b.vel.y -= ny * j2; b.vel.z -= nz * j2; }
          }
        }
      }
    };

    /* main loop */
    const dbgS = new URLSearchParams(location.search).get("roastp");
    const dbg = dbgS === null ? null : Number(dbgS);
    const loop = (now: number) => {
      raf = 0;
      if (!visible || document.hidden) { last = now; return; }
      const rawMs = now - last;
      const dt = Math.min(0.033, rawMs / 1000); last = now;
      if (++perfN > 45) {
        perfAcc += rawMs;
        if (perfN >= 105) {
          if (perfAcc / 60 > 27 && dprNow > 0.8) { dprNow = Math.max(0.8, dprNow - 0.25); renderer.setPixelRatio(dprNow); resize(); }
          perfN = 45; perfAcc = 0;
        }
      }
      const time = now / 1000;
      if (import.meta.env.DEV && dbg !== null) sp = dbg; else sp += (pRef.current - sp) * Math.min(1, dt * 7);
      const p = sp, r = roastLevel(p), heat = smooth(0.24, 0.4, p) * (1 - smooth(0.9, 0.97, p));
      const hot = smooth(0.1, 0.9, r);

      // camera
      path(p, time);
      const ox = camera.aspect > 1.2 ? -1.9 * smooth(0.2, 0.34, p) : 0;
      camPos.x += ox; camLook.x += ox;
      camera.position.lerp(camPos, p < 0.06 ? 1 : 0.35);
      lookNow.lerp(camLook, 0.35);
      camera.lookAt(lookNow);
      camera.updateMatrixWorld();
      if (ptr.on && p > 0.3 && p < 0.9) {
        rayO.copy(camera.position);
        rayD.set(ptr.x, ptr.y, 0.5).unproject(camera).sub(rayO).normalize();
      }

      // machine
      const wT = 2.0 * smooth(0.3, 0.38, p) * (1 - 0.75 * smooth(0.9, 0.97, p));
      omega += (wT - omega) * Math.min(1, dt * 3); theta += omega * dt; arms.rotation.y = -theta;
      drumMat.emissiveIntensity = 0.22 * hot * heat;
      inner.intensity = 5 * heat * (0.8 + 0.2 * Math.sin(time * 9)); burner.intensity = 3.5 * heat * (0.8 + 0.2 * Math.sin(time * 7.3));
      trayLight.intensity = 40 * smooth(0.9, 0.97, p);
      beanMat.roughness = 0.55 - 0.3 * smooth(0.84, 1, r); beanMat.clearcoat = 0.12 + 0.7 * smooth(0.82, 1, r);
      drawTemp(Math.round(22 + 210 * r), hot);

      // physics
      rJump = r - prevR;
      const sub = dbg !== null ? 40 : 2, sdt = dbg !== null ? 1 / 120 : dt / 2;
      for (let k = 0; k < sub; k++) { simClock += sdt; stepPhysics(sdt, p, r); }
      prevR = r;

      // draw beans
      const rChanged = Math.abs(r - lastColR) > 0.0015; if (rChanged) lastColR = r;
      let colDirty = rChanged;
      const wDecay = Math.pow(0.995, dt * 60);
      for (let i = 0; i < N; i++) {
        const b = beans[i];
        if (b.mode === 0) {
          const s = clamp((p - b.rel) / b.dur);
          if (s <= 0) { tmpS.set(0, 0, 0); } else { tmpS.setScalar(b.hero ? 1.5 * BS : BS); }
          b.pos.set(b.sx, lerp(b.y0, TOP, Math.pow(s, 1.15)), b.sz);
          b.q.setFromEuler(tmpEuler.set(s * 7 + i, s * 5, s * 3 + i * 0.5));
          if (s >= 1) tmpS.set(0, 0, 0);
        } else {
          tmpS.setScalar(BS * (b.hero ? 1.5 : 1) * b.size * (1 + b.pop * 0.16));
          const wl = b.w.length();
          if (wl > 1e-4) { ax.copy(b.w).divideScalar(wl); dq.setFromAxisAngle(ax, wl * dt); b.q.premultiply(dq); }
          b.w.multiplyScalar(wDecay);
        }
        if (b.mode === 0) tmpS.multiplyScalar(b.size);
        tmpM.compose(b.pos, b.q, tmpS); beanMesh.setMatrixAt(i, tmpM);
        if (rChanged || b.pop > 0 || b.hadPop) {
          setRoastColor(tmpC, r + b.jit * 0.05);
          if (b.pop > 0) tmpC.lerp(popColor, b.pop * 0.45);
          beanMesh.setColorAt(i, tmpC); colDirty = true;
          b.hadPop = b.pop > 0;
        }
      }
      beanMesh.instanceMatrix.needsUpdate = true; if (colDirty) beanMesh.instanceColor!.needsUpdate = true;

      // rain
      const rv = 1 - smooth(0.16, 0.22, p);
      rainMesh.visible = rv > 0.01;
      if (rainMesh.visible) {
        setRoastColor(tmpC, 0);
        for (let i = 0; i < RN; i++) {
          const o = rain[i];
          const y = 46 - ((o.y0 + time * o.sp + p * 70) % 40);
          tmpS.setScalar(o.s * rv);
          dq.setFromEuler(tmpEuler.set(o.a + time * 0.8, o.b + time * 0.6, time * 0.5));
          tmpM.compose(rainPos.set(o.x, y, o.z), dq, tmpS); rainMesh.setMatrixAt(i, tmpM); rainMesh.setColorAt(i, tmpC);
        }
        rainMesh.instanceMatrix.needsUpdate = true; rainMesh.instanceColor!.needsUpdate = true;
      }

      // sparks + smoke
      for (let i = 0; i < SP; i++) {
        if (spLife[i] <= 0) { spPos[i * 3 + 1] = -999; continue; }
        spVel[i * 3 + 1] -= 9 * dt; spPos[i * 3] += spVel[i * 3] * dt; spPos[i * 3 + 1] += spVel[i * 3 + 1] * dt; spPos[i * 3 + 2] += spVel[i * 3 + 2] * dt; spLife[i] -= dt * 1.6;
      }
      spGeo.attributes.position.needsUpdate = true;
      const steam = smooth(0.84, 0.92, p);
      if ((heat > 0.1 && rnd() < heat * 0.4) || (steam > 0.01 && rnd() < steam * 0.6)) {
        const i = smHead++ % SM, sa = rnd() * TAU, sr = Math.sqrt(rnd()) * 2.6;
        smPos[i * 3] = Math.cos(sa) * sr; smPos[i * 3 + 1] = 0.9; smPos[i * 3 + 2] = Math.sin(sa) * sr; smLife[i] = 1;
      }
      for (let i = 0; i < SM; i++) {
        if (smLife[i] <= 0) { smPos[i * 3 + 1] = -999; continue; }
        smPos[i * 3 + 1] += 1.1 * dt; smPos[i * 3] += Math.sin(time + i) * 0.2 * dt; smLife[i] -= dt * 0.28;
      }
      smGeo.attributes.position.needsUpdate = true;

      renderer.render(scene, camera);
      raf = requestAnimationFrame(loop);
    };

    const startLoop = () => {
      if (visible && !document.hidden && raf === 0) {
        last = performance.now(); perfN = 0; perfAcc = 0;
        raf = requestAnimationFrame(loop);
      }
    };
    const stopLoop = () => {
      if (raf !== 0) {
        cancelAnimationFrame(raf);
        raf = 0;
      }
    };
    const io = typeof IntersectionObserver !== "undefined"
      ? new IntersectionObserver(([entry]) => {
        visible = entry.isIntersecting;
        if (visible) startLoop(); else stopLoop();
      }, { threshold: 0 })
      : null;
    const onVisibilityChange = () => { if (document.hidden) stopLoop(); else startLoop(); };
    document.addEventListener("visibilitychange", onVisibilityChange);
    if (io) io.observe(el);
    else { visible = true; startLoop(); }

    return () => {
      stopLoop();
      document.removeEventListener("visibilitychange", onVisibilityChange);
      io?.disconnect();
      if (ro) ro.disconnect(); else window.removeEventListener("resize", resize);
      cv.removeEventListener("pointermove", onMove); cv.removeEventListener("pointerdown", onDown); window.removeEventListener("pointerup", onUp); cv.removeEventListener("pointerleave", onLeave);
      const geometries = new Set<THREE.BufferGeometry>();
      const materials = new Set<THREE.Material>();
      scene.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (mesh.geometry && !geometries.has(mesh.geometry)) {
          geometries.add(mesh.geometry);
          mesh.geometry.dispose();
        }
        const list = Array.isArray(mesh.material) ? mesh.material : mesh.material ? [mesh.material] : [];
        for (const material of list) {
          if (materials.has(material)) continue;
          materials.add(material);
          material.dispose();
        }
      });
      plaque.t.dispose(); disp.t.dispose(); face.t.dispose(); smokeTex.dispose();
      environmentTarget.dispose(); pm.dispose(); renderer.dispose(); renderer.forceContextLoss(); renderer.domElement.remove();
    };
  }, [pRef, onFail]);

  return <div ref={host} data-testid="canvas-roast" className="absolute inset-0 w-screen lg:w-full" />;
}

export default memo(RoastScene3D);
