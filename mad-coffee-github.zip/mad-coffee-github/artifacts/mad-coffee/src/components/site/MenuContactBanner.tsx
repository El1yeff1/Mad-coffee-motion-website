import { MessageCircle } from "lucide-react";
import { useLang, type L } from "@/lib/i18n";

const kicker: L = { az: "Söhbətə açığıq", ru: "Открыты к общению", en: "Here to help" };
const title: L = { az: "Qəhvə barədə sualın var?", ru: "Есть вопрос о кофе?", en: "Have a coffee question?" };
const detail: L = {
  az: "Nümunə sosial hesabı — link aktiv deyil.",
  ru: "Демо-аккаунт — ссылка не активна.",
  en: "Sample social handle — link is disabled.",
};
export default function MenuContactBanner() {
  const { tr } = useLang();

  return (
    <div className="mx-auto my-6 w-full max-w-[1600px] px-5 md:hidden">
      <div className="flex items-center gap-3 border-y border-border/80 py-3.5">
        <span className="h-9 w-1 shrink-0 bg-primary/70" aria-hidden="true" />
        <div className="min-w-0 flex-1">
          <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">{tr(kicker)}</span>
          <p className="mt-0.5 font-display text-base leading-tight">{tr(title)}</p>
          <p className="mt-0.5 text-[11px] text-foreground/60">{tr(detail)}</p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-1.5 border border-primary/30 px-3 py-2 font-mono text-[10px] uppercase tracking-wide text-foreground/80">
          <MessageCircle className="h-3.5 w-3.5 text-accent" aria-hidden="true" />
          <span>@mad_coffeeshop</span>
        </span>
      </div>
    </div>
  );
}
