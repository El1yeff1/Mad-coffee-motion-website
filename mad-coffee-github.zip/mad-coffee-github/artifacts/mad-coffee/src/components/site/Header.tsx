import { useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { Menu, X } from "lucide-react";
import CartPanel from "./CartPanel";
import type { BeanSelection, CartLine } from "@/lib/data";
import { LANGS, useLang } from "@/lib/i18n";

type HeaderProps = {
  cart: CartLine[];
  onQuantityChange: (id: string, quantity: number) => void;
  onRemove: (id: string) => void;
  onViewProduct: (selection: BeanSelection) => void;
};

export default function Header({ cart, onQuantityChange, onRemove, onViewProduct }: HeaderProps) {
  const { t, lang, setLang } = useLang();
  const { scrollY } = useScroll();
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const bagCount = cart.reduce((count, item) => count + item.quantity, 0);
  useMotionValueEvent(scrollY, "change", (v) => setSolid(v > 60));
  const links = [["menu", t("navMenu")], ["branches", t("navBranches")], ["about", t("navAbout")], ["beans", t("navBeans")], ["contact", t("navContact")]];
  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${solid ? "bg-background/70 backdrop-blur-md border-b border-border/60" : ""}`}>
      <div className="mx-auto flex h-16 max-w-[1600px] items-center justify-between px-5 md:px-10">
        <span aria-hidden className="hidden w-32 md:block" />
        <nav className="hidden items-center gap-7 md:flex">
          {links.map(([id, l]) => (
            <a key={id} href={`#${id}`} data-testid={`link-nav-${id}`} className="link-u font-mono text-[11px] uppercase tracking-[0.18em] text-foreground/80 hover:text-foreground">{l}</a>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-4 md:ml-0">
          <div className="flex font-mono text-[11px] uppercase">
            {LANGS.map((l) => (
              <button key={l} onClick={() => setLang(l)} data-testid={`button-lang-${l}`} className={`relative px-1.5 py-1 transition-colors ${lang === l ? "text-foreground" : "text-foreground/40 hover:text-foreground/80"}`}>
                {l}
                {lang === l && <motion.span layoutId="lang-dot" className="absolute -bottom-0.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-accent" />}
              </button>
            ))}
          </div>
          <button type="button" onClick={() => setCartOpen(true)} data-testid="button-open-cart"
            aria-label={`${t("bag")} (${bagCount})`} aria-haspopup="dialog" aria-expanded={cartOpen}
            className="font-mono text-[10px] uppercase tracking-wider transition-colors hover:text-accent sm:text-[11px]">
            <span data-testid="text-bag">{t("bag")}({bagCount})</span>
          </button>
          <button className="md:hidden" onClick={() => setOpen(true)} data-testid="button-open-menu" aria-label="menu"><Menu className="h-5 w-5" /></button>
        </div>
      </div>
      {createPortal(
        <AnimatePresence>
          {open && (
            <motion.div
              key="mobile-site-menu"
              id="mobile-site-menu"
              role="dialog"
              aria-modal="true"
              aria-label={t("navMenu")}
              initial={{ clipPath: "circle(0% at 100% 0%)" }}
              animate={{ clipPath: "circle(150% at 100% 0%)" }}
              exit={{ clipPath: "circle(0% at 100% 0%)" }}
              transition={{ duration: 0.6, ease: [0.7, 0, 0.2, 1] }}
              className="fixed inset-0 z-[110] flex min-h-[100dvh] flex-col overflow-y-auto overscroll-contain bg-[hsl(var(--caramel))] p-6 text-background"
            >
              <button className="self-end" onClick={() => setOpen(false)} data-testid="button-close-menu" aria-label="close"><X className="h-6 w-6" /></button>
              <div className="mt-10 flex w-full min-w-0 flex-col gap-4">
                {links.map(([id, l], i) => (
                  <motion.a key={id} href={`#${id}`} onClick={() => setOpen(false)} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.06 }} className="max-w-full font-wordmark text-[clamp(1.5rem,9.5vw,3rem)] leading-[0.95] uppercase">{l}</motion.a>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body,
      )}
      <CartPanel open={cartOpen} onOpenChange={setCartOpen} items={cart} onQuantityChange={onQuantityChange} onRemove={onRemove} onViewProduct={onViewProduct} />
    </header>
  );
}
