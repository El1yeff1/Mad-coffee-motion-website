import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { SiInstagram, SiTiktok, SiWhatsapp } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";
import { useLang } from "@/lib/i18n";
import { Kicker, SplitWords } from "./motion";

export default function ContactSection() {
  const { t } = useLang();
  const { toast } = useToast();
  const [f, setF] = useState({ name: "", email: "", topic: 0, message: "" });
  const [err, setErr] = useState<Record<string, string>>({});
  const topics = t("topics").split("|");
  const contactTitleLines = t("contactTitle").split(". ").map((line, index, lines) =>
    index < lines.length - 1 ? `${line}.` : line,
  );
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (!f.name.trim()) er.name = t("required");
    if (!/^\S+@\S+\.\S+$/.test(f.email)) er.email = t("badEmail");
    if (!f.message.trim()) er.message = t("required");
    setErr(er);
    if (Object.keys(er).length) return;
    toast({ title: t("sent"), description: t("sentD") });
    setF({ name: "", email: "", topic: 0, message: "" });
  };
  const field = "peer w-full border-b border-input bg-transparent pb-2 pt-5 font-display text-xl leading-tight outline-none placeholder:text-transparent focus:border-accent";
  const floatingLabel = "pointer-events-none absolute left-0 top-0 font-mono text-[10px] uppercase tracking-widest text-muted-foreground transition-all duration-200 peer-placeholder-shown:top-3 peer-placeholder-shown:text-sm peer-focus:top-0 peer-focus:text-[10px] peer-focus:text-accent";
  const socials = [
    { icon: SiInstagram, label: "@mad_coffeeshop", id: "instagram" },
    { icon: SiWhatsapp, label: "+994 99 000 00 00", id: "whatsapp" },
    { icon: SiTiktok, label: "@mad_coffeeshop", id: "tiktok" },
  ];
  return (
    <section id="contact" className="relative bg-background/90 py-24 backdrop-blur md:py-40">
      <div className="mx-auto grid max-w-[1600px] gap-16 px-5 md:grid-cols-2 md:px-10">
        <div>
          <Kicker>{t("contactKicker")}</Kicker>
          <h2 className="mt-4 flex flex-col font-display text-[clamp(2rem,10.25vw,2.5rem)] leading-[0.95] md:text-[clamp(2.5rem,5.5vw,4.5rem)]">
            {contactTitleLines.map((line, index) => (
              <span key={`${index}-${line}`} className="block w-max whitespace-nowrap">
                <SplitWords text={line} className="whitespace-nowrap" />
              </span>
            ))}
          </h2>
          <p className="mt-12 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">{t("social")}</p>
          <ul className="mt-4">
            {socials.map((s, i) => (
              <motion.li key={s.id} initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <div data-testid={`text-social-${s.id}`} className="flex items-center gap-4 border-b border-border py-5">
                  <s.icon className="h-6 w-6 text-primary" />
                  <span className="flex-1 font-wordmark text-xl md:text-2xl">{s.label}</span>
                  <span className="font-mono text-[9px] uppercase text-muted-foreground">Demo</span>
                </div>
              </motion.li>
            ))}
          </ul>
        </div>
        <form onSubmit={submit} noValidate className="flex w-full max-w-xl flex-col gap-5 md:pt-16" data-testid="form-contact">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            {(["name", "email"] as const).map((k) => (
              <label key={k} className="relative block">
                <input data-testid={`input-${k}`} type={k === "email" ? "email" : "text"} placeholder=" " value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} className={field} />
                <span className={floatingLabel}>{t(k)}</span>
                {err[k] && <motion.span initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="mt-1 block font-mono text-[11px] text-accent">{err[k]}</motion.span>}
              </label>
            ))}
          </div>
          <div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{t("topic")}</span>
            <div className="mt-3 flex flex-nowrap gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden md:gap-2">
              {topics.map((tp, i) => (
                <button type="button" key={i} onClick={() => setF({ ...f, topic: i })} data-testid={`button-topic-${i}`}
                  className={`shrink-0 whitespace-nowrap rounded-full border px-2 py-2 font-mono text-[9px] uppercase tracking-[0.04em] transition-colors md:px-4 md:text-[11px] md:tracking-normal ${f.topic === i ? "border-primary bg-primary text-background" : "border-border hover:border-primary"}`}>{tp}</button>
              ))}
            </div>
          </div>
          <label className="relative block">
            <textarea data-testid="input-message" rows={3} placeholder=" " value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} className={`${field} resize-none`} />
            <span className={floatingLabel}>{t("message")}</span>
            {err.message && <span className="mt-1 block font-mono text-[11px] text-accent">{err.message}</span>}
          </label>
          <div className="flex justify-end">
            <button type="submit" data-testid="button-send" className="inline-flex min-h-12 items-center gap-4 rounded-full border border-primary/35 bg-primary/5 py-1.5 pl-5 pr-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-foreground hover:border-accent hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background">
              <span>{t("send")}</span>
              <span aria-hidden="true" className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-accent-foreground">
                <ArrowUpRight className="h-4 w-4" />
              </span>
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}
