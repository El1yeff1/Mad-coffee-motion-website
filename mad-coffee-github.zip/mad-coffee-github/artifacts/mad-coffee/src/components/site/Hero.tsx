import { useRef } from "react";
import { motion, useMotionValue, useReducedMotion, useScroll, useSpring, useTransform, type MotionValue } from "framer-motion";
import { ArrowDown } from "lucide-react";
import { img, useLang } from "@/lib/i18n";

function Letter({ ch, i, mx, my, prog }: { ch: string; i: number; mx: MotionValue<number>; my: MotionValue<number>; prog: MotionValue<number> }) {
  const ref = useRef<HTMLSpanElement>(null);
  const push = useTransform([mx, my], ([x, y]: number[]) => {
    const el = ref.current; if (!el) return 0;
    const r = el.getBoundingClientRect();
    const dx = x - (r.left + r.width / 2), dy = y - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy);
    return d < 260 ? (1 - d / 260) : 0;
  });
  const s = useSpring(push, { stiffness: 220, damping: 18 });
  const yy = useTransform(s, (v) => -v * 40);
  const sk = useTransform(s, (v) => v * -10);
  const scrollY = useTransform(prog, [0, 1], [0, (i % 2 ? 1 : -1) * 90]);
  const sy = useTransform([yy, scrollY], ([a, b]: number[]) => a + b);
  const color = useTransform(s, [0, 1], ["hsl(36 45% 86%)", "hsl(12 92% 54%)"]);
  return (
    <motion.span ref={ref} className="inline-block" style={{ y: sy, skewX: sk, color }}
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 + i * 0.05, duration: 0.8 }}>
      {ch === " " ? "\u00A0" : ch}
    </motion.span>
  );
}

export default function Hero() {
  const { t, lang } = useLang();
  const heroTagParts = lang === "ru" || lang === "en" ? t("heroTag").split("? ") : [];
  const reduce = useReducedMotion();
  const ref = useRef<HTMLElement>(null);
  const mx = useMotionValue(-999), my = useMotionValue(-999);
  const cx = useSpring(useMotionValue(0), { stiffness: 60, damping: 20 });
  const cy = useSpring(useMotionValue(0), { stiffness: 60, damping: 20 });
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const cupY = useTransform(scrollYProgress, [0, 1], [0, 260]);
  const cupRot = useTransform(scrollYProgress, [0, 1], [0, -6]);
  const cupScale = useTransform(scrollYProgress, [0, 1], [1, 0.8]);
  const tagY = useTransform(scrollYProgress, [0, 1], [0, -160]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const word = "MAD";

  return (
    <section ref={ref} id="home" className="relative flex min-h-[100svh] flex-col items-center justify-between overflow-hidden px-4 pb-5 pt-20 sm:min-h-[100dvh] sm:pb-6 sm:pt-24"
      onPointerMove={(e) => { if (reduce) return; mx.set(e.clientX); my.set(e.clientY); cx.set((e.clientX / innerWidth - 0.5) * 30); cy.set((e.clientY / innerHeight - 0.5) * 20); }}
      onPointerLeave={() => { mx.set(-999); my.set(-999); }}>
      <motion.div style={{ y: tagY, opacity: fade }} className="relative z-10 text-center">
        <motion.h1 initial={{ opacity: 0, y: 40, filter: "blur(8px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          data-testid="text-hero-tagline" className="font-display text-[clamp(2.4rem,6.8vw,6.8rem)] font-medium leading-[0.95] tracking-tight text-[hsl(var(--cream))]">
          {heroTagParts.length === 2 ? (
            <>
              <span>{heroTagParts[0]}?</span>
              <span className="hidden sm:inline"> </span>
              <span className="block sm:inline">{heroTagParts[1]}</span>
            </>
          ) : t("heroTag")}
        </motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }} className="mx-auto mt-4 max-w-md font-mono text-[11px] uppercase tracking-[0.2em] text-[hsl(var(--cream))]/70">
          {t("heroSub")}
        </motion.p>
      </motion.div>

      <motion.div style={{ x: cx, rotateY: cx, y: cupY, rotate: cupRot, scale: cupScale }} className="relative z-10 top-0 -mb-[12vw] mt-0 w-[min(64vw,560px)] sm:top-[2vw] sm:-mb-[15vw] sm:w-[min(68vw,580px)] [perspective:800px]">
        <motion.svg aria-hidden viewBox="0 0 400 400" className="pointer-events-none absolute left-1/2 top-[60%] w-[112%] -translate-x-1/2 -translate-y-1/2 text-[hsl(var(--cream))]/45"
          animate={{ rotate: 360 }} transition={{ duration: 50, repeat: Infinity, ease: "linear" }}>
          <defs><path id="ring" d="M200,200 m-170,0 a170,170 0 1,1 340,0 a170,170 0 1,1 -340,0" /></defs>
          <text fill="currentColor" fontFamily="JetBrains Mono, monospace" fontSize="15" letterSpacing="7" textLength="1065" lengthAdjust="spacing">
            <textPath href="#ring">MAD COFFEE ✦ BAKI ✦ ESPRESSO BAR ✦ MAD COFFEE ✦ BAKI ✦ ESPRESSO BAR ✦</textPath>
          </text>
        </motion.svg>
        {/* surface the cup rests on: warm light pool, contact shadow, reflection */}
        <div aria-hidden className="pointer-events-none absolute left-1/2 top-[90%] h-[26%] w-[190%] -translate-x-1/2 rounded-[50%] blur-xl"
          style={{ background: "radial-gradient(ellipse at center, hsla(30,70%,60%,0.28) 0%, hsla(24,50%,30%,0.14) 45%, transparent 70%)" }} />
        <div aria-hidden className="pointer-events-none absolute left-1/2 top-[88%] h-[11%] w-[112%] -translate-x-1/2 rounded-[50%] blur-md"
          style={{ background: "radial-gradient(ellipse at center, rgba(8,3,1,0.95) 0%, rgba(8,3,1,0.7) 40%, transparent 72%)" }} />
        <img aria-hidden src={img("hero-espresso.png")} alt="" className="pointer-events-none absolute left-0 top-[93%] w-full -scale-y-100 opacity-30 blur-[1.5px]"
          style={{ WebkitMaskImage: "linear-gradient(to top, rgba(0,0,0,0.9), transparent 38%)", maskImage: "linear-gradient(to top, rgba(0,0,0,0.9), transparent 38%)" }} />
        <motion.img initial={{ opacity: 0, y: 80, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 1.4, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          src={img("hero-espresso.png")} alt="Mad espresso" data-testid="img-hero-cup" className="relative w-full drop-shadow-[0_18px_22px_rgba(10,4,1,0.55)]" />
        <motion.div style={{ y: cy }} className="absolute -right-6 top-6 hidden rotate-12 rounded-full border border-[hsl(var(--cream))]/40 px-3 py-1 font-mono text-[10px] uppercase text-[hsl(var(--cream))] md:block">18g / 28s</motion.div>
      </motion.div>

      <div className="relative z-20 w-full -translate-y-[5vw] select-none text-center sm:translate-y-[4vw]" data-hover>
        <div className="origin-bottom scale-y-[1.3] whitespace-nowrap font-wordmark text-[clamp(3.5rem,19vw,25rem)] leading-[0.74] tracking-[-0.04em]" aria-label="MAD COFFEE">
          {word.split("").map((c, i) => <Letter key={i} ch={c} i={i} mx={mx} my={my} prog={scrollYProgress} />)}
        </div>
        <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1, duration: 1, ease: [0.7, 0, 0.2, 1] }} className="mt-3 flex origin-left flex-wrap items-center justify-between gap-x-3 gap-y-2 border-t border-[hsl(var(--cream))]/30 pt-3 font-mono text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--cream))]/70 sm:text-[10px] sm:tracking-[0.25em] md:text-[11px]">
          <span>Coffee — Bakı, 40.37°N</span>
          <a href="#menu" className="flex items-center gap-2 hover:text-accent" data-testid="link-scroll-down">{t("scroll")} <ArrowDown className="h-3 w-3 animate-bounce" /></a>
          <span className="hidden sm:inline">@mad_coffeeshop</span>
        </motion.div>
      </div>
    </section>
  );
}
