import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { useLang, type L } from "@/lib/i18n";

/* ---------- copy ---------- */
const STEPS: { t: L; d: L; from: number }[] = [
  { from: 0, t: { az: "Yaşıl dənələr", ru: "Зелёные зёрна", en: "Green beans" }, d: { az: "Xam dənələr yuxarıdan qovurma barabanına tökülür.", ru: "Сырые зёрна сыплются сверху в барабан.", en: "Raw beans pour from above into the drum." } },
  { from: 0.14, t: { az: "Qurutma", ru: "Сушка", en: "Drying" }, d: { az: "Rütubət buxara çevrilir, yaşıl rəng solur.", ru: "Влага уходит паром, зелень блёкнет.", en: "Moisture leaves as steam and the green fades." } },
  { from: 0.362, t: { az: "Maillard reaksiyası", ru: "Реакция Майяра", en: "Maillard" }, d: { az: "Şəkərlər və amin turşuları görüşür — aromat doğulur.", ru: "Сахара встречают аминокислоты — рождается аромат.", en: "Sugars meet amino acids and the aroma is born." } },
  { from: 0.569, t: { az: "Birinci çatlama", ru: "Первый крэк", en: "First crack" }, d: { az: "196°C-də dənələr popkorn kimi çatlayır.", ru: "При 196°C зёрна трескаются, как попкорн.", en: "At 196°C the beans crack like popcorn." } },
  { from: 0.688, t: { az: "İnkişaf", ru: "Развитие", en: "Development" }, d: { az: "Dad burada həll olunur: saniyələr hər şeyi dəyişir.", ru: "Здесь решается вкус: секунды меняют всё.", en: "Flavour is decided here: seconds change everything." } },
  { from: 0.776, t: { az: "İkinci çatlama", ru: "Второй крэк", en: "Second crack" }, d: { az: "Yağlar səthə çıxır. Biz adətən bu xəttdən əvvəl dayanırıq.", ru: "Масла выходят на поверхность. Мы обычно тормозим раньше.", en: "Oils surface. We usually stop right before this line." } },
  { from: 0.88, t: { az: "Soyutma", ru: "Охлаждение", en: "Cooling" }, d: { az: "Dənələr dərhal soyudulur və qablaşdırılır. Bakıda qovrulub.", ru: "Зёрна мгновенно остужаются и упаковываются. Обжарено в Баку.", en: "Beans are cooled instantly and packed. Roasted in Baku." } },
];
const UI = {
  kicker: { az: "Qovurxana", ru: "Обжарочная", en: "The roastery" } as L,
  temp: { az: "Temperatur", ru: "Температура", en: "Temp" } as L,
  time: { az: "Vaxt", ru: "Время", en: "Time" } as L,
  level: { az: "Qovurma", ru: "Обжарка", en: "Roast" } as L,
  hint: { az: "Dənələrin üstündə kursoru gəzdir. Klikləsən qarışdırırsan.", ru: "Води курсором по зёрнам. Клик — перемешать.", en: "Move over the beans. Click to stir them." } as L,
  scrollHint: { az: "Qovurmaq üçün scroll et", ru: "Скролль, чтобы жарить", en: "Scroll to roast" } as L,
  lv: [
    { az: "Yaşıl", ru: "Зелёная", en: "Green" },
    { az: "Açıq", ru: "Светлая", en: "Light" },
    { az: "Orta", ru: "Средняя", en: "Medium" },
    { az: "Tünd", ru: "Тёмная", en: "Dark" },
  ] as L[],
};

/* ---------- helpers ---------- */
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const smooth = (a: number, b: number, v: number) => { const t = clamp((v - a) / (b - a)); return t * t * (3 - 2 * t); };
const STOPS: [number, number[]][] = [
  [0, [118, 138, 66]], [0.22, [178, 166, 72]], [0.42, [170, 117, 58]], [0.62, [126, 77, 36]], [0.8, [84, 49, 26]], [1, [40, 23, 13]],
];
function roastRGB(r: number): number[] {
  r = clamp(r);
  for (let i = 1; i < STOPS.length; i++) {
    if (r <= STOPS[i][0]) {
      const [a, ca] = STOPS[i - 1], [b, cb] = STOPS[i];
      const t = (r - a) / (b - a);
      return ca.map((c, k) => c + (cb[k] - c) * t);
    }
  }
  return STOPS[STOPS.length - 1][1];
}
const rgb = (c: number[], m = 1, a = 1) => `rgba(${Math.min(255, c[0] * m) | 0},${Math.min(255, c[1] * m) | 0},${Math.min(255, c[2] * m) | 0},${a})`;
const rOf = (p: number) => clamp((p - 0.14) / 0.74);
const stepOf = (p: number) => { let s = 0; STEPS.forEach((st, i) => { if (p >= st.from) s = i; }); return s; };
const fmtTime = (r: number) => { const s = Math.round(r * 750); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };

type Bean = {
  x: number; y: number; vx: number; vy: number; a: number; av: number;
  rel: number; jit: number; sz: number; pop: number; active: boolean; inside: boolean; c1: number; c2: number; sx: number;
};
type Spark = { x: number; y: number; vx: number; vy: number; life: number };
type Smoke = { x: number; y: number; vx: number; vy: number; r: number; life: number };

const N = 84;

/* ---------- canvas ---------- */
function RoastCanvas({ pRef }: { pRef: React.MutableRefObject<number> }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current!;
    const ctx = cv.getContext("2d")!;
    let W = 0, H = 0, dpr = 1;
    const beans: Bean[] = Array.from({ length: N }, (_, i) => ({
      x: 0, y: -999, vx: 0, vy: 0, a: Math.random() * 6.28, av: 0,
      rel: 0.02 + (i / N) * 0.11 + Math.random() * 0.004, jit: Math.random() * 2 - 1, sz: 0.92 + Math.random() * 0.16,
      pop: 0, active: false, inside: false, c1: 0.6 + Math.random() * 0.12, c2: 0.88 + Math.random() * 0.09, sx: Math.random() * 2 - 1,
    }));
    const sparks: Spark[] = [];
    const smoke: Smoke[] = [];
    const ptr = { x: -999, y: -999, down: false };
    let rJump = 0, theta = 0, omega = 0, prevR = 0, last = performance.now(), raf = 0, visible = false;

    const resize = () => {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      W = cv.clientWidth; H = cv.clientHeight;
      cv.width = Math.max(2, W * dpr); cv.height = Math.max(2, H * dpr);
    };
    const geom = () => {
      const R = Math.min(W * 0.4, H * 0.34);
      const cx = W / 2, cy = H * 0.47;
      return { R, cx, cy, rb: R * 0.07, u: R / 220, floor: cy + R + R * 0.3 };
    };
    resize();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(resize) : null;
    if (ro) ro.observe(cv); else window.addEventListener("resize", resize);

    const toLocal = (e: PointerEvent) => { const r = cv.getBoundingClientRect(); ptr.x = e.clientX - r.left; ptr.y = e.clientY - r.top; };
    const onMove = (e: PointerEvent) => toLocal(e);
    const onDown = (e: PointerEvent) => {
      toLocal(e); ptr.down = true;
      const { u } = geom();
      for (const b of beans) {
        if (!b.active) continue;
        const d = Math.hypot(b.x - ptr.x, b.y - ptr.y);
        if (d < 70 * u * 1.6) { b.pop = 1; b.vy -= 220 * u; for (let k = 0; k < 3; k++) sparks.push({ x: b.x, y: b.y, vx: (Math.random() - 0.5) * 260 * u, vy: -Math.random() * 260 * u, life: 1 }); }
      }
    };
    const onUp = () => { ptr.down = false; };
    const onLeave = () => { ptr.x = -999; ptr.y = -999; ptr.down = false; };
    cv.addEventListener("pointermove", onMove); cv.addEventListener("pointerdown", onDown);
    window.addEventListener("pointerup", onUp); cv.addEventListener("pointerleave", onLeave);

    const pop = (b: Bean, u: number) => {
      if (Math.abs(rJump) > 0.04) return;
      b.pop = 1; b.vy -= (240 + Math.random() * 260) * u; b.vx += (Math.random() - 0.5) * 320 * u; b.av += (Math.random() - 0.5) * 12;
      for (let k = 0; k < 4 && sparks.length < 90; k++) sparks.push({ x: b.x, y: b.y, vx: (Math.random() - 0.5) * 360 * u, vy: -Math.random() * 340 * u, life: 1 });
    };

    const step = (dt: number, p: number, r: number, open: boolean) => {
      const { R, cx, cy, rb, u, floor } = geom();
      const g = 1000 * u;
      const s = 1 + 0.26 * smooth(0.4, 0.9, r);
      const rad = rb * 0.74 * s;
      const trayHalf = R * 1.05;
      const wallV = omega * R * 0.92;
      for (const b of beans) {
        b.pop = Math.max(0, b.pop - dt * 2.6);
        const should = p >= b.rel;
        if (should && !b.active) { b.active = true; b.inside = false; b.x = cx + b.sx * R * 0.2; b.y = -rb * 2 - Math.random() * 40; b.vx = 0; b.vy = 40 * u; }
        if (!should && b.active) { b.active = false; b.y = -999; b.inside = false; }
        if (!b.active) continue;
        if (!open && b.y > cy + R) { b.inside = true; b.x = cx + (Math.random() - 0.5) * R * 0.5; b.y = cy + R * 0.55; b.vx = 0; b.vy = 0; }
        b.vy += g * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.a += b.av * dt; b.av *= 0.995; b.vx *= 0.9992;
        if (prevR < b.c1 && r >= b.c1) pop(b, u);
        if (prevR < b.c2 && r >= b.c2) pop(b, u);
        // cursor stirs the beans
        const px = b.x - ptr.x, py = b.y - ptr.y, pd = Math.hypot(px, py);
        const reach = 110 * u * 1.4;
        if (pd < reach && pd > 0.01) {
          const f = (1 - pd / reach) * (ptr.down ? 2600 : 900) * u * dt;
          b.vx += (px / pd) * f; b.vy += (py / pd) * f;
          if (ptr.down) { b.vx += (-py / pd) * f * 0.8; b.vy += (px / pd) * f * 0.8; }
          b.av += (px / pd) * f * 0.02;
        }
        if (!open) {
          const dx = b.x - cx, dy = b.y - cy, d = Math.hypot(dx, dy);
          if (!b.inside && d < R - rad && b.y > cy - R * 0.5) b.inside = true;
          if (b.inside && d > R - rad) {
            const nx = dx / d, ny = dy / d;
            b.x = cx + nx * (R - rad); b.y = cy + ny * (R - rad);
            const vn = b.vx * nx + b.vy * ny;
            if (vn > 0) { b.vx -= 1.35 * vn * nx; b.vy -= 1.35 * vn * ny; }
            const tx = -ny, ty = nx;
            const vt = b.vx * tx + b.vy * ty;
            const dv = (wallV - vt) * 0.07;
            b.vx += tx * dv; b.vy += ty * dv; b.av += dv / rad * 0.6;
          }
        } else {
          if (b.y > floor - rad) { b.y = floor - rad; b.vy *= -0.22; b.vx *= 0.86; b.av *= 0.9; }
          if (b.x < cx - trayHalf + rad) { b.x = cx - trayHalf + rad; b.vx *= -0.3; }
          if (b.x > cx + trayHalf - rad) { b.x = cx + trayHalf - rad; b.vx *= -0.3; }
        }
      }
      // bean to bean
      for (let i = 0; i < N; i++) {
        const a = beans[i]; if (!a.active || a.y < -rb) continue;
        for (let j = i + 1; j < N; j++) {
          const b = beans[j]; if (!b.active || b.y < -rb) continue;
          const dx = b.x - a.x, dy = b.y - a.y, md = rad * (a.sz + b.sz);
          if (Math.abs(dx) > md || Math.abs(dy) > md) continue;
          const d = Math.hypot(dx, dy);
          if (d < md && d > 0.001) {
            const nx = dx / d, ny = dy / d, ov = (md - d) * 0.5;
            a.x -= nx * ov; a.y -= ny * ov; b.x += nx * ov; b.y += ny * ov;
            const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
            if (vn < 0) { const j2 = vn * 0.6; a.vx += nx * j2; a.vy += ny * j2; b.vx -= nx * j2; b.vy -= ny * j2; }
          }
        }
      }
    };

    const draw = (t: number, p: number, r: number) => {
      const { R, cx, cy, rb, u, floor } = geom();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const open = p > 0.88;
      const heat = smooth(0.06, 0.4, p) * (1 - smooth(0.88, 0.97, p));
      const hot = smooth(0.1, 0.9, r);

      // heat glow
      const gl = ctx.createRadialGradient(cx, cy + R * 0.2, R * 0.2, cx, cy + R * 0.2, R * 1.9);
      gl.addColorStop(0, `rgba(255,${110 + hot * 20 | 0},40,${0.1 + heat * 0.38})`);
      gl.addColorStop(0.5, `rgba(180,60,20,${heat * 0.13})`);
      gl.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = gl; ctx.fillRect(0, 0, W, H);

      // cooling tray
      const trayA = smooth(0.84, 0.9, p);
      if (trayA > 0) {
        ctx.save(); ctx.globalAlpha = trayA;
        const tw = R * 1.05, ty = floor;
        ctx.beginPath(); ctx.moveTo(cx - tw - 14, ty - 26); ctx.lineTo(cx - tw, ty + 14); ctx.lineTo(cx + tw, ty + 14); ctx.lineTo(cx + tw + 14, ty - 26);
        ctx.strokeStyle = "rgba(210,190,160,.55)"; ctx.lineWidth = 3; ctx.stroke();
        const tg = ctx.createLinearGradient(0, ty - 26, 0, ty + 14); tg.addColorStop(0, "rgba(255,255,255,.04)"); tg.addColorStop(1, "rgba(255,255,255,.14)");
        ctx.fillStyle = tg; ctx.fill();
        ctx.fillStyle = "rgba(210,190,160,.35)";
        for (let k = -9; k <= 9; k++) { ctx.beginPath(); ctx.arc(cx + (k * tw) / 9.6, ty + 6, 2.2, 0, 6.28); ctx.fill(); }
        ctx.restore();
      }

      // funnel
      const gapA = 0.4, gh = R * Math.sin(gapA), gy = cy - R * Math.cos(gapA);
      ctx.beginPath(); ctx.moveTo(cx - R * 0.95, gy - R * 0.75); ctx.lineTo(cx - gh, gy); ctx.moveTo(cx + R * 0.95, gy - R * 0.75); ctx.lineTo(cx + gh, gy);
      ctx.strokeStyle = "rgba(210,190,160,.4)"; ctx.lineWidth = R * 0.025; ctx.lineCap = "round"; ctx.stroke();

      // flames
      if (heat > 0.02) {
        for (let i = 0; i < 11; i++) {
          const fx = cx + ((i - 5) / 5) * R * 0.62, fy = cy + R + R * 0.1;
          const fh = R * (0.06 + 0.2 * heat) * (0.65 + 0.35 * Math.sin(t * 0.011 + i * 1.7)) * (1 - Math.abs(i - 5) / 9);
          const fg = ctx.createLinearGradient(0, fy, 0, fy + fh);
          fg.addColorStop(0, "rgba(255,200,90,.9)"); fg.addColorStop(0.5, "rgba(255,90,30,.6)"); fg.addColorStop(1, "rgba(255,60,20,0)");
          ctx.beginPath(); ctx.moveTo(fx - R * 0.025, fy); ctx.quadraticCurveTo(fx, fy + fh * 1.3, fx + R * 0.025, fy); ctx.fillStyle = fg; ctx.fill();
        }
      }

      // drum interior + vanes
      ctx.save(); ctx.globalAlpha = 1 - trayA * 0.7;
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, 6.28); ctx.fillStyle = "rgba(12,6,3,.78)"; ctx.fill();
      ctx.strokeStyle = "rgba(210,190,160,.14)"; ctx.lineWidth = R * 0.03;
      for (let k = 0; k < 4; k++) {
        const an = theta + (k * Math.PI) / 2;
        ctx.beginPath(); ctx.moveTo(cx + Math.cos(an) * R * 0.74, cy + Math.sin(an) * R * 0.74); ctx.lineTo(cx + Math.cos(an) * R * 0.97, cy + Math.sin(an) * R * 0.97); ctx.stroke();
      }
      ctx.restore();

      // beans
      const s = 1 + 0.26 * smooth(0.4, 0.9, r);
      const oil = smooth(0.84, 1, r);
      for (const b of beans) {
        if (!b.active) continue;
        const col = roastRGB(r + b.jit * 0.05);
        const sc = rb * s * b.sz * (1 + b.pop * 0.18);
        ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.a);
        const g = ctx.createRadialGradient(-sc * 0.3, -sc * 0.3, sc * 0.1, 0, 0, sc * 1.05);
        g.addColorStop(0, rgb(col, 1.4)); g.addColorStop(0.55, rgb(col, 1)); g.addColorStop(1, rgb(col, 0.55));
        ctx.beginPath(); ctx.ellipse(0, 0, sc, sc * 0.68, 0, 0, 6.28); ctx.fillStyle = g; ctx.fill();
        ctx.beginPath(); ctx.moveTo(-sc * 0.85, 0); ctx.bezierCurveTo(-sc * 0.3, -sc * 0.28, sc * 0.3, sc * 0.28, sc * 0.85, 0);
        ctx.strokeStyle = rgb(col, 0.3, 0.9); ctx.lineWidth = Math.max(1, sc * 0.1); ctx.lineCap = "round"; ctx.stroke();
        if (oil > 0) { ctx.beginPath(); ctx.ellipse(-sc * 0.28, -sc * 0.26, sc * 0.4, sc * 0.14, -0.4, 0, 6.28); ctx.fillStyle = `rgba(255,235,200,${0.22 * oil})`; ctx.fill(); }
        if (b.pop > 0) { ctx.beginPath(); ctx.ellipse(0, 0, sc * 1.1, sc * 0.78, 0, 0, 6.28); ctx.strokeStyle = `rgba(255,190,90,${b.pop * 0.9})`; ctx.lineWidth = 2; ctx.stroke(); }
        ctx.restore();
      }

      // drum ring with opening at the top
      ctx.save(); ctx.globalAlpha = 1 - trayA * 0.75;
      ctx.beginPath(); ctx.arc(cx, cy, R, -Math.PI / 2 + gapA, -Math.PI / 2 - gapA + Math.PI * 2);
      const rg = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R); rg.addColorStop(0, "#9a8670"); rg.addColorStop(0.5, "#3b2c20"); rg.addColorStop(1, "#8a7560");
      ctx.strokeStyle = rg; ctx.lineWidth = R * 0.07; ctx.lineCap = "round";
      ctx.shadowColor = `rgba(255,110,40,${0.7 * heat})`; ctx.shadowBlur = 24 * heat; ctx.stroke(); ctx.shadowBlur = 0;
      ctx.fillStyle = "rgba(235,215,185,.8)";
      for (let k = 0; k < 28; k++) {
        const an = theta + (k * Math.PI * 2) / 28, rx = cx + Math.cos(an) * R, ry = cy + Math.sin(an) * R;
        if (Math.abs(((an + Math.PI / 2) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2)) < gapA || Math.abs(((an + Math.PI / 2) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI * 2) < gapA) continue;
        ctx.beginPath(); ctx.arc(rx, ry, R * 0.011, 0, 6.28); ctx.fill();
      }
      ctx.restore();

      // smoke
      for (const m of smoke) {
        const sg = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, m.r);
        sg.addColorStop(0, `rgba(210,200,190,${0.14 * m.life})`); sg.addColorStop(1, "rgba(210,200,190,0)");
        ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(m.x, m.y, m.r, 0, 6.28); ctx.fill();
      }
      // sparks
      for (const k of sparks) { ctx.fillStyle = `rgba(255,${170 + 60 * (1 - k.life) | 0},70,${k.life})`; ctx.beginPath(); ctx.arc(k.x, k.y, 1 + 1.2 * k.life, 0, 6.28); ctx.fill(); }
      void u;
    };

    const loop = (now: number) => {
      raf = 0;
      if (!visible || document.hidden) { last = now; return; }
      const dt = Math.min(0.033, (now - last) / 1000); last = now;
      const p = pRef.current, r = rOf(p), open = p > 0.88;
      const { R, cx, cy, u } = geom();
      const wTarget = 1.5 * smooth(0.1, 0.2, p) * (1 - smooth(0.86, 0.9, p));
      omega += (wTarget - omega) * Math.min(1, dt * 3); theta += omega * dt;
      rJump = r - prevR;
      const n = 2;
      for (let i = 0; i < n; i++) step(dt / n, p, r, open);
      prevR = r;
      // smoke + sparks
      const heat = smooth(0.1, 0.4, p) * (1 - smooth(0.9, 0.98, p));
      if (smoke.length < 70 && Math.random() < heat * 0.55) smoke.push({ x: cx + (Math.random() - 0.5) * R * 0.5, y: cy - R * 0.9, vx: (Math.random() - 0.5) * 20 * u, vy: -(50 + Math.random() * 70) * u, r: 14 * u + Math.random() * 14 * u, life: 1 });
      for (let i = smoke.length - 1; i >= 0; i--) { const m = smoke[i]; m.x += (m.vx + Math.sin(now * 0.002 + i) * 14 * u) * dt; m.y += m.vy * dt; m.r += 22 * u * dt; m.life -= dt * 0.35; if (m.life <= 0) smoke.splice(i, 1); }
      for (let i = sparks.length - 1; i >= 0; i--) { const k = sparks[i]; k.vy += 900 * u * dt; k.x += k.vx * dt; k.y += k.vy * dt; k.life -= dt * 1.8; if (k.life <= 0) sparks.splice(i, 1); }
      draw(now, p, r);
      raf = requestAnimationFrame(loop);
    };
    const startLoop = () => {
      if (visible && !document.hidden && raf === 0) {
        last = performance.now();
        raf = requestAnimationFrame(loop);
      }
    };
    const stopLoop = () => {
      if (raf !== 0) {
        cancelAnimationFrame(raf);
        raf = 0;
      }
    };
    const io = typeof IntersectionObserver !== "undefined"
      ? new IntersectionObserver(([entry]) => {
        visible = entry.isIntersecting;
        if (visible) startLoop(); else stopLoop();
      }, { threshold: 0 })
      : null;
    const onVisibilityChange = () => { if (document.hidden) stopLoop(); else startLoop(); };
    document.addEventListener("visibilitychange", onVisibilityChange);
    if (io) io.observe(cv);
    else { visible = true; startLoop(); }
    return () => {
      stopLoop();
      document.removeEventListener("visibilitychange", onVisibilityChange);
      io?.disconnect();
      if (ro) ro.disconnect(); else window.removeEventListener("resize", resize);
      cv.removeEventListener("pointermove", onMove); cv.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp); cv.removeEventListener("pointerleave", onLeave);
    };
  }, [pRef]);
  return <canvas ref={ref} data-testid="canvas-roast" className="block h-full w-full touch-pan-y" />;
}

/* ---------- section ---------- */
export default function RoastSection2D() {
  const { tr } = useLang();
  const ref = useRef<HTMLElement>(null);
  const pRef = useRef(0);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const [p, setP] = useState(0);
  useMotionValueEvent(scrollYProgress, "change", (v) => { pRef.current = clamp(v); setP(Math.round(clamp(v) * 400) / 400); });
  useEffect(() => { pRef.current = clamp(scrollYProgress.get()); }, [scrollYProgress]);

  const r = rOf(p);
  const si = stepOf(p);
  const next = STEPS[si + 1]?.from ?? 1;
  const frac = clamp((p - STEPS[si].from) / (next - STEPS[si].from));
  const temp = Math.round(22 + 210 * r);
  const lv = r < 0.12 ? 0 : r < 0.5 ? 1 : r < 0.78 ? 2 : 3;
  const wordCol = rgb(roastRGB(r).map((v) => Math.max(v * 1.7, 120)), 1);

  return (
    <section ref={ref} id="roast" className="relative h-[520vh] w-screen bg-[hsl(24_30%_5%)] lg:w-full">
      <div className="sticky top-0 grid h-[100dvh] w-screen grid-rows-[auto_minmax(0,1fr)] overflow-hidden lg:w-full lg:grid-cols-[minmax(0,0.95fr)_minmax(0,1.1fr)] lg:grid-rows-1">
        <div className="relative z-10 flex flex-col justify-center gap-4 px-5 pt-20 md:px-10 lg:gap-7 lg:pt-0">
          <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-[hsl(var(--cream))]/60">{tr(UI.kicker)}</div>
          <h2 className="font-wordmark text-[clamp(2.1rem,5vw,4.8rem)] font-black leading-[0.9] tracking-[-0.06em] text-[hsl(var(--cream))]" data-testid="text-roast-title">
            We <span style={{ color: wordCol }} className="italic transition-colors duration-200">roast</span> coffee.
          </h2>

          <div className="min-h-[5.5rem] lg:min-h-[8rem]">
            <AnimatePresence mode="wait">
              <motion.div key={si} initial={{ opacity: 0, y: 18, filter: "blur(6px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} exit={{ opacity: 0, y: -14, filter: "blur(6px)" }} transition={{ duration: 0.35 }}>
                <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-accent">{String(si + 1).padStart(2, "0")} / {String(STEPS.length).padStart(2, "0")}</div>
                <div className="mt-1 font-wordmark text-2xl uppercase text-[hsl(var(--cream))] md:text-4xl" data-testid="text-roast-step">{tr(STEPS[si].t)}</div>
                <p className="mt-2 max-w-none text-sm text-[hsl(var(--cream))]/70 md:text-base lg:max-w-md">{tr(STEPS[si].d)}</p>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="flex gap-1.5">
            {STEPS.map((_, i) => (
              <div key={i} className="h-1 flex-1 overflow-hidden rounded-full bg-[hsl(var(--cream))]/15">
                <div className="h-full origin-left bg-accent" style={{ transform: `scaleX(${i < si ? 1 : i === si ? frac : 0})` }} />
              </div>
            ))}
          </div>

          <div className="grid w-full max-w-none grid-cols-3 gap-4 font-mono text-[11px] uppercase tracking-wider text-[hsl(var(--cream))]/60 lg:max-w-md">
            <div><div>{tr(UI.temp)}</div><div className="mt-1 font-wordmark text-2xl text-[hsl(var(--cream))] md:text-3xl" data-testid="text-roast-temp">{temp}°C</div></div>
            <div><div>{tr(UI.time)}</div><div className="mt-1 font-wordmark text-2xl text-[hsl(var(--cream))] md:text-3xl">{fmtTime(r)}</div></div>
            <div><div>{tr(UI.level)}</div><div className="mt-1 font-wordmark text-2xl md:text-3xl" style={{ color: wordCol }}>{tr(UI.lv[lv])}</div></div>
          </div>
          <div className="hidden h-1.5 max-w-md overflow-hidden rounded-full bg-[hsl(var(--cream))]/10 lg:block">
            <div className="h-full rounded-full" style={{ width: `${(temp / 232) * 100}%`, background: "linear-gradient(90deg,#8a9a4a,#d9a441,#e8642a,#c0391b)" }} />
          </div>
        </div>

        <div className="relative min-h-0">
          <RoastCanvas pRef={pRef} />
          <div className="pointer-events-none absolute inset-x-0 bottom-4 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--cream))]/50">
            {p < 0.03 ? tr(UI.scrollHint) : tr(UI.hint)}
          </div>
        </div>
      </div>
    </section>
  );
}
