import { motion, useScroll, useTransform, useVelocity, useSpring } from "framer-motion";
import { useLang } from "@/lib/i18n";

export default function Marquee({ reverse = false }: { reverse?: boolean }) {
  const { t } = useLang();
  const { scrollY } = useScroll();
  const vel = useSpring(useVelocity(scrollY), { damping: 50, stiffness: 300 });
  const skew = useTransform(vel, [-2000, 2000], [-8, 8]);
  const x = useTransform(scrollY, (v) => `${((reverse ? 1 : -1) * v * 0.15) % 1000}px`);
  const items = Array.from({ length: 8 }, () => [t("marquee"), "Bakı", "Specialty", "Mad"]).flat();
  return (
    <div className={`relative overflow-hidden border-y border-border py-5 ${reverse ? "bg-accent text-accent-foreground -rotate-1" : "bg-[hsl(var(--cream))] text-background rotate-1"}`}>
      <motion.div style={{ x, skewX: skew }} className="flex whitespace-nowrap">
        <div className="flex animate-[marq_40s_linear_infinite] gap-10 pr-10 motion-reduce:animate-none">
          {items.map((w, i) => (
            <span key={i} className={`font-wordmark text-3xl uppercase md:text-5xl ${i % 4 === 1 ? "font-display !font-normal italic normal-case [font-stretch:100%]" : ""}`}>{w} <span className="text-primary">*</span></span>
          ))}
        </div>
      </motion.div>
      <style>{`@keyframes marq{to{transform:translateX(-50%)}}`}</style>
    </div>
  );
}
