import { useEffect, useRef } from "react";

/**
 * Real-time fluid simulation: cream and coffee dye is pushed around by the
 * cursor (velocity + pressure solve) and slowly relaxes back into a marbled
 * coffee/cream pattern. Strongest in the hero, dims as the page scrolls.
 */

const VS = `attribute vec2 p;varying vec2 vUv;void main(){vUv=p*.5+.5;gl_Position=vec4(p,0.,1.);}`;
const HEAD = `precision highp float;varying vec2 vUv;`;

const BASE = `
uniform float aspect;uniform float t;
float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y);}
float fbm(vec2 p){float s=0.,a=.5;for(int i=0;i<4;i++){s+=a*n(p);p=p*2.02+vec2(1.7,9.2);a*=.5;}return s;}
vec3 base(vec2 uv){
 vec2 p=uv;p.x*=aspect;float tt=t*.025;
 vec2 q=vec2(fbm(p*1.1+tt),fbm(p*1.1+vec2(5.2,1.3)-tt));
 vec2 w=vec2(fbm(p*1.1+2.9*q+vec2(1.7,9.2)+tt*1.3),fbm(p*1.1+2.9*q+vec2(8.3,2.8)-tt));
 float f=fbm(p*1.1+3.2*w);
 f+= (0.55-uv.x*.6-uv.y*.15)*.35;
 vec3 esp=vec3(.045,.024,.014),mid=vec3(.3,.16,.08),car=vec3(.62,.38,.19),crm=vec3(.86,.74,.58);
 vec3 col=mix(esp,mid,smoothstep(.24,.58,f));
 col=mix(col,car,smoothstep(.48,.74,f));
 col=mix(col,crm,smoothstep(.64,.92,f)*.85);
 return col;
 }`;

const FS = {
  init: HEAD + BASE + `void main(){gl_FragColor=vec4(base(vUv),1.);}`,
  splat: HEAD + `uniform sampler2D uT;uniform float aspect;uniform vec2 pt;uniform vec3 color;uniform float radius;uniform float mode;
void main(){vec2 d=vUv-pt;d.x*=aspect;float g=exp(-dot(d,d)/radius);vec4 s=texture2D(uT,vUv);
 if(mode>.5){gl_FragColor=vec4(mix(s.rgb,color,clamp(g*.9,0.,1.)),1.);}else{gl_FragColor=vec4(s.rgb+g*color,1.);}}`,
  advect: HEAD + `uniform sampler2D uVel;uniform sampler2D uSrc;uniform float dt;uniform float diss;
void main(){vec2 c=vUv-dt*texture2D(uVel,vUv).xy;gl_FragColor=texture2D(uSrc,c)/(1.+diss*dt);}`,
  advectDye: HEAD + BASE + `uniform sampler2D uVel;uniform sampler2D uSrc;uniform float dt;uniform float relax;
void main(){vec2 c=vUv-dt*texture2D(uVel,vUv).xy;vec3 a=texture2D(uSrc,c).rgb;
 gl_FragColor=vec4(mix(a,base(vUv),clamp(relax*dt,0.,1.)),1.);}`,
  curl: HEAD + `uniform sampler2D uVel;uniform vec2 tx;
void main(){float L=texture2D(uVel,vUv-vec2(tx.x,0.)).y,R=texture2D(uVel,vUv+vec2(tx.x,0.)).y;
 float B=texture2D(uVel,vUv-vec2(0.,tx.y)).x,T=texture2D(uVel,vUv+vec2(0.,tx.y)).x;
 gl_FragColor=vec4(.5*(R-L-T+B),0.,0.,1.);}`,
  vort: HEAD + `uniform sampler2D uVel;uniform sampler2D uCurl;uniform vec2 tx;uniform float dt;uniform float curl;
void main(){float L=texture2D(uCurl,vUv-vec2(tx.x,0.)).x,R=texture2D(uCurl,vUv+vec2(tx.x,0.)).x;
 float B=texture2D(uCurl,vUv-vec2(0.,tx.y)).x,T=texture2D(uCurl,vUv+vec2(0.,tx.y)).x;float C=texture2D(uCurl,vUv).x;
 vec2 f=.5*vec2(abs(T)-abs(B),abs(R)-abs(L));f/=length(f)+1e-4;f*=curl*C;f.y*=-1.;
 vec2 v=texture2D(uVel,vUv).xy+f*dt;gl_FragColor=vec4(clamp(v,-4.,4.),0.,1.);}`,
  div: HEAD + `uniform sampler2D uVel;uniform vec2 tx;
void main(){float L=texture2D(uVel,vUv-vec2(tx.x,0.)).x,R=texture2D(uVel,vUv+vec2(tx.x,0.)).x;
 float B=texture2D(uVel,vUv-vec2(0.,tx.y)).y,T=texture2D(uVel,vUv+vec2(0.,tx.y)).y;
 gl_FragColor=vec4(.5*(R-L+T-B),0.,0.,1.);}`,
  press: HEAD + `uniform sampler2D uP;uniform sampler2D uDiv;uniform vec2 tx;
void main(){float L=texture2D(uP,vUv-vec2(tx.x,0.)).x,R=texture2D(uP,vUv+vec2(tx.x,0.)).x;
 float B=texture2D(uP,vUv-vec2(0.,tx.y)).x,T=texture2D(uP,vUv+vec2(0.,tx.y)).x;
 gl_FragColor=vec4((L+R+B+T-texture2D(uDiv,vUv).x)*.25,0.,0.,1.);}`,
  grad: HEAD + `uniform sampler2D uP;uniform sampler2D uVel;uniform vec2 tx;
void main(){float L=texture2D(uP,vUv-vec2(tx.x,0.)).x,R=texture2D(uP,vUv+vec2(tx.x,0.)).x;
 float B=texture2D(uP,vUv-vec2(0.,tx.y)).x,T=texture2D(uP,vUv+vec2(0.,tx.y)).x;
 vec2 v=texture2D(uVel,vUv).xy-vec2(R-L,T-B);gl_FragColor=vec4(v,0.,1.);}`,
  clear: HEAD + `uniform sampler2D uT;uniform float v;void main(){gl_FragColor=v*texture2D(uT,vUv);}`,
  display: HEAD + `uniform sampler2D uDye;uniform float k;uniform vec2 tx;
void main(){
 vec3 c=texture2D(uDye,vUv).rgb;
 float lL=dot(texture2D(uDye,vUv-vec2(tx.x,0.)).rgb,vec3(.33)),lR=dot(texture2D(uDye,vUv+vec2(tx.x,0.)).rgb,vec3(.33));
 float lB=dot(texture2D(uDye,vUv-vec2(0.,tx.y)).rgb,vec3(.33)),lT=dot(texture2D(uDye,vUv+vec2(0.,tx.y)).rgb,vec3(.33));
 vec3 nrm=normalize(vec3((lL-lR)*3.,(lB-lT)*3.,.25));
 float spec=pow(max(dot(nrm,normalize(vec3(-.4,.6,.7))),0.),22.);
 c+=spec*.2*k;
 vec3 esp=vec3(.06,.033,.02);
 c=mix(esp,c,k*.85+.15);
 float vig=smoothstep(1.25,.25,length(vUv-.5)*1.4);
 c*=mix(.55,1.,vig);
 gl_FragColor=vec4(c,1.);}`,
};

type Uni = number | number[];

export default function SwirlCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = ref.current!;
    const opts = { antialias: false, alpha: false, depth: false, stencil: false, preserveDrawingBuffer: false };
    let gl2 = cv.getContext("webgl2", opts) as WebGL2RenderingContext | null;
    const gl = (gl2 ?? (cv.getContext("webgl", opts) as WebGLRenderingContext | null)) as WebGLRenderingContext | null;
    if (!gl) return;

    let halfType: number;
    if (gl2) {
      gl2.getExtension("EXT_color_buffer_float");
      gl2.getExtension("EXT_color_buffer_half_float");
      halfType = gl2.HALF_FLOAT;
    } else {
      const ext = gl.getExtension("OES_texture_half_float");
      gl.getExtension("OES_texture_half_float_linear");
      gl.getExtension("EXT_color_buffer_half_float");
      if (!ext) return;
      halfType = ext.HALF_FLOAT_OES;
    }

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const compile = (type: number, src: string) => {
      const s = gl.createShader(type)!;
      gl.shaderSource(s, src);
      gl.compileShader(s);
      return s;
    };
    const vs = compile(gl.VERTEX_SHADER, VS);
    const programs: Record<string, { pr: WebGLProgram; loc: Record<string, WebGLUniformLocation | null> }> = {};
    for (const [name, src] of Object.entries(FS)) {
      const pr = gl.createProgram()!;
      gl.attachShader(pr, vs);
      gl.attachShader(pr, compile(gl.FRAGMENT_SHADER, src));
      gl.bindAttribLocation(pr, 0, "p");
      gl.linkProgram(pr);
      programs[name] = { pr, loc: {} };
    }
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

    const use = (name: string, u: Record<string, Uni>) => {
      const P = programs[name];
      gl.useProgram(P.pr);
      for (const key in u) {
        if (!(key in P.loc)) P.loc[key] = gl.getUniformLocation(P.pr, key);
        const l = P.loc[key];
        if (l === null) continue;
        const v = u[key];
        if (typeof v === "number") gl.uniform1f(l, v);
        else if (v.length === 2) gl.uniform2f(l, v[0], v[1]);
        else gl.uniform3f(l, v[0], v[1], v[2]);
      }
    };
    const bindTex = (unit: number, tex: WebGLTexture, name: string, prog: string) => {
      const P = programs[prog];
      gl.activeTexture(gl.TEXTURE0 + unit);
      gl.bindTexture(gl.TEXTURE_2D, tex);
      if (!(name in P.loc)) P.loc[name] = gl.getUniformLocation(P.pr, name);
      gl.uniform1i(P.loc[name], unit);
    };

    type FBO = { tex: WebGLTexture; fbo: WebGLFramebuffer; w: number; h: number };
    const makeFBO = (w: number, h: number): FBO => {
      const tex = gl.createTexture()!;
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      if (gl2) gl2.texImage2D(gl2.TEXTURE_2D, 0, gl2.RGBA16F, w, h, 0, gl2.RGBA, halfType, null);
      else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, halfType, null);
      const fbo = gl.createFramebuffer()!;
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      return { tex, fbo, w, h };
    };
    type Pair = { a: FBO; b: FBO; swap: () => void };
    const makePair = (w: number, h: number): Pair => {
      const p: Pair = { a: makeFBO(w, h), b: makeFBO(w, h), swap() { const t = p.a; p.a = p.b; p.b = t; } };
      return p;
    };

    const SIM = 128, DYE = 512;
    const vel = makePair(SIM, SIM);
    const dye = makePair(DYE, DYE);
    const pres = makePair(SIM, SIM);
    const div = makeFBO(SIM, SIM);
    const curl = makeFBO(SIM, SIM);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) return;

    let aspect = 1;
    const blit = (target: FBO | null) => {
      if (target) { gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo); gl.viewport(0, 0, target.w, target.h); }
      else { gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, cv.width, cv.height); }
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    const stx: [number, number] = [1 / SIM, 1 / SIM];
    const dtx: [number, number] = [1 / DYE, 1 / DYE];

    const resize = () => {
      const s = 0.6;
      cv.width = Math.max(2, Math.floor(innerWidth * s));
      cv.height = Math.max(2, Math.floor(innerHeight * s));
      aspect = cv.width / cv.height;
    };
    resize();

    const t0 = performance.now();
    const time = () => (reduce ? 14 : (performance.now() - t0) / 1000);

    use("init", { aspect, t: time() });
    blit(dye.a);
    blit(dye.b);

    const splat = (x: number, y: number, dx: number, dy: number, color: [number, number, number]) => {
      use("splat", { aspect, pt: [x, y], color: [dx * 55, dy * 55, 0], radius: 0.0035, mode: 0 });
      bindTex(0, vel.a.tex, "uT", "splat");
      blit(vel.b); vel.swap();
      use("splat", { aspect, pt: [x, y], color, radius: 0.0042, mode: 1 });
      bindTex(0, dye.a.tex, "uT", "splat");
      blit(dye.b); dye.swap();
    };

    const splatVel = (x: number, y: number, dx: number, dy: number) => {
      use("splat", { aspect, pt: [x, y], color: [dx * 55, dy * 55, 0], radius: 0.006, mode: 0 });
      bindTex(0, vel.a.tex, "uT", "splat");
      blit(vel.b); vel.swap();
    };

    const splatDye = (x: number, y: number, color: [number, number, number]) => {
      use("splat", { aspect, pt: [x, y], color, radius: 0.0042, mode: 1 });
      bindTex(0, dye.a.tex, "uT", "splat");
      blit(dye.b); dye.swap();
    };

    const ptr = { x: 0.5, y: 0.5, px: 0.5, py: 0.5, moved: false };
    const onMove = (e: PointerEvent) => {
      ptr.x = e.clientX / innerWidth;
      ptr.y = 1 - e.clientY / innerHeight;
      ptr.moved = true;
    };
    addEventListener("pointermove", onMove);

    const display = () => {
      const k = Math.max(0.18, 1 - scrollY / (innerHeight * 1.4));
      use("display", { k, tx: dtx });
      bindTex(0, dye.a.tex, "uDye", "display");
      blit(null);
    };

    let raf = 0;
    let last = performance.now();
    const loop = () => {
      raf = 0;
      const now = performance.now();
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const sec = (now - t0) / 1000;
      const active = !reduce && !document.hidden && scrollY < innerHeight * 1.4;

      if (active) {
        if (ptr.moved) {
          const dx = ptr.x - ptr.px, dy = ptr.y - ptr.py;
          const mix = 0.5 + 0.5 * Math.sin(sec * 0.9);
          const cream: [number, number, number] = [0.2 + 0.66 * mix, 0.11 + 0.63 * mix, 0.06 + 0.52 * mix];
          splat(ptr.x, ptr.y, dx, dy, cream);
          ptr.px = ptr.x; ptr.py = ptr.y; ptr.moved = false;
        }
        // idle: three wandering "spoons" stir vortex pairs so the surface keeps swirling in every direction
        for (let i = 0; i < 3; i++) {
          const ph = i * 2.1;
          const ix = 0.5 + 0.4 * Math.cos(sec * (0.21 + i * 0.07) + ph) * Math.cos(sec * 0.05 + i);
          const iy = 0.5 + 0.3 * Math.sin(sec * (0.27 + i * 0.05) + ph * 1.3);
          const ang = sec * (0.9 + i * 0.35) * (i % 2 ? -1 : 1);
          const ox = Math.cos(ang) * 0.03, oy = Math.sin(ang) * 0.03;
          const m = 0.011;
          splatVel(ix + ox / aspect, iy + oy, -Math.sin(ang) * m, Math.cos(ang) * m);
          splatVel(ix - ox / aspect, iy - oy, Math.sin(ang) * m, -Math.cos(ang) * m);
          const mixv = 0.5 + 0.5 * Math.sin(sec * 0.6 + ph * 2);
          if (Math.sin(sec * 0.8 + ph) > 0.2) splatDye(ix, iy, [0.22 + 0.64 * mixv, 0.12 + 0.6 * mixv, 0.06 + 0.5 * mixv]);
        }

        use("curl", { tx: stx }); bindTex(0, vel.a.tex, "uVel", "curl"); blit(curl);
        use("vort", { tx: stx, dt, curl: 22 });
        bindTex(0, vel.a.tex, "uVel", "vort"); bindTex(1, curl.tex, "uCurl", "vort");
        blit(vel.b); vel.swap();
        use("div", { tx: stx }); bindTex(0, vel.a.tex, "uVel", "div"); blit(div);
        use("clear", { v: 0.8 }); bindTex(0, pres.a.tex, "uT", "clear"); blit(pres.b); pres.swap();
        use("press", { tx: stx });
        bindTex(1, div.tex, "uDiv", "press");
        for (let i = 0; i < 18; i++) { bindTex(0, pres.a.tex, "uP", "press"); blit(pres.b); pres.swap(); }
        use("grad", { tx: stx });
        bindTex(0, pres.a.tex, "uP", "grad"); bindTex(1, vel.a.tex, "uVel", "grad");
        blit(vel.b); vel.swap();
        use("advect", { dt, diss: 0.9 });
        bindTex(0, vel.a.tex, "uVel", "advect"); bindTex(1, vel.a.tex, "uSrc", "advect");
        blit(vel.b); vel.swap();
        use("advectDye", { aspect, t: sec, dt, relax: 0.15 });
        bindTex(0, vel.a.tex, "uVel", "advectDye"); bindTex(1, dye.a.tex, "uSrc", "advectDye");
        blit(dye.b); dye.swap();
      }
      display();
      if (active) raf = requestAnimationFrame(loop);
    };

    const stop = () => {
      if (raf !== 0) {
        cancelAnimationFrame(raf);
        raf = 0;
      }
    };
    const refresh = () => {
      if (reduce) {
        stop();
        display();
      } else if (document.hidden) {
        stop();
      } else if (!raf) {
        last = performance.now();
        raf = requestAnimationFrame(loop);
      }
    };
    const onResize = () => { resize(); refresh(); };
    const onScroll = () => refresh();
    const onVisibilityChange = () => refresh();
    addEventListener("resize", onResize);
    addEventListener("scroll", onScroll);
    document.addEventListener("visibilitychange", onVisibilityChange);
    refresh();

    return () => {
      stop();
      removeEventListener("pointermove", onMove);
      removeEventListener("resize", onResize);
      removeEventListener("scroll", onScroll);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      for (const { pr } of Object.values(programs)) gl.deleteProgram(pr);
      for (const f of [vel.a, vel.b, dye.a, dye.b, pres.a, pres.b, div, curl]) { gl.deleteTexture(f.tex); gl.deleteFramebuffer(f.fbo); }
      gl.deleteBuffer(buf);
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden
      className="fixed inset-0 z-0 h-full w-full"
      style={{ background: "radial-gradient(ellipse at 30% 40%, hsl(24 45% 22%), hsl(24 30% 6%) 70%)" }}
    />
  );
}
