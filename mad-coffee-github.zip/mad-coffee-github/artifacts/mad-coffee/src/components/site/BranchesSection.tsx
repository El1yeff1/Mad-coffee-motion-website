import { Fragment, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Clock, MapPin, Navigation, Phone } from "lucide-react";
import type { Branch } from "@/lib/data";
import { img, useLang } from "@/lib/i18n";
import { Kicker, SplitWords } from "./motion";

export default function BranchesSection({ items }: { items: Branch[] }) {
  const { t, tr, lang } = useLang();
  const [id, setId] = useState(items[0]?.id ?? "");
  const [hasChangedBranch, setHasChangedBranch] = useState(false);
  const [desktopLayout, setDesktopLayout] = useState(() =>
    typeof window !== "undefined" && !!window.matchMedia?.("(min-width: 1024px)").matches
  );
  useEffect(() => {
    const media = window.matchMedia("(min-width: 1024px)");
    const update = () => setDesktopLayout(media.matches);
    update();
    if (media.addEventListener) media.addEventListener("change", update);
    else media.addListener(update);
    return () => {
      if (media.removeEventListener) media.removeEventListener("change", update);
      else media.removeListener(update);
    };
  }, []);

  useEffect(() => {
    if (!items.some((branch) => branch.id === id)) setId(items[0]?.id ?? "");
  }, [items, id]);
  const b = items.find((x) => x.id === id) ?? items[0];
  const branchTitleClass = `mt-4 max-w-3xl whitespace-nowrap font-display text-[clamp(26px,8.5vw,47px)] leading-[0.95] md:text-[71px] ${lang === "en" ? "branch-heading-en" : ""}`;
  if (!b) {
    return (
      <section id="branches" className="relative bg-background/85 py-20 backdrop-blur-sm md:py-32">
        <div className="mx-auto max-w-[1600px] px-5 md:px-10">
          <Kicker>{t("brKicker")}</Kicker>
          <h2 className={branchTitleClass}><SplitWords text={t("brTitle")} /></h2>
          <p className="mt-8 font-mono text-xs uppercase tracking-wider text-muted-foreground">{t("branchesUnavailable")}</p>
        </div>
      </section>
    );
  }

  const renderBranchButton = (x: Branch, i: number) => (
    <button key={x.id} onClick={() => { setId(x.id); setHasChangedBranch(true); }} data-testid={`button-branch-${x.id}`}
      className={`group relative flex w-full items-center gap-5 border-b border-border py-5 pr-4 text-left transition-colors ${id === x.id ? "text-foreground" : "text-foreground/45 hover:text-foreground/80"}`}>
      {id === x.id && <motion.span layoutId="br-bar" className="absolute left-0 top-0 h-full w-1 bg-accent" />}
      <span className="pl-4 font-mono text-[11px]">0{i + 1}</span>
      <span className="flex-1">
        <span className="block font-wordmark text-3xl uppercase md:text-4xl">{tr(x.name)}</span>
        <span className="font-mono text-[11px] uppercase tracking-wider">{tr(x.area)}</span>
      </span>
      <MapPin className={`h-5 w-5 transition-transform ${id === x.id ? "text-accent scale-110" : "group-hover:-translate-y-1"}`} />
    </button>
  );

  const renderBranchPanel = (mobile = false) => (
    <motion.div key={b.id}
      initial={mobile
        ? (hasChangedBranch ? { height: 0, opacity: 0, y: -12 } : false)
        : { opacity: 0, y: 30 }}
      animate={mobile ? { height: "auto", opacity: 1, y: 0 } : { opacity: 1, y: 0 }}
      exit={mobile ? { height: 0, opacity: 0, y: -8 } : { opacity: 0, y: -20 }}
      transition={mobile
        ? { height: { duration: 0.62, ease: [0.16, 1, 0.3, 1] }, opacity: { duration: 0.32, delay: 0.08 }, y: { duration: 0.42, ease: [0.16, 1, 0.3, 1] } }
        : { duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="grid gap-px overflow-hidden border border-border bg-border md:grid-cols-2">
      <div className="relative min-h-[260px] bg-card">
        <motion.img src={img(b.image)} alt={tr(b.name)} className="absolute inset-0 h-full w-full object-cover"
          initial={mobile && hasChangedBranch ? { scale: 1.06, opacity: 0.8 } : false}
          animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }} />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        <div className="absolute bottom-0 p-6">
          <p className="font-display text-4xl italic">{tr(b.area)}</p>
        </div>
      </div>
      <motion.div className="flex flex-col gap-5 bg-card p-6 md:p-8"
        initial={mobile && hasChangedBranch ? { opacity: 0, y: 12 } : false}
        animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.38, delay: mobile && hasChangedBranch ? 0.14 : 0 }}>
        <div className="flex gap-3"><MapPin className="mt-0.5 h-4 w-4 text-primary" /><p data-testid="text-branch-address">{tr(b.address)}</p></div>
        <div className="flex gap-3"><Clock className="mt-0.5 h-4 w-4 text-primary" /><div><p className="font-mono text-[10px] uppercase text-muted-foreground">{t("hours")}</p><p>{tr(b.hours)}</p></div></div>
        <div className="flex gap-3"><Phone className="mt-0.5 h-4 w-4 text-primary" /><div><p className="font-mono text-[10px] uppercase text-muted-foreground">{t("phone")}</p><span>{b.phone}</span></div></div>
        <div className="mt-auto">
          <a data-testid="link-directions" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/dir/?api=1&destination=${b.lat},${b.lng}`}
            className="inline-flex items-center gap-2 bg-accent px-5 py-3 font-wordmark text-sm uppercase text-accent-foreground">
            <Navigation className="h-4 w-4" /> {t("directions")}
          </a>
        </div>
      </motion.div>
      <div className="relative h-[190px] sm:h-[260px] md:h-[340px] bg-card md:col-span-2">
        <iframe title={`map-${b.id}`} src={`https://www.google.com/maps?q=${b.lat},${b.lng}&z=16&output=embed`} loading="lazy"
          className="h-full w-full [filter:grayscale(1)_sepia(.6)_invert(.88)_hue-rotate(180deg)_saturate(1.4)_contrast(.9)]" />
      </div>
    </motion.div>
  );

  return (
    <section id="branches" className="relative bg-background/85 pt-4 pb-24 backdrop-blur-sm md:py-40">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <Kicker>{t("brKicker")}</Kicker>
        <h2 className={branchTitleClass}><SplitWords text={t("brTitle")} /></h2>
        {desktopLayout ? (
          <div className="mt-14 grid gap-8 lg:grid-cols-[0.9fr_1.6fr]">
          <div className="flex flex-col">{items.map(renderBranchButton)}</div>
            <AnimatePresence mode="wait">{renderBranchPanel()}</AnimatePresence>
          </div>
        ) : (
          <div className="mt-14 flex flex-col">
            {items.map((x, i) => (
              <div key={x.id} className="relative">
                {renderBranchButton(x, i)}
                <AnimatePresence initial={false}>
                  {id === x.id && renderBranchPanel(true)}
                </AnimatePresence>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
