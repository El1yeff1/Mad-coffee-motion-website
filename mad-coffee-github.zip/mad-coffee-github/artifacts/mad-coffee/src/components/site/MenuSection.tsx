import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Flame } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { categories, type MenuItem } from "@/lib/data";
import { img, useLang } from "@/lib/i18n";
import { Kicker, Reveal, SplitWords } from "./motion";

export default function MenuSection({ items }: { items: MenuItem[] }) {
  const { t, tr } = useLang();
  const [cat, setCat] = useState("all");
  const [sel, setSel] = useState<MenuItem | null>(null);
  const [hov, setHov] = useState<MenuItem | null>(null);
  const list = cat === "all" ? items : items.filter((m) => m.cat === cat);
  return (
    <section id="menu" className="relative mx-auto w-full max-w-[1600px] px-5 pt-24 pb-4 md:px-10 md:py-40">
      <div className="grid grid-cols-[minmax(0,1fr)] gap-10 md:grid-cols-[1fr_1.4fr] md:gap-16">
        <div className="md:sticky md:top-24 md:self-start">
          <Kicker>{t("menuKicker")}</Kicker>
          <h2 className="mt-4 whitespace-nowrap font-display text-[clamp(24px,7.5vw,34px)] leading-[0.95] md:text-[clamp(24px,3.2vw,54px)]"><SplitWords text={t("menuTitle")} /></h2>
          <div className="relative mt-10 hidden aspect-[4/5] overflow-hidden md:block">
            <AnimatePresence mode="popLayout">
              <motion.img key={(hov ?? list[0])?.id} src={img((hov ?? list[0])?.image ?? "menu-drinks.jpg")} alt="" initial={{ opacity: 0, scale: 1.15, clipPath: "inset(100% 0 0 0)" }} animate={{ opacity: 1, scale: 1, clipPath: "inset(0% 0 0 0)" }} exit={{ opacity: 0 }} transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                className={`absolute inset-0 h-full w-full ${(hov ?? list[0])?.image.endsWith(".png") ? "object-contain p-10" : "object-cover"}`} />
            </AnimatePresence>
            <div className="absolute bottom-3 left-3 font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--cream))]">{hov ? tr(hov.name) : ""}</div>
          </div>
        </div>
        <div className="min-w-0">
          <div role="tablist" className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 [scrollbar-width:none] md:mx-0 md:flex-wrap md:overflow-visible md:px-0 [&::-webkit-scrollbar]:hidden">
            {[{ id: "all", label: { az: t("all"), ru: t("all"), en: t("all") } }, ...categories].map((c) => (
              <button key={c.id} role="tab" aria-selected={cat === c.id} onClick={() => setCat(c.id)} data-testid={`tab-category-${c.id}`}
                className={`relative shrink-0 rounded-full border px-4 py-2 font-mono text-[11px] uppercase tracking-wider transition-colors ${cat === c.id ? "border-transparent text-background" : "border-border text-foreground/70 hover:border-primary hover:text-foreground"}`}>
                {cat === c.id && <motion.span layoutId="cat-pill" className="absolute inset-0 rounded-full bg-primary" transition={{ type: "spring", stiffness: 400, damping: 30 }} />}
                <span className="relative">{tr(c.label)}</span>
              </button>
            ))}
          </div>
          <motion.ul layout className="-mx-5 mt-8 border-t border-border md:mx-0 md:mt-10">
            <AnimatePresence mode="popLayout">
              {list.length === 0 && <p className="py-16 text-center font-display text-2xl italic text-muted-foreground">{t("empty")}</p>}
              {list.map((m, i) => (
                <motion.li layout key={m.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ delay: i * 0.04 }}>
                  <button onClick={() => setSel(m)} onPointerEnter={() => setHov(m)} data-native-cursor data-testid={`card-menu-${m.id}`}
                    className="group relative grid w-full grid-cols-[72px_minmax(0,1fr)_auto] items-center gap-x-3.5 gap-y-1 overflow-hidden border-b border-border px-4 py-4 text-left md:grid-cols-[2rem_minmax(0,1fr)_auto_1.5rem] md:gap-x-4 md:px-0 md:py-6">
                    <span className="absolute inset-0 origin-bottom scale-y-0 bg-[hsl(var(--cream))] transition-transform duration-500 ease-[cubic-bezier(.7,0,.2,1)] group-hover:scale-y-100" />
                    <span className={`relative row-span-2 h-[72px] w-[72px] overflow-hidden rounded-sm bg-[radial-gradient(circle_at_50%_40%,hsl(30_62%_30%),hsl(24_30%_8%))] md:hidden`}>
                      <img src={img(m.image)} alt="" loading="lazy" className={`h-full w-full ${m.image.endsWith(".png") ? "object-contain p-1.5" : "object-cover"}`} />
                    </span>
                    <span className="relative hidden w-8 md:col-start-1 md:row-start-1 md:block font-mono text-[11px] text-muted-foreground group-hover:text-background/60">{String(i + 1).padStart(2, "0")}</span>
                    <span className="relative col-start-2 col-end-3 row-start-1 min-w-0 transition-transform duration-500 md:group-hover:translate-x-3">
                      <span className="flex items-center gap-2 whitespace-nowrap font-display text-[clamp(0.8125rem,4.1vw,1rem)] font-semibold leading-tight group-hover:text-background md:text-4xl">
                        {tr(m.name)}{m.signature && <Flame className="h-4 w-4 text-accent" />}
                      </span>
                      <span className="mt-1 block truncate font-mono text-[10px] uppercase tracking-wide text-muted-foreground group-hover:text-background/70 md:text-[11px]">{tr(m.notes)}</span>
                    </span>
                    <span className="relative col-start-3 row-start-1 whitespace-nowrap self-start pt-1 font-wordmark text-base md:pt-0 md:text-2xl group-hover:text-background">{m.price.toFixed(2)} ₼</span>
                    <span title={tr(m.desc)} className="relative col-start-2 col-end-4 row-start-2 text-[11px] leading-snug text-foreground/60 group-hover:text-background/70 md:col-end-4">{tr(m.desc)}</span>
                    <ArrowUpRight className="relative col-start-4 row-start-1 hidden h-5 w-5 -rotate-45 opacity-0 transition-all group-hover:rotate-0 group-hover:text-accent group-hover:opacity-100 md:block" />
                  </button>
                </motion.li>
              ))}
            </AnimatePresence>
          </motion.ul>
        </div>
      </div>
      <Dialog open={!!sel} onOpenChange={(o) => !o && setSel(null)}>
        <DialogContent className="inset-0 left-0 top-0 grid h-[100dvh] max-h-[100dvh] w-full max-w-none translate-x-0 translate-y-0 gap-0 overflow-y-auto overscroll-contain touch-pan-y [-webkit-overflow-scrolling:touch] rounded-none border-border bg-card p-0 md:inset-auto md:left-[50%] md:top-[50%] md:h-auto md:max-h-[85vh] md:max-w-3xl md:translate-x-[-50%] md:translate-y-[-50%] md:gap-4 md:rounded-lg">
          {sel && (
            <div className="grid h-[100dvh] min-h-[100dvh] grid-rows-[38dvh_minmax(0,1fr)] md:h-auto md:min-h-0 md:grid-cols-2 md:grid-rows-none">
              <div className="relative min-h-0 bg-[radial-gradient(circle_at_50%_40%,hsl(30_62%_30%),hsl(24_30%_6%))] md:aspect-square">
                <motion.img initial={{ scale: 1.2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.8 }} src={img(sel.image)} alt={tr(sel.name)} className={`h-full w-full ${sel.image.endsWith(".png") ? "object-contain p-4 md:p-8" : "object-cover"}`} />
                {sel.signature && <span className="absolute left-4 top-4 bg-accent px-2 py-1 font-mono text-[10px] uppercase text-accent-foreground">Mad signature</span>}
              </div>
              <div className="flex min-h-0 flex-col p-4 sm:p-6 md:p-8">
                <Kicker>{tr(categories.find((c) => c.id === sel.cat)!.label)}</Kicker>
                <DialogTitle className="mt-3 font-display text-3xl font-medium leading-none md:text-4xl">{tr(sel.name)}</DialogTitle>
                <DialogDescription className="mt-3 text-base text-foreground/75">{tr(sel.desc)}</DialogDescription>
                <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-border pt-4 font-mono text-[11px] uppercase md:mt-6 md:gap-4 md:pt-5 md:text-xs">
                  <div><dt className="text-muted-foreground">{t("volume")}</dt><dd className="mt-1">{sel.vol}</dd></div>
                  <div><dt className="text-muted-foreground">{t("notes")}</dt><dd className="mt-1 normal-case">{tr(sel.notes)}</dd></div>
                </dl>
                <div className="mt-auto flex items-end justify-between pt-5 md:pt-8">
                  <span data-testid="text-dialog-price" className="inline-flex items-baseline whitespace-nowrap font-wordmark text-3xl text-primary sm:text-4xl md:text-5xl">{sel.price.toFixed(2)}<span className="ml-1 text-xl md:text-2xl">₼</span></span>
                </div>
                <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{t("orderAt")}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Reveal className="sr-only"><span /></Reveal>
    </section>
  );
}
