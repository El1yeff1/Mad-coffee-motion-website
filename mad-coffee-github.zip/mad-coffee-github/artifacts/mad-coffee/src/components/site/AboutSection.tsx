import { useEffect, useRef, useState } from "react";
import { animate, motion, useInView, useScroll, useTransform } from "framer-motion";
import { img, useLang } from "@/lib/i18n";
import { Kicker, Reveal } from "./motion";

function Count({ to, dec = 0 }: { to: number; dec?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => { if (!inView) return undefined; const c = animate(0, to, { duration: 2, ease: "easeOut", onUpdate: setV }); return () => c.stop(); }, [inView, to]);
  return <span ref={ref}>{v.toFixed(dec)}</span>;
}

export default function AboutSection() {
  const { t } = useLang();
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const x = useTransform(scrollYProgress, [0, 1], ["5%", "-45%"]);
  const y1 = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const y2 = useTransform(scrollYProgress, [0, 1], [-40, 120]);
  const words = t("aboutTitle").split(" ");
  return (
    <section id="about" ref={ref} className="relative overflow-hidden py-24 md:py-40">
      <motion.div style={{ x }} aria-hidden className="pointer-events-none relative -mt-[4vw] mb-5 whitespace-nowrap font-wordmark text-[22vw] uppercase leading-none text-transparent [-webkit-text-stroke:1px_hsl(30_62%_52%/0.35)]">
        Mad · Mad · Mad ·
      </motion.div>
      <div className="mx-auto grid max-w-[1600px] gap-12 px-5 md:grid-cols-12 md:px-10">
        <div className="md:col-span-7">
          <Kicker>{t("aboutKicker")}</Kicker>
          <h2 className="mt-5 font-display text-4xl leading-[1.02] md:text-6xl">
            {words.map((w, i) => (
              <motion.span key={i + w} className="inline-block" initial={{ opacity: 0.12 }} whileInView={{ opacity: 1 }} viewport={{ margin: "-35% 0px -35% 0px" }} transition={{ duration: 0.4, delay: i * 0.03 }}>
                <span className={i === 1 || i === 2 ? "italic text-accent" : ""}>{w}</span>&nbsp;
              </motion.span>
            ))}
          </h2>
          <div className="mt-10 grid gap-6 text-foreground/75 md:grid-cols-2">
            <Reveal><p>{t("about1")}</p></Reveal>
            <Reveal delay={0.1}><p>{t("about2")}</p></Reveal>
          </div>
          <div className="mt-14 grid grid-cols-3 border-t border-border pt-8">
            {[[18.5, 1, t("stat1")], [28, 0, t("stat2")], [1347, 0, t("stat3")]].map(([n, d, l], i) => (
              <div key={i} className="min-w-0 pr-0 sm:pr-4">
                <p className="font-wordmark text-4xl text-primary md:text-6xl"><Count to={n as number} dec={d as number} /></p>
                <p className="mt-2 whitespace-nowrap font-mono text-[clamp(7px,2.2vw,9px)] uppercase tracking-[-0.02em] text-muted-foreground md:text-[10px]">{l}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="relative h-[520px] md:col-span-5 md:h-auto">
          <motion.img style={{ y: y1 }} src={img("interior-1.jpg")} alt="Mad Coffee interior" className="absolute right-0 top-0 h-[70%] w-[78%] object-cover" />
          <motion.img style={{ y: y2 }} src={img("interior-2.jpg")} alt="Barista" className="absolute bottom-0 left-0 h-[48%] w-[58%] border-4 border-background object-cover" />
          <motion.div style={{ rotate: useTransform(scrollYProgress, [0, 1], [0, 220]) }} className="absolute left-[38%] top-[52%] flex h-28 w-28 items-center justify-center rounded-full bg-accent font-mono text-[9px] uppercase text-accent-foreground">
            <svg viewBox="0 0 100 100" className="absolute inset-0"><defs><path id="c" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" /></defs><text fill="currentColor" fontSize="9" letterSpacing="2"><textPath href="#c">MAD COFFEE · BAKU · ESPRESSO BAR ·</textPath></text></svg>
            <span className="font-wordmark text-2xl">Z</span>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
