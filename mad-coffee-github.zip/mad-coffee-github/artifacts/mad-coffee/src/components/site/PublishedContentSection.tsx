import type { SiteData } from "@workspace/api-client-react";
import type { Lang } from "@/lib/i18n";
import { Kicker, Reveal } from "./motion";

type ContentBlock = SiteData["content"][number];

export default function PublishedContentSection({ blocks, lang }: { blocks: ContentBlock[]; lang: Lang }) {
  if (blocks.length === 0) return null;

  return (
    <section aria-label="Published updates" className="relative mx-auto w-full max-w-[1600px] px-5 py-20 md:px-10 md:py-32">
      <Kicker>06 — Mad Journal</Kicker>
      <div className="mt-8 divide-y divide-border border-y border-border">
        {blocks.map((block, index) => (
          <Reveal key={block.id} className="grid gap-4 py-7 md:grid-cols-[0.7fr_1.3fr] md:gap-12 md:py-10" data-testid={`card-published-content-${block.id}`}>
            <p className="font-mono text-[10px] uppercase tracking-widest text-accent">0{index + 1} / Live</p>
            <div>
              <h2 data-testid={`text-content-title-${block.id}`} className="font-display text-2xl leading-tight md:text-4xl">{block.title[lang]}</h2>
              <p data-testid={`text-content-body-${block.id}`} className="mt-4 max-w-3xl whitespace-pre-wrap text-sm leading-relaxed text-foreground/70 md:text-base">{block.body[lang]}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
