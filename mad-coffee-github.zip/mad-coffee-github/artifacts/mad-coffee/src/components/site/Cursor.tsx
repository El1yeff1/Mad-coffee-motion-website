import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export default function Cursor() {
  const x = useMotionValue(-100), y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 400, damping: 35 }), sy = useSpring(y, { stiffness: 400, damping: 35 });
  const [hover, setHover] = useState(false);
  const [nativeCursor, setNativeCursor] = useState(false);
  const [fine, setFine] = useState(false);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(hover: hover) and (pointer: fine)");
    setFine(mq.matches);
    if (!mq.matches) return;
    document.body.classList.add("cursor-none-fine");
    const mv = (e: PointerEvent) => {
      x.set(e.clientX); y.set(e.clientY);
      const el = e.target as HTMLElement;
      const useNativeCursor = !!el.closest("[data-native-cursor]");
      setNativeCursor(useNativeCursor);
      setHover(!useNativeCursor && !!el.closest("a,button,[role=tab],input,textarea,select,[data-hover]"));
      setVisible(true);
    };
    const hide = () => {
      setVisible(false);
      setHover(false);
      setNativeCursor(false);
    };
    window.addEventListener("pointermove", mv);
    window.addEventListener("blur", hide);
    document.documentElement.addEventListener("pointerleave", hide);
    return () => {
      window.removeEventListener("pointermove", mv);
      window.removeEventListener("blur", hide);
      document.documentElement.removeEventListener("pointerleave", hide);
      document.body.classList.remove("cursor-none-fine");
    };
  }, [x, y]);
  if (!fine) return null;
  return (
    <>
      <motion.div className="pointer-events-none fixed left-0 top-0 z-[120] h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent" style={{ x, y, opacity: visible && !nativeCursor ? 1 : 0 }} />
      <motion.div className="pointer-events-none fixed left-0 top-0 z-[119] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[hsl(var(--cream))]/60 mix-blend-difference"
        style={{ x: sx, y: sy }} animate={{ width: hover ? 64 : 30, height: hover ? 64 : 30, opacity: visible && !nativeCursor ? 1 : 0, backgroundColor: hover ? "hsla(36,45%,88%,1)" : "hsla(36,45%,88%,0)" }} transition={{ duration: 0.25 }} />
    </>
  );
}
