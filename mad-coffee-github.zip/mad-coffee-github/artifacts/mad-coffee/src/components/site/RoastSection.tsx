import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { useLang, type L } from "@/lib/i18n";
import RoastScene3D from "./RoastScene3D";
import RoastSection2D from "./RoastSection2D";

const hasWebGL = () => {
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (!gl) return false;
    gl.getExtension("WEBGL_lose_context")?.loseContext();
    return true;
  } catch { return false; }
};

const STEPS: { t: L; d: L; from: number }[] = [
  { from: 0, t: { az: "Yaşıl dənələr", ru: "Зелёные зёрна", en: "Green beans" }, d: { az: "Xam qəhvə dənələri göydən yağır. Hələ qoxusu yoxdur.", ru: "Сырые зёрна сыплются с неба. Аромата пока нет.", en: "Raw coffee beans rain down. No aroma yet." } },
  { from: 0.06, t: { az: "Bir dənənin ardınca", ru: "За одним зерном", en: "Follow one bean" }, d: { az: "Kamera bir dənəyə qoşulub maşına doğru enir.", ru: "Камера пристраивается к одному зерну и падает к машине.", en: "The camera locks onto one bean and drops toward the machine." } },
  { from: 0.22, t: { az: "Roasterin qarşısında", ru: "Перед обжарщиком", en: "At the roaster" }, d: { az: "Yaşıl dənələr huni vasitəsilə barabana tökülür, kamera maşının qarşısına keçir.", ru: "Зелёные зёрна сыплются через воронку в барабан, камера выходит к фасаду.", en: "Green beans pour through the hopper while the camera settles in front of the roaster." } },
  { from: 0.36, t: { az: "Qurutma", ru: "Сушка", en: "Drying" }, d: { az: "Rütubət buxara çevrilir, yaşıl rəng solur.", ru: "Влага уходит паром, зелень блёкнет.", en: "Moisture leaves as steam and the green fades." } },
  { from: 0.51, t: { az: "Maillard reaksiyası", ru: "Реакция Майяра", en: "Maillard" }, d: { az: "Şəkərlər və amin turşuları görüşür — aromat doğulur.", ru: "Сахара встречают аминокислоты — рождается аромат.", en: "Sugars meet amino acids and the aroma is born." } },
  { from: 0.65, t: { az: "Birinci çatlama", ru: "Первый крэк", en: "First crack" }, d: { az: "196°C-də dənələr popkorn kimi çatlayır.", ru: "При 196°C зёрна трескаются, как попкорн.", en: "At 196°C the beans crack like popcorn." } },
  { from: 0.73, t: { az: "İnkişaf", ru: "Развитие", en: "Development" }, d: { az: "Dad burada həll olunur: saniyələr hər şeyi dəyişir.", ru: "Здесь решается вкус: секунды меняют всё.", en: "Flavour is decided here: seconds change everything." } },
  { from: 0.79, t: { az: "İkinci çatlama", ru: "Второй крэк", en: "Second crack" }, d: { az: "Yağlar səthə çıxır. Biz adətən bu xəttdən əvvəl dayanırıq.", ru: "Масла выходят на поверхность. Мы обычно тормозим раньше.", en: "Oils surface. We usually stop right before this line." } },
];
const UI = {
  kicker: { az: "Qovurxana", ru: "Обжарочная", en: "The roastery" } as L,
  temp: { az: "Temperatur", ru: "Температура", en: "Temp" } as L,
  time: { az: "Vaxt", ru: "Время", en: "Time" } as L,
  level: { az: "Qovurma", ru: "Обжарка", en: "Roast" } as L,
  hint: { az: "Kursoru dənələrin üstündə gəzdir. Klikləsən qarışdırırsan.", ru: "Води курсором по зёрнам. Клик — перемешать.", en: "Move over the beans. Click to stir them." } as L,
  scrollHint: { az: "Qovurmaq üçün scroll et", ru: "Скролль, чтобы жарить", en: "Scroll to roast" } as L,
  lv: [
    { az: "Yaşıl", ru: "Зелёная", en: "Green" }, { az: "Açıq", ru: "Светлая", en: "Light" },
    { az: "Orta", ru: "Средняя", en: "Medium" }, { az: "Tünd", ru: "Тёмная", en: "Dark" },
  ] as L[],
};

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const rOf = (p: number) => clamp((p - 0.36) / 0.5);
const stepOf = (p: number) => { let s = 0; STEPS.forEach((st, i) => { if (p >= st.from) s = i; }); return s; };
const fmtTime = (r: number) => { const s = Math.round(r * 750); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };
const wordColor = (r: number) => {
  const stops = ["#9fc15a", "#e4cf62", "#d79a52", "#b97a46", "#c58b55", "#c98f5a"];
  return stops[Math.min(stops.length - 1, Math.floor(r * (stops.length - 1) + 0.5))];
};

export default function RoastSection() {
  const [supported] = useState(hasWebGL);
  const [failed, setFailed] = useState(false);
  const handleFail = useCallback(() => setFailed(true), []);
  return supported && !failed ? <RoastSection3D onFail={handleFail} /> : <RoastSection2D />;
}

function RoastSection3D({ onFail }: { onFail: () => void }) {
  const { tr } = useLang();
  const ref = useRef<HTMLElement>(null);
  const pRef = useRef(0);
  const [sceneReady, setSceneReady] = useState(false);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const [p, setP] = useState(0);
  useEffect(() => {
    const section = ref.current;
    if (!section || typeof IntersectionObserver === "undefined") {
      setSceneReady(true);
      return;
    }
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setSceneReady(true);
        observer.disconnect();
      }
    }, { rootMargin: "150% 0px", threshold: 0 });
    observer.observe(section);
    return () => observer.disconnect();
  }, []);
  useMotionValueEvent(scrollYProgress, "change", (v) => { pRef.current = clamp(v); setP(Math.round(clamp(v) * 400) / 400); });

  const r = rOf(p);
  const si = stepOf(p);
  const next = STEPS[si + 1]?.from ?? 1;
  const frac = clamp((p - STEPS[si].from) / (next - STEPS[si].from));
  const temp = Math.round(22 + 210 * r);
  const lv = r < 0.12 ? 0 : r < 0.5 ? 1 : r < 0.78 ? 2 : 3;
  const col = wordColor(r);

  return (
    <section ref={ref} id="roast" className="relative h-[700vh] w-screen bg-[hsl(24_30%_5%)] lg:w-full">
      <div className="sticky top-0 h-[100dvh] w-screen overflow-hidden lg:w-full" style={{ background: "radial-gradient(ellipse 60% 50% at 70% 55%, hsl(24 55% 17% / .9), transparent 70%), radial-gradient(ellipse at 50% 0%, hsl(26 40% 16%), hsl(24 30% 4%) 70%)" }}>
        {sceneReady && <RoastScene3D pRef={pRef} onFail={onFail} />}
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 50%, transparent 55%, hsl(24 30% 3% / .55) 100%)" }} />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-[hsl(24_30%_4%)]/85 via-[hsl(24_30%_4%)]/30 to-transparent lg:via-transparent" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[hsl(24_30%_4%)]/90 to-transparent lg:hidden" />

        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex flex-col gap-3 px-5 pb-8 md:px-10 lg:inset-y-0 lg:w-[44%] lg:justify-center lg:gap-6 lg:pb-0">
          <div className="font-mono text-[11px] uppercase tracking-[0.32em] text-accent/80">{tr(UI.kicker)}</div>
          <h2 className="font-wordmark text-[clamp(2.1rem,5vw,4.8rem)] font-black leading-[0.9] tracking-[-0.06em] text-[hsl(var(--cream))] [text-shadow:0_2px_30px_rgba(0,0,0,0.45)]" data-testid="text-roast-title">
            We <span style={{ color: col }} className="italic transition-colors duration-200">roast</span> coffee.
          </h2>
          <div className="min-h-[5.5rem] lg:min-h-[8rem]">
            <AnimatePresence mode="wait">
              <motion.div key={si} initial={{ opacity: 0, y: 18, filter: "blur(6px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} exit={{ opacity: 0, y: -14, filter: "blur(6px)" }} transition={{ duration: 0.35 }}>
                <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-accent">{String(si + 1).padStart(2, "0")} / {String(STEPS.length).padStart(2, "0")}</div>
                <div className="mt-1 font-wordmark text-2xl uppercase text-[hsl(var(--cream))] md:text-4xl" data-testid="text-roast-step">{tr(STEPS[si].t)}</div>
                <p className="mt-2 max-w-none text-sm text-[hsl(var(--cream))]/75 md:text-base lg:max-w-md">{tr(STEPS[si].d)}</p>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="flex w-full max-w-none gap-1.5 lg:max-w-md">
            {STEPS.map((_, i) => (
              <div key={i} className="h-1 flex-1 overflow-hidden rounded-full bg-[hsl(var(--cream))]/15">
                <div className="h-full origin-left bg-accent" style={{ transform: `scaleX(${i < si ? 1 : i === si ? frac : 0})` }} />
              </div>
            ))}
          </div>
          <div className="grid w-full max-w-none grid-cols-3 gap-4 font-mono text-[11px] uppercase tracking-wider text-[hsl(var(--cream))]/60 lg:max-w-md">
            <div><div>{tr(UI.temp)}</div><div className="mt-1 font-wordmark text-2xl text-[hsl(var(--cream))] md:text-3xl" data-testid="text-roast-temp">{temp}°C</div></div>
            <div><div>{tr(UI.time)}</div><div className="mt-1 font-wordmark text-2xl text-[hsl(var(--cream))] md:text-3xl">{fmtTime(r)}</div></div>
            <div><div>{tr(UI.level)}</div><div className="mt-1 font-wordmark text-2xl md:text-3xl" style={{ color: col }}>{tr(UI.lv[lv])}</div></div>
          </div>
        </div>

        <div className="pointer-events-none absolute right-5 top-20 z-10 hidden font-mono text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--cream))]/50 md:block">
          {p < 0.03 ? tr(UI.scrollHint) : p > 0.34 && p < 0.9 ? tr(UI.hint) : ""}
        </div>
      </div>
    </section>
  );
}
