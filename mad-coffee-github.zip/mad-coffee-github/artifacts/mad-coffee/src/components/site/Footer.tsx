import { motion } from "framer-motion";
import { SiInstagram } from "react-icons/si";
import { type Branch } from "@/lib/data";
import { useLang } from "@/lib/i18n";

export default function Footer({ branches }: { branches: Branch[] }) {
  const { t, tr } = useLang();
  return (
    <footer className="relative overflow-hidden bg-[#090807] text-[hsl(var(--cream))]">
      <div className="mx-auto grid max-w-[1600px] gap-8 px-5 pt-12 sm:grid-cols-2 sm:gap-10 md:pt-10 md:px-10 lg:grid-cols-4">
        <p className="font-display text-3xl italic sm:col-span-2 lg:col-span-2">{t("footerLine")}</p>
        <div className="font-mono text-[11px] uppercase leading-6">
          {branches.map((b) => <p key={b.id}>{tr(b.name)} — {tr(b.hours).split(" ").slice(-3).join(" ")}</p>)}
        </div>
        <div className="flex flex-col gap-2 font-mono text-[11px] uppercase">
          {["menu", "branches", "about", "beans", "contact"].map((id) => <a key={id} href={`#${id}`} className="link-u self-start">{id}</a>)}
          <span className="mt-2 flex items-center gap-2" data-testid="text-footer-social"><SiInstagram /> @mad_coffeeshop</span>
        </div>
      </div>
      <motion.div initial={{ y: "18%" }} whileInView={{ y: "0%" }} viewport={{ once: true }} transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        className="mb-8 mt-12 text-center font-wordmark text-[clamp(5rem,17vw,16rem)] uppercase leading-[0.82] text-[#45413e] sm:mb-12 sm:mt-16">MAD</motion.div>
      <div className="relative mt-6 flex flex-col items-center gap-2 border-t border-[hsl(var(--cream))]/15 bg-[#090807] px-5 py-5 text-center font-mono text-[9px] uppercase text-[hsl(var(--cream))]/55 sm:flex-row sm:justify-between sm:text-left md:px-10">
        <span>© {new Date().getFullYear()} Mad Coffee. {t("rights")}</span><span>Bakı · Баку · Baku</span>
      </div>
    </footer>
  );
}
