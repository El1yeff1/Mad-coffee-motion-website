import { useRef } from "react";
import { ArrowUpRight, Minus, Plus, Trash2 } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetTitle } from "@/components/ui/sheet";
import { img, useLang } from "@/lib/i18n";
import type { BeanSelection, CartLine } from "@/lib/data";

type CartPanelProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: CartLine[];
  onQuantityChange: (id: string, quantity: number) => void;
  onRemove: (id: string) => void;
  onViewProduct: (selection: BeanSelection) => void;
};

const getPrice = (item: CartLine) => item.size === "250" ? item.bean.p250 : item.bean.p1k;

export default function CartPanel({ open, onOpenChange, items, onQuantityChange, onRemove, onViewProduct }: CartPanelProps) {
  const { t, tr } = useLang();
  const pendingProduct = useRef<BeanSelection | null>(null);
  const count = items.reduce((total, item) => total + item.quantity, 0);
  const subtotal = items.reduce((total, item) => total + getPrice(item) * item.quantity, 0);

  const openProduct = (item: CartLine) => {
    pendingProduct.current = { bean: item.bean, size: item.size };
    onOpenChange(false);
  };

  const browseProducts = () => {
    onOpenChange(false);
    document.getElementById("beans")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full border-border bg-card p-0 sm:max-w-md"
        onCloseAutoFocus={(event) => {
          const selection = pendingProduct.current;
          if (!selection) return;
          event.preventDefault();
          pendingProduct.current = null;
          onViewProduct(selection);
        }}
      >
        <div className="flex h-full flex-col">
          <div className="border-b border-border px-5 pb-4 pt-7 sm:px-6">
            <SheetTitle className="pr-8 font-wordmark text-3xl uppercase">{t("bag")}</SheetTitle>
            <SheetDescription className="mt-1">{t("cartCount").replace("{count}", String(count))}</SheetDescription>
          </div>

          <div className="flex-1 overflow-y-auto px-5 sm:px-6">
            {items.length === 0 ? (
              <div className="flex h-full min-h-64 flex-col items-center justify-center text-center">
                <p className="max-w-xs font-display text-2xl italic text-foreground/75">{t("cartEmpty")}</p>
                <button type="button" onClick={browseProducts} data-testid="button-cart-browse"
                  className="mt-6 bg-accent px-5 py-3 font-wordmark text-xs uppercase text-accent-foreground">
                  {t("cartBrowse")}
                </button>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {items.map((item) => {
                  const price = getPrice(item);
                  return (
                    <article key={item.id} className="flex gap-3 py-5" data-testid={`cart-line-${item.bean.id}-${item.size}`}>
                      <button type="button" onClick={() => openProduct(item)} aria-label={tr(item.bean.name)}
                        className="relative h-20 w-16 shrink-0 overflow-hidden bg-background">
                        <img src={img("beans-bag.jpg")} alt="" className="h-full w-full object-cover" />
                        <div className="absolute inset-0 mix-blend-color opacity-70" style={{ background: `hsl(${item.bean.tone})` }} />
                      </button>
                      <div className="min-w-0 flex-1">
                        <h3 className="min-w-0 font-wordmark text-sm uppercase">
                          <button type="button" onClick={() => openProduct(item)} data-testid={`button-cart-view-${item.bean.id}-${item.size}`}
                            className="inline-flex max-w-full items-center gap-1 text-left transition-colors hover:text-accent">
                            <span className="truncate">{tr(item.bean.name)}</span>
                            <ArrowUpRight className="h-3 w-3 shrink-0" />
                          </button>
                        </h3>
                        <p className="mt-1 font-mono text-[10px] uppercase text-muted-foreground">
                          {item.size === "250" ? t("size250") : t("size1k")} · {price} ₼
                        </p>
                        <div className="mt-3 inline-flex items-center border border-border">
                          <button type="button" onClick={() => onQuantityChange(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1} aria-label={t("cartDecrease")} data-testid={`button-cart-decrease-${item.bean.id}-${item.size}`}
                            className="p-2 text-foreground/70 transition-colors hover:text-foreground disabled:cursor-not-allowed disabled:opacity-30">
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="min-w-8 text-center font-mono text-xs" data-testid={`text-cart-quantity-${item.bean.id}-${item.size}`}>{item.quantity}</span>
                          <button type="button" onClick={() => onQuantityChange(item.id, item.quantity + 1)}
                            aria-label={t("cartIncrease")} data-testid={`button-cart-increase-${item.bean.id}-${item.size}`}
                            className="p-2 text-foreground/70 transition-colors hover:text-foreground">
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-col items-end justify-between">
                        <span className="font-wordmark text-sm text-primary">{price * item.quantity} ₼</span>
                        <button type="button" onClick={() => onRemove(item.id)} aria-label={`${t("cartRemove")} ${tr(item.bean.name)}`}
                          data-testid={`button-cart-remove-${item.bean.id}-${item.size}`}
                          className="p-2 text-muted-foreground transition-colors hover:text-accent">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>

          {items.length > 0 && (
            <div className="border-t border-border bg-background/50 px-5 py-5 sm:px-6">
              <div className="flex items-center justify-between font-mono text-xs uppercase">
                <span className="text-muted-foreground">{t("cartSubtotal")}</span>
                <span className="font-wordmark text-2xl text-primary" data-testid="text-cart-subtotal">{subtotal} ₼</span>
              </div>
              <p className="mt-3 font-mono text-[10px] text-muted-foreground">{t("cartNote")}</p>
              <button type="button" onClick={browseProducts} data-testid="button-cart-continue"
                className="mt-4 w-full border border-border px-4 py-3 font-mono text-[11px] uppercase tracking-wider transition-colors hover:border-primary">
                {t("cartBrowse")}
              </button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
