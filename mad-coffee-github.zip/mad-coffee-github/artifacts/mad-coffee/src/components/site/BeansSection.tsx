import { useEffect, useRef } from "react";
import { motion, useMotionValue, useMotionValueEvent, useScroll } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetTitle } from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { beans, type Bean, type BeanSelection } from "@/lib/data";
import { img, useLang } from "@/lib/i18n";
import { Kicker, SplitWords } from "./motion";

function RoastMeter({ level }: { level: number }) {
  return <div className="flex gap-1">{[1, 2, 3].map((n) => <span key={n} className={`h-1.5 w-6 ${n <= level ? "bg-primary" : "bg-border"}`} />)}</div>;
}

export default function BeansSection({ onAdd, selection, onSelectionChange }: {
  onAdd: (bean: Bean, size: "250" | "1k") => void;
  selection: BeanSelection | null;
  onSelectionChange: (selection: BeanSelection | null) => void;
}) {
  const { t, tr } = useLang();
  const { toast } = useToast();
  const sel = selection?.bean ?? null;
  const size = selection?.size ?? "250";
  const ref = useRef<HTMLElement>(null);
  const stickyRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const maxTravel = useRef(0);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const x = useMotionValue(0);
  useMotionValueEvent(scrollYProgress, "change", (progress) => {
    x.set(-progress * maxTravel.current);
  });
  useEffect(() => {
    const measure = () => {
      const viewportWidth = stickyRef.current?.clientWidth ?? 0;
      const contentWidth = trackRef.current?.scrollWidth ?? 0;
      maxTravel.current = Math.max(0, contentWidth - viewportWidth);
      x.set(-scrollYProgress.get() * maxTravel.current);
    };
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    if (stickyRef.current) observer?.observe(stickyRef.current);
    if (trackRef.current) observer?.observe(trackRef.current);
    window.addEventListener("resize", measure);
    return () => {
      observer?.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [scrollYProgress, x]);
  const titleLines = t("beansTitle").split(". ").map((line, index, lines) =>
    index < lines.length - 1 ? `${line}.` : line,
  );
  return (
    <section id="beans" ref={ref} className="relative h-[300vh] bg-[hsl(var(--cream))] text-background">
      <div ref={stickyRef} className="sticky top-0 flex h-[100dvh] flex-col justify-center overflow-hidden">
        <div className="mx-auto w-full max-w-[1600px] px-5 md:px-10">
          <Kicker>{t("beansKicker")}</Kicker>
          <h2 className="mt-3 flex flex-col font-display text-[clamp(1.75rem,9vw,2.5rem)] leading-[0.95] md:text-7xl">
            {titleLines.map((line, index) => (
              <span key={`${index}-${line}`} className="block w-max whitespace-nowrap">
                <SplitWords text={line} className="whitespace-nowrap" />
              </span>
            ))}
          </h2>
        </div>
        <motion.div ref={trackRef} style={{ x }} className="mt-10 flex w-max gap-6 pl-5 md:pl-10">
          {beans.map((b, i) => (
            <motion.button key={b.id} onClick={() => onSelectionChange({ bean: b, size: "250" })} data-testid={`card-bean-${b.id}`} whileHover={{ y: -12, rotate: i % 2 ? 1.5 : -1.5 }}
              className="group relative flex h-[56vh] w-[78vw] shrink-0 flex-col overflow-hidden bg-background text-left text-foreground sm:w-[46vw] lg:w-[30vw]">
              <div className="relative h-[58%] shrink-0 overflow-hidden">
                <img src={img("beans-bag.jpg")} alt={tr(b.name)} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 mix-blend-color opacity-70" style={{ background: `hsl(${b.tone})` }} />
                <span className="absolute left-4 top-4 font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--cream))]">0{i + 1} / 0{beans.length}</span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <div className="flex h-4 shrink-0 items-center justify-between font-mono text-[10px] uppercase text-muted-foreground"><span className="min-w-0 truncate whitespace-nowrap">{tr(b.process)}</span><RoastMeter level={b.roast} /></div>
                <h3 className="mt-2 h-12 shrink-0 overflow-hidden font-wordmark text-2xl uppercase leading-none line-clamp-2 md:h-auto md:text-3xl md:line-clamp-none">
                  {b.id === "ken"
                    ? <>{tr(b.name).split(" ")[0]}{" "}<br className="md:hidden" />{tr(b.name).split(" ").slice(1).join(" ")}</>
                    : tr(b.name)}
                </h3>
                <p className="mt-2 font-display text-[clamp(0.8rem,4vw,0.95rem)] leading-[1.15] italic text-foreground/70 md:text-lg md:leading-normal">{tr(b.notes)}</p>
                <div className="mt-auto flex items-center justify-between">
                <span className="whitespace-nowrap font-wordmark text-xl text-primary">{b.p250} ₼ <span className="font-mono text-[10px] text-muted-foreground">/ 250g</span></span>
                  <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-2 group-hover:text-accent" />
                </div>
              </div>
            </motion.button>
          ))}
          <div className="w-[10vw] shrink-0" />
        </motion.div>
        <div className="mx-auto mt-8 h-px w-[calc(100%-2.5rem)] max-w-[1520px] bg-background/20">
          <motion.div style={{ scaleX: scrollYProgress }} className="h-px origin-left bg-accent" />
        </div>
      </div>
      <Sheet open={!!selection} onOpenChange={(o) => !o && onSelectionChange(null)}>
        <SheetContent side="right" className="h-[100dvh] max-h-[100dvh] w-full overflow-y-auto overscroll-contain touch-pan-y [-webkit-overflow-scrolling:touch] border-border bg-card p-0 sm:h-full sm:max-h-none sm:max-w-lg">
          {sel && (
            <div className="flex h-[calc(100dvh-1.25rem)] min-h-[calc(100dvh-1.25rem)] flex-col">
              <div className="relative h-[38dvh] min-h-48 shrink-0 sm:h-[40dvh] md:h-72">
                <img src={img("beans-bag.jpg")} alt="" className="h-full w-full object-cover" />
                <div className="absolute inset-0 mix-blend-color opacity-70" style={{ background: `hsl(${sel.tone})` }} />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
              </div>
              <div className="-mt-8 relative flex min-h-0 flex-1 flex-col p-4 sm:-mt-10 sm:p-6 md:-mt-12 md:p-7">
                <SheetTitle className="font-wordmark text-3xl uppercase leading-none sm:text-3xl md:text-4xl">{tr(sel.name)}</SheetTitle>
                <SheetDescription className="mt-3 font-display text-lg italic text-foreground/80 md:text-xl">{tr(sel.desc)}</SheetDescription>
                <dl className="mt-5 grid grid-cols-2 gap-x-3 gap-y-4 border-y border-border py-4 font-mono text-[11px] uppercase sm:mt-5 sm:gap-4 sm:py-4 sm:text-xs">
                  <div><dt className="text-muted-foreground">{t("origin")}</dt><dd className="mt-1">{tr(sel.origin)}</dd></div>
                  <div><dt className="text-muted-foreground">{t("process")}</dt><dd className="mt-1">{tr(sel.process)}</dd></div>
                  <div><dt className="text-muted-foreground">{t("roast")}</dt><dd className="mt-2"><RoastMeter level={sel.roast} /></dd></div>
                  <div><dt className="text-muted-foreground">{t("brew")}</dt><dd className="mt-1">{tr(sel.brew)}</dd></div>
                  <div className="col-span-2"><dt className="text-muted-foreground">{t("notes")}</dt><dd className="mt-1 normal-case">{tr(sel.notes)}</dd></div>
                </dl>
                <div className="mt-5 inline-flex border border-border p-1">
                  {(["250", "1k"] as const).map((s) => (
                    <button key={s} onClick={() => selection && onSelectionChange({ ...selection, size: s })} data-testid={`button-size-${s}`} className={`relative px-4 py-2 font-mono text-[11px] uppercase sm:px-5 sm:text-xs ${size === s ? "text-background" : "text-foreground/60"}`}>
                      {size === s && <motion.span layoutId="size" className="absolute inset-0 bg-primary" />}
                      <span className="relative">{s === "250" ? "250 g" : "1 kg"}</span>
                    </button>
                  ))}
                </div>
                <div className="mt-auto flex items-center justify-between gap-3 pt-5 sm:gap-4">
                  <motion.span key={size} initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} data-testid="text-bean-price" className="inline-flex shrink-0 items-baseline whitespace-nowrap font-wordmark text-4xl text-primary sm:text-4xl md:text-5xl">{size === "250" ? sel.p250 : sel.p1k}<span className="ml-1 text-[0.65em]">₼</span></motion.span>
                  <button data-testid="button-add-to-cart" onClick={() => { onAdd(sel, size); toast({ title: tr(sel.name), description: t("addedToCart") }); onSelectionChange(null); }}
                    className="shrink-0 whitespace-nowrap bg-accent px-4 py-2 font-wordmark text-[11px] uppercase leading-tight text-accent-foreground transition-transform hover:-rotate-2 sm:px-5 sm:py-3 sm:text-sm">{t("addToCart")}</button>
                </div>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </section>
  );
}
