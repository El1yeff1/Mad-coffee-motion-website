import { useState, type FormEvent, type ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetAdminDataQueryKey,
  getGetAdminSessionQueryKey,
  getGetSiteDataQueryKey,
  useAdminLogin,
  useAdminLogout,
  useCreateBranch,
  useCreateContentBlock,
  useCreateMenuItem,
  useDeleteContentBlock,
  useGetAdminData,
  useGetAdminSession,
  useUpdateBranch,
  useUpdateContentBlock,
  useUpdateMenuItem,
} from '@workspace/api-client-react';
import type {
  Branch,
  BranchInput,
  ContentBlock,
  ContentBlockInput,
  ContentBlockStatus,
  LocalizedText,
  MenuItem,
  MenuItemInput,
} from '@workspace/api-client-react';
import {
  Coffee,
  FileText,
  LayoutDashboard,
  LogOut,
  MapPin,
  Pencil,
  Plus,
  RefreshCw,
  Save,
  Store,
  Trash2,
  X,
} from 'lucide-react';

type Section = 'overview' | 'menu' | 'branches' | 'content';
type Editor =
  | { kind: 'menu'; item?: MenuItem }
  | { kind: 'branch'; item?: Branch }
  | { kind: 'content'; item?: ContentBlock };
type Flash = { text: string; error?: boolean };

const emptyLocalized = (): LocalizedText => ({ az: '', ru: '', en: '' });
const errorMessage = (error: unknown) =>
  error instanceof Error ? error.message : 'Something went wrong. Please try again.';
const safeLocalized = (text?: LocalizedText) => text ?? emptyLocalized();
const menuCategories = [
  ['espresso', 'Espresso based'],
  ['filter', 'Filter / V60'],
  ['cold', 'Cold coffee'],
  ['matcha', 'Matcha / tea'],
  ['dessert', 'Desserts & bakery'],
] as const;

function LocalizedFields({
  title,
  value,
  onChange,
  multiline = false,
}: {
  title: string;
  value: LocalizedText;
  onChange: (next: LocalizedText) => void;
  multiline?: boolean;
}) {
  const languages: Array<keyof LocalizedText> = ['az', 'ru', 'en'];
  return (
    <div className="admin-locale-grid">
      {languages.map((language) => (
        <div className="admin-field" key={language}>
          <div className="admin-locale-title">{language.toUpperCase()} · {title}</div>
          {multiline ? (
            <textarea
              aria-label={`${title} in ${language.toUpperCase()}`}
              data-testid={`input-${title.toLowerCase().replaceAll(' ', '-')}-${language}`}
              value={value[language]}
              onChange={(event) => onChange({ ...value, [language]: event.target.value })}
            />
          ) : (
            <input
              aria-label={`${title} in ${language.toUpperCase()}`}
              data-testid={`input-${title.toLowerCase().replaceAll(' ', '-')}-${language}`}
              value={value[language]}
              onChange={(event) => onChange({ ...value, [language]: event.target.value })}
              required
            />
          )}
        </div>
      ))}
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return <label className="admin-field"><span>{label}</span>{children}</label>;
}

function MenuEditor({
  item,
  saving,
  onSave,
  onCancel,
}: {
  item?: MenuItem;
  saving: boolean;
  onSave: (data: MenuItemInput) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState<MenuItemInput>(() => ({
    category: item?.category ?? '',
    name: safeLocalized(item?.name),
    description: safeLocalized(item?.description),
    price: item?.price ?? 0,
    volume: item?.volume ?? '',
    tastingNotes: safeLocalized(item?.tastingNotes),
    image: item?.image ?? '',
    signature: item?.signature ?? false,
    available: item?.available ?? true,
  }));
  const submit = (event: FormEvent) => {
    event.preventDefault();
    onSave(form);
  };
  return (
    <form onSubmit={submit}>
      <div className="admin-editor-section">
        <h3 className="admin-section-title">Product identity</h3>
        <Field label="Category">
          <select required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} data-testid="input-menu-category">
            <option value="" disabled>Select a category</option>
            {menuCategories.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
        </Field>
        <LocalizedFields title="Name" value={form.name} onChange={(name) => setForm({ ...form, name })} />
        <LocalizedFields title="Description" value={form.description} onChange={(description) => setForm({ ...form, description })} multiline />
        <LocalizedFields title="Tasting notes" value={form.tastingNotes} onChange={(tastingNotes) => setForm({ ...form, tastingNotes })} />
      </div>
      <div className="admin-editor-section">
        <h3 className="admin-section-title">Service details</h3>
        <div className="admin-locale-grid">
          <Field label="Price · AZN">
            <input type="number" min="0" step="0.01" required value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} data-testid="input-menu-price" />
          </Field>
          <Field label="Volume">
            <input required value={form.volume} onChange={(e) => setForm({ ...form, volume: e.target.value })} placeholder="180 ml" data-testid="input-menu-volume" />
          </Field>
          <Field label="Image path">
            <input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="menu-drinks.jpg" data-testid="input-menu-image" />
          </Field>
        </div>
        <div className="admin-checkbox-row">
          <label className="admin-check"><input type="checkbox" checked={Boolean(form.signature)} onChange={(e) => setForm({ ...form, signature: e.target.checked })} /> Signature item</label>
          <label className="admin-check"><input type="checkbox" checked={Boolean(form.available)} onChange={(e) => setForm({ ...form, available: e.target.checked })} /> Available to order</label>
        </div>
      </div>
      <EditorFooter saving={saving} onCancel={onCancel} />
    </form>
  );
}

function BranchEditor({
  item,
  saving,
  onSave,
  onCancel,
}: {
  item?: Branch;
  saving: boolean;
  onSave: (data: BranchInput) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState<BranchInput>(() => ({
    name: safeLocalized(item?.name),
    area: safeLocalized(item?.area),
    address: safeLocalized(item?.address),
    hours: safeLocalized(item?.hours),
    phone: item?.phone ?? '',
    lat: item?.lat ?? 40.4093,
    lng: item?.lng ?? 49.8671,
    image: item?.image ?? '',
    active: item?.active ?? true,
  }));
  const submit = (event: FormEvent) => {
    event.preventDefault();
    onSave(form);
  };
  return (
    <form onSubmit={submit}>
      <div className="admin-editor-section">
        <h3 className="admin-section-title">Branch identity</h3>
        <LocalizedFields title="Name" value={form.name} onChange={(name) => setForm({ ...form, name })} />
        <LocalizedFields title="Area" value={form.area} onChange={(area) => setForm({ ...form, area })} />
        <LocalizedFields title="Address" value={form.address} onChange={(address) => setForm({ ...form, address })} />
        <LocalizedFields title="Hours" value={form.hours} onChange={(hours) => setForm({ ...form, hours })} />
      </div>
      <div className="admin-editor-section">
        <h3 className="admin-section-title">Visit details</h3>
        <div className="admin-locale-grid">
          <Field label="Phone"><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} data-testid="input-branch-phone" /></Field>
          <Field label="Latitude"><input type="number" step="any" value={form.lat} onChange={(e) => setForm({ ...form, lat: Number(e.target.value) })} data-testid="input-branch-latitude" /></Field>
          <Field label="Longitude"><input type="number" step="any" value={form.lng} onChange={(e) => setForm({ ...form, lng: Number(e.target.value) })} data-testid="input-branch-longitude" /></Field>
        </div>
        <Field label="Image path"><input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="interior-1.jpg" data-testid="input-branch-image" /></Field>
        <div className="admin-checkbox-row"><label className="admin-check"><input type="checkbox" checked={Boolean(form.active)} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Branch is active</label></div>
      </div>
      <EditorFooter saving={saving} onCancel={onCancel} />
    </form>
  );
}

function ContentEditor({
  item,
  saving,
  onSave,
  onCancel,
}: {
  item?: ContentBlock;
  saving: boolean;
  onSave: (data: ContentBlockInput) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState<ContentBlockInput>(() => ({
    title: safeLocalized(item?.title),
    body: safeLocalized(item?.body),
    status: item?.status ?? 'draft',
  }));
  const submit = (event: FormEvent) => {
    event.preventDefault();
    onSave(form);
  };
  return (
    <form onSubmit={submit}>
      <div className="admin-editor-section">
        <h3 className="admin-section-title">Copy across languages</h3>
        <LocalizedFields title="Title" value={form.title} onChange={(title) => setForm({ ...form, title })} />
        <LocalizedFields title="Body" value={form.body} onChange={(body) => setForm({ ...form, body })} multiline />
      </div>
      <div className="admin-editor-section">
        <h3 className="admin-section-title">Publication</h3>
        <Field label="Status">
          <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as ContentBlockStatus })} data-testid="select-content-status">
            <option value="draft">Draft</option><option value="published">Published</option><option value="archived">Archived</option>
          </select>
        </Field>
      </div>
      <EditorFooter saving={saving} onCancel={onCancel} />
    </form>
  );
}

function EditorFooter({ saving, onCancel }: { saving: boolean; onCancel: () => void }) {
  return (
    <div className="admin-editor-foot">
      <span className="admin-staff">{saving ? 'Saving changes…' : 'All fields are saved to the server.'}</span>
      <div>
        <button type="button" className="admin-button admin-button-quiet" onClick={onCancel} data-testid="button-cancel-edit">Cancel</button>
        <button type="submit" className="admin-button admin-button-primary" disabled={saving} data-testid="button-save-record"><Save size={14} />{saving ? 'Saving…' : 'Save changes'}</button>
      </div>
    </div>
  );
}

function StatusTag({ status }: { status: string }) {
  const label = status === 'published' ? 'Published' : status === 'draft' ? 'Draft' : status === 'archived' ? 'Archived' : status;
  return <span className={`admin-tag ${status === 'published' ? 'is-live' : status === 'draft' ? 'is-draft' : 'is-archived'}`}>{label}</span>;
}

function AdminLoading() {
  return (
    <div className="admin-shell" aria-label="Loading workspace">
      <div className="admin-workspace">
        <aside className="admin-sidebar"><div className="admin-sidebar-brand"><div className="admin-brand-mark">Z</div></div></aside>
        <main className="admin-main"><div className="admin-topbar" /><div className="admin-content"><div className="admin-skeleton" /><div className="admin-skeleton" /><div className="admin-skeleton" /></div></main>
      </div>
    </div>
  );
}

export default function Admin() {
  const queryClient = useQueryClient();
  const session = useGetAdminSession({ query: { queryKey: getGetAdminSessionQueryKey(), retry: false } });
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [section, setSection] = useState<Section>('overview');
  const [editor, setEditor] = useState<Editor | null>(null);
  const [flash, setFlash] = useState<Flash | null>(null);
  const dataQuery = useGetAdminData({
    query: {
      queryKey: getGetAdminDataQueryKey(),
      enabled: Boolean(session.data?.authenticated),
      retry: false,
    },
  });
  const refreshData = () => Promise.all([
    queryClient.invalidateQueries({ queryKey: getGetAdminDataQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getGetSiteDataQueryKey() }),
  ]);
  const showSaved = () => {
    setFlash({ text: 'Saved. The public site data is up to date.' });
    window.setTimeout(() => setFlash(null), 3200);
    setEditor(null);
    void refreshData();
  };
  const login = useAdminLogin({
    mutation: {
      onSuccess: () => {
        setLoginError('');
        void queryClient.invalidateQueries({ queryKey: getGetAdminSessionQueryKey() });
      },
      onError: (error) => setLoginError(errorMessage(error)),
    },
  });
  const logout = useAdminLogout({
    mutation: {
      onSuccess: () => {
        void queryClient.invalidateQueries({ queryKey: getGetAdminSessionQueryKey() });
        void queryClient.removeQueries({ queryKey: getGetAdminDataQueryKey() });
        setEditor(null);
      },
    },
  });
  const createMenu = useCreateMenuItem({ mutation: { onSuccess: showSaved, onError: (e) => setFlash({ text: errorMessage(e), error: true }) } });
  const updateMenu = useUpdateMenuItem({ mutation: { onSuccess: showSaved, onError: (e) => setFlash({ text: errorMessage(e), error: true }) } });
  const createBranch = useCreateBranch({ mutation: { onSuccess: showSaved, onError: (e) => setFlash({ text: errorMessage(e), error: true }) } });
  const updateBranch = useUpdateBranch({ mutation: { onSuccess: showSaved, onError: (e) => setFlash({ text: errorMessage(e), error: true }) } });
  const createContent = useCreateContentBlock({ mutation: { onSuccess: showSaved, onError: (e) => setFlash({ text: errorMessage(e), error: true }) } });
  const updateContent = useUpdateContentBlock({ mutation: { onSuccess: showSaved, onError: (e) => setFlash({ text: errorMessage(e), error: true }) } });
  const deleteContent = useDeleteContentBlock({
    mutation: {
      onSuccess: () => {
        setFlash({ text: 'Content block removed.' });
        window.setTimeout(() => setFlash(null), 3200);
        void refreshData();
      },
      onError: (e) => setFlash({ text: errorMessage(e), error: true }),
    },
  });
  const data = dataQuery.data;

  if (session.isLoading) return <AdminLoading />;
  if (!session.data?.authenticated) {
    return (
      <div className="admin-shell admin-login">
        <section className="admin-login-art">
          <div className="admin-art-top"><div className="admin-art-wordmark">MAD COFFEE</div></div>
          <div className="admin-art-copy">
            <div className="admin-art-kicker">Baku · Staff control room</div>
            <h1>Keep the details<br />sharp.</h1>
            <p>One careful edit keeps every menu, address and line of copy true across the city.</p>
          </div>
          <div className="admin-art-bottom"><span>Menu · branches · words</span><span>40° 22′ N / 49° 53′ E</span></div>
        </section>
        <main className="admin-login-pane">
          <div className="admin-login-card">
            <div className="admin-eyebrow">Staff access / 01</div>
            <h2>Welcome back.</h2>
            <p>Sign in with your Mad Coffee staff credentials to manage the published site.</p>
            {loginError && <div role="alert" className="admin-error" data-testid="status-login-error">{loginError}</div>}
            <form onSubmit={(event) => {
              event.preventDefault();
              setLoginError('');
              login.mutate({ data: credentials });
            }}>
              <Field label="Username"><input autoComplete="username" required value={credentials.username} onChange={(e) => setCredentials({ ...credentials, username: e.target.value })} data-testid="input-admin-username" /></Field>
              <Field label="Password"><input type="password" autoComplete="current-password" required value={credentials.password} onChange={(e) => setCredentials({ ...credentials, password: e.target.value })} data-testid="input-admin-password" /></Field>
              <button className="admin-button admin-button-primary" style={{ width: '100%', marginTop: 10 }} disabled={login.isPending} type="submit" data-testid="button-admin-login">
                {login.isPending ? 'Checking credentials…' : 'Enter control room'} <span aria-hidden="true">↗</span>
              </button>
            </form>
            <p style={{ marginTop: 20, marginBottom: 0, fontSize: 10 }}>Session is secured by an httpOnly browser cookie.</p>
          </div>
        </main>
      </div>
    );
  }

  if (dataQuery.isLoading) return <AdminLoading />;
  if (dataQuery.isError || !data) {
    return (
      <div className="admin-shell">
        <div className="admin-workspace">
          <aside className="admin-sidebar"><div className="admin-sidebar-brand"><div className="admin-brand-mark">M</div><div className="admin-brand-copy"><div className="admin-brand-name">MAD COFFEE</div><div className="admin-brand-sub">BAKU / ADMIN</div></div></div></aside>
          <main className="admin-main">
            <header className="admin-topbar"><div className="admin-crumb">Mad / Workspace unavailable</div><button className="admin-button admin-button-quiet" onClick={() => logout.mutate()} data-testid="button-admin-logout-error"><LogOut size={14} /> Sign out</button></header>
            <section className="admin-content"><div className="admin-empty admin-panel" style={{ marginTop: 45 }}>
              <div className="admin-empty-mark"><RefreshCw size={19} /></div><h3>We could not open the control room.</h3>
              <p>{errorMessage(dataQuery.error)} Your changes are safe; try loading the workspace again.</p>
              <button className="admin-button admin-button-primary" onClick={() => void dataQuery.refetch()} data-testid="button-retry-admin-data"><RefreshCw size={14} /> Try again</button>
            </div></section>
          </main>
        </div>
      </div>
    );
  }

  const menuItems = data.allMenu ?? data.menu ?? [];
  const branches = data.allBranches ?? data.branches ?? [];
  const contentBlocks = data.allContent ?? data.content ?? [];
  const mutationsPending = createMenu.isPending || updateMenu.isPending || createBranch.isPending || updateBranch.isPending || createContent.isPending || updateContent.isPending;
  const sectionTitle: Record<Section, string> = { overview: 'Workspace overview', menu: 'Menu products', branches: 'Branches', content: 'Content blocks' };
  const edit = (next: Editor) => setEditor(next);
  const openNew = (kind: Editor['kind']) => {
    setEditor(kind === 'menu' ? { kind } : kind === 'branch' ? { kind } : { kind });
  };
  const saveMenu = (form: MenuItemInput) => {
    if (editor?.kind !== 'menu') return;
    if (editor.item) updateMenu.mutate({ id: editor.item.id, data: form });
    else createMenu.mutate({ data: form });
  };
  const saveBranch = (form: BranchInput) => {
    if (editor?.kind !== 'branch') return;
    if (editor.item) updateBranch.mutate({ id: editor.item.id, data: form });
    else createBranch.mutate({ data: form });
  };
  const saveContent = (form: ContentBlockInput) => {
    if (editor?.kind !== 'content') return;
    if (editor.item) updateContent.mutate({ id: editor.item.id, data: form });
    else createContent.mutate({ data: form });
  };
  const updateAvailability = (item: MenuItem) => updateMenu.mutate(
    { id: item.id, data: { available: !item.available } },
    { onSuccess: () => { setFlash({ text: item.available ? 'Product marked unavailable.' : 'Product is available again.' }); window.setTimeout(() => setFlash(null), 2800); void refreshData(); } },
  );
  const updateBranchActivity = (branch: Branch) => updateBranch.mutate(
    { id: branch.id, data: { active: !branch.active } },
    { onSuccess: () => { setFlash({ text: branch.active ? 'Branch paused.' : 'Branch is active.' }); window.setTimeout(() => setFlash(null), 2800); void refreshData(); } },
  );
  const setContentStatus = (block: ContentBlock, status: ContentBlockStatus) => updateContent.mutate(
    { id: block.id, data: { status } },
    { onSuccess: () => { setFlash({ text: `Content set to ${status}.` }); window.setTimeout(() => setFlash(null), 2800); void refreshData(); } },
  );
  const startDelete = (block: ContentBlock) => {
    if (window.confirm(`Delete “${block.title.en || block.title.az}”? This cannot be undone.`)) deleteContent.mutate({ id: block.id });
  };

  return (
    <div className="admin-shell">
      <div className="admin-workspace">
        <aside className="admin-sidebar">
          <div className="admin-sidebar-brand">
            <div className="admin-brand-mark">M</div>
            <div className="admin-brand-copy"><div className="admin-brand-name">MAD COFFEE</div><div className="admin-brand-sub">BAKU / ADMIN</div></div>
          </div>
          <div className="admin-nav-label">Control room</div>
          <nav className="admin-nav" aria-label="Admin sections">
            {([
              ['overview', LayoutDashboard, 'Overview'],
              ['menu', Coffee, 'Menu'],
              ['branches', Store, 'Branches'],
              ['content', FileText, 'Content'],
            ] as const).map(([key, Icon, label]) => (
              <button key={key} className={`admin-nav-button ${section === key ? 'active' : ''}`} onClick={() => setSection(key)} data-testid={`nav-admin-${key}`}>
                <Icon size={16} strokeWidth={1.7} /><span>{label}</span>
              </button>
            ))}
          </nav>
          <div className="admin-sidebar-foot"><span className="admin-online">Session active</span><span>v1.0</span></div>
        </aside>
        <main className="admin-main">
          <header className="admin-topbar">
            <div className="admin-crumb">Mad / {sectionTitle[section]}</div>
            <div className="admin-top-actions">
              <span className="admin-staff">Site content · Baku, AZ</span>
              <button className="admin-button admin-button-quiet" onClick={() => logout.mutate()} disabled={logout.isPending} data-testid="button-admin-logout">
                <LogOut size={14} />{logout.isPending ? 'Signing out…' : 'Sign out'}
              </button>
            </div>
          </header>
          <section className="admin-content">
            {section === 'overview' && (
              <>
                <div className="admin-page-head">
                  <div><div className="admin-eyebrow">Live site / control room</div><h1>Good work starts<br className="mobile-break" /> with good details.</h1><p>Keep the public-facing Mad experience accurate in three languages.</p></div>
                  <button className="admin-button admin-button-primary" onClick={() => { setSection('menu'); openNew('menu'); }} data-testid="button-add-menu-overview"><Plus size={15} /> Add a product</button>
                </div>
                <div className="admin-overview">
                  <div className="admin-stat"><div className="admin-stat-label">Site inventory</div><div className="admin-stat-value">{menuItems.length + branches.length + contentBlocks.length}</div><div className="admin-stat-note">managed records</div></div>
                  <div className="admin-stat"><div className="admin-stat-label">Menu products</div><div className="admin-stat-value">{menuItems.length}</div><div className="admin-stat-note">{menuItems.filter((item) => item.available).length} available today</div></div>
                  <div className="admin-stat"><div className="admin-stat-label">Active branches</div><div className="admin-stat-value">{branches.filter((branch) => branch.active).length}<span style={{ color: '#a59a8c', fontSize: 18 }}> / {branches.length}</span></div><div className="admin-stat-note">across Baku</div></div>
                  <div className="admin-stat"><div className="admin-stat-label">Published copy</div><div className="admin-stat-value">{contentBlocks.filter((block) => block.status === 'published').length}</div><div className="admin-stat-note">of {contentBlocks.length} blocks</div></div>
                </div>
                <div className="admin-panel">
                  <div className="admin-toolbar"><h2>Recently managed products</h2><button className="admin-button admin-button-quiet" onClick={() => setSection('menu')} data-testid="button-view-menu">View menu <span aria-hidden="true">→</span></button></div>
                  {menuItems.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Availability</th><th /></tr></thead><tbody>
                    {menuItems.slice(0, 5).map((item) => <tr key={item.id} data-testid={`row-overview-product-${item.id}`}><td><div className="admin-item-name">{item.name.en || item.name.az}</div><div className="admin-item-sub">{item.name.az}</div></td><td>{item.category}</td><td className="admin-metric">{item.price.toFixed(2)} ₼</td><td><StatusTag status={item.available ? 'published' : 'archived'} /></td><td><div className="admin-row-actions"><button className="admin-icon-button" title="Edit product" onClick={() => { setSection('menu'); edit({ kind: 'menu', item }); }} data-testid={`button-edit-product-${item.id}`}><Pencil size={14} /></button></div></td></tr>)}
                  </tbody></table></div> : <EmptyState title="The menu is clear." copy="Add your first product to start maintaining the public menu." action="Add first product" onAction={() => { setSection('menu'); openNew('menu'); }} />}
                </div>
              </>
            )}
            {section === 'menu' && (
              <>
                <div className="admin-page-head"><div><div className="admin-eyebrow">Catalog / {menuItems.length} records</div><h1>Menu products</h1><p>Names, tasting notes, price and availability in one place.</p></div><button className="admin-button admin-button-primary" onClick={() => openNew('menu')} data-testid="button-add-menu"><Plus size={15} /> New product</button></div>
                <div className="admin-panel"><div className="admin-toolbar"><h2>All products</h2><span>{menuItems.filter((item) => item.available).length} available · prices in AZN</span></div>
                  {menuItems.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Volume</th><th>Status</th><th>Actions</th></tr></thead><tbody>
                    {menuItems.map((item) => <tr key={item.id} data-testid={`row-menu-${item.id}`}><td><div className="admin-item-name">{item.name.en || item.name.az}</div><div className="admin-item-sub">{item.signature ? 'Signature · ' : ''}{item.name.az || item.id}</div></td><td>{item.category}</td><td className="admin-metric">{item.price.toFixed(2)} ₼</td><td className="admin-metric">{item.volume}</td><td><button onClick={() => updateAvailability(item)} style={{ border: 0, background: 'transparent', padding: 0, cursor: 'pointer' }} title="Toggle availability" data-testid={`button-toggle-availability-${item.id}`}><StatusTag status={item.available ? 'published' : 'archived'} /></button></td><td><div className="admin-row-actions"><button className="admin-icon-button" title="Edit product" onClick={() => edit({ kind: 'menu', item })} data-testid={`button-edit-menu-${item.id}`}><Pencil size={14} /></button></div></td></tr>)}
                  </tbody></table></div> : <EmptyState title="Nothing on the menu yet." copy="Create a product with its name and details in Azerbaijani, Russian and English." action="Create product" onAction={() => openNew('menu')} />}</div>
              </>
            )}
            {section === 'branches' && (
              <>
                <div className="admin-page-head"><div><div className="admin-eyebrow">City locations / {branches.length} records</div><h1>Branches</h1><p>Keep each address and opening hour exact, in every language.</p></div><button className="admin-button admin-button-primary" onClick={() => openNew('branch')} data-testid="button-add-branch"><Plus size={15} /> Add branch</button></div>
                <div className="admin-panel"><div className="admin-toolbar"><h2>Baku locations</h2><span>{branches.filter((branch) => branch.active).length} open to the public</span></div>
                  {branches.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Branch</th><th>Address</th><th>Hours · AZ</th><th>Phone</th><th>Status</th><th>Actions</th></tr></thead><tbody>
                    {branches.map((branch) => <tr key={branch.id} data-testid={`row-branch-${branch.id}`}><td><div className="admin-item-name">{branch.name.en || branch.name.az}</div><div className="admin-item-sub">{branch.area.en || branch.area.az}</div></td><td><div>{branch.address.en || branch.address.az}</div><div className="admin-item-sub"><MapPin size={10} style={{ verticalAlign: 'middle' }} /> {branch.lat.toFixed(4)}, {branch.lng.toFixed(4)}</div></td><td>{branch.hours.az}</td><td className="admin-metric">{branch.phone}</td><td><button onClick={() => updateBranchActivity(branch)} style={{ border: 0, background: 'transparent', padding: 0, cursor: 'pointer' }} title="Toggle branch activity" data-testid={`button-toggle-branch-${branch.id}`}><StatusTag status={branch.active ? 'published' : 'archived'} /></button></td><td><div className="admin-row-actions"><button className="admin-icon-button" title="Edit branch" onClick={() => edit({ kind: 'branch', item: branch })} data-testid={`button-edit-branch-${branch.id}`}><Pencil size={14} /></button></div></td></tr>)}
                  </tbody></table></div> : <EmptyState title="No branches listed." copy="Add a location so guests can find their nearest Mad Coffee." action="Add a branch" onAction={() => openNew('branch')} />}</div>
              </>
            )}
            {section === 'content' && (
              <>
                <div className="admin-page-head"><div><div className="admin-eyebrow">Published site language / {contentBlocks.length} blocks</div><h1>Content blocks</h1><p>Draft, publish or archive the words guests see on the site.</p></div><button className="admin-button admin-button-primary" onClick={() => openNew('content')} data-testid="button-add-content"><Plus size={15} /> New content block</button></div>
                <div className="admin-panel"><div className="admin-toolbar"><h2>Site copy</h2><span>{contentBlocks.filter((block) => block.status === 'published').length} published</span></div>
                  {contentBlocks.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Block</th><th>Preview · English</th><th>Status</th><th>Workflow</th><th>Actions</th></tr></thead><tbody>
                    {contentBlocks.map((block) => <tr key={block.id} data-testid={`row-content-${block.id}`}><td><div className="admin-item-name">{block.title.en || block.title.az}</div><div className="admin-item-sub">{block.id}</div></td><td><div style={{ maxWidth: 330, color: '#756d62', lineHeight: 1.5 }}>{block.body.en}</div></td><td><StatusTag status={block.status} /></td><td><select aria-label={`Set status for ${block.title.en || block.id}`} value={block.status} onChange={(e) => setContentStatus(block, e.target.value as ContentBlockStatus)} data-testid={`select-content-workflow-${block.id}`}><option value="draft">Draft</option><option value="published">Publish</option><option value="archived">Archive</option></select></td><td><div className="admin-row-actions"><button className="admin-icon-button" title="Edit content block" onClick={() => edit({ kind: 'content', item: block })} data-testid={`button-edit-content-${block.id}`}><Pencil size={14} /></button><button className="admin-icon-button" title="Delete content block" onClick={() => startDelete(block)} disabled={deleteContent.isPending} data-testid={`button-delete-content-${block.id}`}><Trash2 size={14} /></button></div></td></tr>)}
                  </tbody></table></div> : <EmptyState title="No copy blocks yet." copy="Create a multilingual block and decide whether it is a draft or ready to publish." action="Create content block" onAction={() => openNew('content')} />}</div>
              </>
            )}
          </section>
        </main>
      </div>
      {editor && (
        <div className="admin-editor-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setEditor(null); }}>
          <aside className="admin-editor" role="dialog" aria-modal="true" aria-label={`Edit ${editor.kind}`}>
            <div className="admin-editor-head"><div><div className="admin-eyebrow">{editor.item ? 'Record / edit' : 'New record'}</div><h2>{editor.item ? 'Edit ' : 'Create '}{editor.kind === 'menu' ? 'product' : editor.kind === 'branch' ? 'branch' : 'content block'}</h2></div><button className="admin-icon-button" onClick={() => setEditor(null)} aria-label="Close editor" data-testid="button-close-editor"><X size={16} /></button></div>
            <div className="admin-editor-body">
              {editor.kind === 'menu' && <MenuEditor key={`menu-${editor.item?.id ?? 'new'}`} item={editor.item} saving={createMenu.isPending || updateMenu.isPending} onSave={saveMenu} onCancel={() => setEditor(null)} />}
              {editor.kind === 'branch' && <BranchEditor key={`branch-${editor.item?.id ?? 'new'}`} item={editor.item} saving={createBranch.isPending || updateBranch.isPending} onSave={saveBranch} onCancel={() => setEditor(null)} />}
              {editor.kind === 'content' && <ContentEditor key={`content-${editor.item?.id ?? 'new'}`} item={editor.item} saving={createContent.isPending || updateContent.isPending} onSave={saveContent} onCancel={() => setEditor(null)} />}
            </div>
          </aside>
        </div>
      )}
      {flash && <div role="status" className={`admin-flash ${flash.error ? 'error' : ''}`} data-testid="status-save-feedback">{flash.text}</div>}
      {mutationsPending && <span className="admin-staff" style={{ position: 'fixed', left: -9999 }}>Saving</span>}
    </div>
  );
}

function EmptyState({ title, copy, action, onAction }: { title: string; copy: string; action: string; onAction: () => void }) {
  return (
    <div className="admin-empty">
      <div className="admin-empty-mark"><Coffee size={20} strokeWidth={1.4} /></div>
      <h3>{title}</h3><p>{copy}</p>
      <button className="admin-button admin-button-quiet" onClick={onAction} data-testid="button-empty-create"><Plus size={14} />{action}</button>
    </div>
  );
}
