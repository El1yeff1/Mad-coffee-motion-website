import { useMemo, useState } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { useGetSiteData } from "@workspace/api-client-react";
import SwirlCanvas from "@/components/site/SwirlCanvas";
import Cursor from "@/components/site/Cursor";
import Header from "@/components/site/Header";
import Hero from "@/components/site/Hero";
import Marquee from "@/components/site/Marquee";
import RoastSection from "@/components/site/RoastSection";
import MenuSection from "@/components/site/MenuSection";
import MenuContactBanner from "@/components/site/MenuContactBanner";
import BranchesSection from "@/components/site/BranchesSection";
import AboutSection from "@/components/site/AboutSection";
import BeansSection from "@/components/site/BeansSection";
import ContactSection from "@/components/site/ContactSection";
import Footer from "@/components/site/Footer";
import { branches, DEMO_PHONE, menu, type BeanSelection, type Branch, type CartLine, type MenuItem } from "@/lib/data";
import PublishedContentSection from "@/components/site/PublishedContentSection";
import { useLang } from "@/lib/i18n";

export default function Home() {
  const { lang, t } = useLang();
  const siteDataQuery = useGetSiteData({
    query: { staleTime: 15_000, refetchInterval: 30_000, refetchOnWindowFocus: true },
  });
  const siteMenu = useMemo<MenuItem[]>(() => siteDataQuery.data
    ? siteDataQuery.data.menu.map((item) => ({
        id: item.id,
        cat: item.category,
        name: item.name,
        desc: item.description,
        price: item.price,
        vol: item.volume,
        notes: item.tastingNotes,
        image: item.image,
        signature: item.signature,
      }))
    : menu, [siteDataQuery.data]);
  const siteBranches = useMemo<Branch[]>(() => (siteDataQuery.data?.branches ?? branches).map((branch) => ({ ...branch, phone: DEMO_PHONE })), [siteDataQuery.data]);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [beanSelection, setBeanSelection] = useState<BeanSelection | null>(null);
  const addToCart = (bean: CartLine["bean"], size: CartLine["size"]) => {
    const id = `${bean.id}-${size}`;
    setCart((current) => {
      const existing = current.find((item) => item.id === id);
      return existing
        ? current.map((item) => item.id === id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...current, { id, bean, size, quantity: 1 }];
    });
  };
  const changeCartQuantity = (id: string, quantity: number) => {
    setCart((current) => quantity < 1
      ? current.filter((item) => item.id !== id)
      : current.map((item) => item.id === id ? { ...item, quantity } : item));
  };
  const removeFromCart = (id: string) => setCart((current) => current.filter((item) => item.id !== id));
  const { scrollYProgress } = useScroll();
  const sx = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });
  return (
    <div className="grain relative min-h-[100dvh] text-foreground">
      <SwirlCanvas />
      <Cursor />
      <motion.div style={{ scaleX: sx }} className="fixed inset-x-0 top-0 z-[70] h-0.5 origin-left bg-accent" />
      <Header cart={cart} onQuantityChange={changeCartQuantity} onRemove={removeFromCart} onViewProduct={setBeanSelection} />
      <main className="relative z-10">
        {siteDataQuery.isError && <div role="alert" data-testid="status-site-data-error" className="border-y border-accent/50 bg-card px-5 py-2 text-center font-mono text-[10px] uppercase tracking-wider text-accent md:text-xs">{t("catalogSyncError")}</div>}
        <Hero />
        <Marquee />
        <RoastSection />
        <MenuSection items={siteMenu} />
        <MenuContactBanner />
        <BranchesSection items={siteBranches} />
        <Marquee reverse />
        <AboutSection />
        <PublishedContentSection blocks={siteDataQuery.data?.content ?? []} lang={lang} />
        <BeansSection onAdd={addToCart} selection={beanSelection} onSelectionChange={setBeanSelection} />
        <ContactSection />
      </main>
      <div className="relative z-10"><Footer branches={siteBranches} /></div>
    </div>
  );
}
