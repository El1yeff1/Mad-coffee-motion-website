# Mad Coffee Demo

A portfolio concept for a specialty coffee shop website. It is an independent demo and is not affiliated with or endorsed by any real coffee business. Contact details and social handles are examples only; no social or phone links are active.

## Run the website

Requirements: Node.js 20+ and pnpm 9+.

```sh
pnpm install
pnpm dev
```

Open the local Vite address shown in the terminal. The public website uses local fallback catalog content when the API is not configured.

## Optional API and admin panel

The API requires PostgreSQL and these environment variables: `DATABASE_URL`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `SESSION_SECRET`, and `PORT=8080`. Keep real values in your local environment; do not commit them. Initialize the schema with `pnpm --filter @workspace/db run push`, then start the API with `pnpm --filter @workspace/api-server run dev`. The Vite development server proxies `/api` to port 8080.

For a deployed version, configure the hosting provider to route `/api` to the API service and serve the built website from `artifacts/mad-coffee/dist`.

Build the website with `pnpm build`.
