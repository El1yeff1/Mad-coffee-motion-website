import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, jsonb, pgTable, real, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export type LocalizedText = { az: string; ru: string; en: string };

export const menuItemsTable = pgTable("menu_items", {
  id: text("id").primaryKey(),
  category: text("category").notNull(),
  name: jsonb("name").$type<LocalizedText>().notNull(),
  description: jsonb("description").$type<LocalizedText>().notNull(),
  price: real("price").notNull(),
  volume: text("volume").notNull(),
  tastingNotes: jsonb("tasting_notes").$type<LocalizedText>().notNull(),
  image: text("image").notNull(),
  signature: boolean("signature").notNull().default(false),
  available: boolean("available").notNull().default(true),
  position: integer("position").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertMenuItemSchema = createInsertSchema(menuItemsTable).omit({ updatedAt: true });
export type InsertMenuItem = z.infer<typeof insertMenuItemSchema>;
export type MenuItem = typeof menuItemsTable.$inferSelect;
