import { createInsertSchema } from "drizzle-zod";
import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import type { LocalizedText } from "./menu-items";

export const contentBlocksTable = pgTable("content_blocks", {
  id: text("id").primaryKey(),
  title: jsonb("title").$type<LocalizedText>().notNull(),
  body: jsonb("body").$type<LocalizedText>().notNull(),
  status: text("status").notNull().default("draft"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertContentBlockSchema = createInsertSchema(contentBlocksTable).omit({ updatedAt: true });
export type InsertContentBlock = z.infer<typeof insertContentBlockSchema>;
export type ContentBlock = typeof contentBlocksTable.$inferSelect;
