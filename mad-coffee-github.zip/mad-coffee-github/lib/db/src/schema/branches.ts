import { createInsertSchema } from "drizzle-zod";
import { boolean, jsonb, pgTable, real, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import type { LocalizedText } from "./menu-items";

export const branchesTable = pgTable("branches", {
  id: text("id").primaryKey(),
  name: jsonb("name").$type<LocalizedText>().notNull(),
  area: jsonb("area").$type<LocalizedText>().notNull(),
  address: jsonb("address").$type<LocalizedText>().notNull(),
  hours: jsonb("hours").$type<LocalizedText>().notNull(),
  phone: text("phone").notNull(),
  lat: real("lat").notNull(),
  lng: real("lng").notNull(),
  image: text("image").notNull(),
  active: boolean("active").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertBranchSchema = createInsertSchema(branchesTable).omit({ updatedAt: true });
export type InsertBranch = z.infer<typeof insertBranchSchema>;
export type Branch = typeof branchesTable.$inferSelect;
